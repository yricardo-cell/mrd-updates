"""Reparto ABC del inventario y consultas del informe de herramientas paradas."""
from datetime import datetime, timedelta

import main
from auth import hash_password
from models import Almacen, Herramienta, Movimiento, Usuario


def _almacen(db):
    almacen = db.query(Almacen).filter(Almacen.activo == True).first()
    if not almacen:
        almacen = Almacen(nombre="Almacen ABC")
        db.add(almacen)
        db.commit()
    return almacen


def _login(client, db):
    db.add(Usuario(username="admin-abc", password_hash=hash_password("ClaveSegura123!"),
                   nombre="Admin ABC", rol="admin", activo=True, must_change_password=False))
    db.commit()
    resp = client.post("/login", data={"username": "admin-abc", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def _herramienta(db, almacen, codigo, precio=None):
    # Sin fecha de compra no hay amortizacion, asi que el valor actual es el precio.
    db.add(Herramienta(codigo=codigo, nombre=f"Herramienta {codigo}", estado="disponible",
                       activa=True, almacen_id=almacen.id, precio_compra=precio))
    db.commit()


def test_reparte_el_valor_en_a_b_y_c(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "ABC-CARA", 800)     # 80 % del total -> A
    _herramienta(db, almacen, "ABC-MEDIA", 150)    # hasta el 95 %   -> B
    _herramienta(db, almacen, "ABC-BARATA", 50)    # el resto        -> C

    d = main._analisis_abc(db)
    clases = {f["codigo"]: f["clase"] for f in d["filas"]}
    assert clases == {"ABC-CARA": "A", "ABC-MEDIA": "B", "ABC-BARATA": "C"}
    assert d["total"] == 1000
    assert [f["acumulado"] for f in d["filas"]] == [80.0, 95.0, 100.0]


def test_lo_que_no_tiene_precio_queda_fuera_y_se_avisa(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "ABC-CON-PRECIO", 100)
    _herramienta(db, almacen, "ABC-SIN-PRECIO", None)

    d = main._analisis_abc(db)
    assert [f["codigo"] for f in d["filas"]] == ["ABC-CON-PRECIO"]
    assert d["sin_valor"] == 1


def test_almacen_sin_precios_no_revienta(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "ABC-NADA", None)

    d = main._analisis_abc(db)
    assert d["filas"] == [] and d["total"] == 0
    assert all(g["n"] == 0 for g in d["resumen"])


def test_la_pagina_y_el_excel_responden(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "ABC-WEB", 500)
    _login(client, db)

    assert client.get("/informes/abc").status_code == 200
    excel = client.get("/informes/abc/excel")
    assert excel.status_code == 200
    assert excel.content[:2] == b"PK"


def test_paradas_solo_lista_lo_que_lleva_meses_sin_salir(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "PARADA-VIEJA", 100)
    _herramienta(db, almacen, "PARADA-RECIENTE", 100)
    _herramienta(db, almacen, "PARADA-NUNCA", 100)
    vieja = db.query(Herramienta).filter(Herramienta.codigo == "PARADA-VIEJA").one()
    reciente = db.query(Herramienta).filter(Herramienta.codigo == "PARADA-RECIENTE").one()
    db.add(Movimiento(herramienta_id=vieja.id, tipo="entrega", estado_nuevo="entregada",
                      fecha=datetime.now() - timedelta(days=400)))
    db.add(Movimiento(herramienta_id=reciente.id, tipo="entrega", estado_nuevo="entregada",
                      fecha=datetime.now() - timedelta(days=10)))
    db.commit()

    codigos = [f["codigo"] for f in main._herramientas_paradas(db, 6)]
    assert "PARADA-VIEJA" in codigos
    assert "PARADA-NUNCA" in codigos
    assert "PARADA-RECIENTE" not in codigos


def test_paradas_se_queda_con_la_salida_mas_reciente(client, db):
    almacen = _almacen(db)
    _herramienta(db, almacen, "PARADA-VARIAS", 100)
    h = db.query(Herramienta).filter(Herramienta.codigo == "PARADA-VARIAS").one()
    for dias in (500, 400, 20):
        db.add(Movimiento(herramienta_id=h.id, tipo="entrega", estado_nuevo="entregada",
                          fecha=datetime.now() - timedelta(days=dias)))
    db.commit()

    # La ultima salida fue hace 20 dias, asi que no esta parada.
    assert "PARADA-VARIAS" not in [f["codigo"] for f in main._herramientas_paradas(db, 6)]
