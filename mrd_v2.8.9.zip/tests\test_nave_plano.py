"""Plano o vista aerea de una zona, pintado en el suelo del 3D."""
import base64

import pytest

import main
from auth import hash_password
from models import Almacen, NaveZona, Usuario
from security import generar_csrf_token

PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
)


def _setup(db, rol="admin"):
    almacen = Almacen(nombre="Nave plano", codigo="MRD-PLA", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(
        username="user-plano", password_hash=hash_password("ClaveSegura123!"),
        nombre="Usuario Plano", rol=rol, activo=True, must_change_password=False,
        almacen_id=almacen.id,
    ))
    zona = NaveZona(almacen_id=almacen.id, nombre="Nave principal", tipo="nave",
                    largo=10000, ancho=7000, alto=800, activo=True)
    db.add(zona)
    db.commit()
    return almacen, zona


def _login(client):
    resp = client.post("/login", data={"username": "user-plano", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])
    token = generar_csrf_token()
    client.cookies.set("mrd_csrf", token)
    return {"X-CSRF-Token": token, "Accept": "application/json"}


@pytest.fixture(autouse=True)
def carpeta_aislada(tmp_path, monkeypatch):
    """Los planos se guardan en static/uploads/planos, que es una carpeta viva de
    la instalación: sin esto los tests borrarían el plano real de una zona."""
    monkeypatch.setattr(main, "_nave_plano_dir", lambda: tmp_path)
    return tmp_path


def test_subir_ver_y_quitar_el_plano(client, db, carpeta_aislada):
    _, zona = _setup(db)
    cabeceras = _login(client)
    fichero = carpeta_aislada / f"z_{zona.id}.png"

    r = client.post(f"/api/nave/zonas/{zona.id}/plano",
                    files={"plano": ("nave.png", PNG, "image/png")}, headers=cabeceras)
    assert r.status_code == 200, r.text
    assert r.json()["plano"].startswith(f"/static/uploads/planos/z_{zona.id}.png")

    db.expire_all()
    assert db.get(NaveZona, zona.id).plano_path == f"z_{zona.id}.png"
    assert fichero.exists()

    zonas = client.get("/api/nave/3d", headers=cabeceras).json()["zonas"]
    assert zonas[0]["plano"] == f"/static/uploads/planos/z_{zona.id}.png"

    r = client.post(f"/api/nave/zonas/{zona.id}/plano/eliminar", headers=cabeceras)
    assert r.status_code == 200
    db.expire_all()
    assert db.get(NaveZona, zona.id).plano_path is None
    assert not fichero.exists()


def test_rechaza_lo_que_no_es_una_imagen(client, db):
    _, zona = _setup(db)
    cabeceras = _login(client)
    r = client.post(f"/api/nave/zonas/{zona.id}/plano",
                    files={"plano": ("virus.txt", b"no soy una imagen", "text/plain")},
                    headers=cabeceras)
    assert r.status_code in (400, 415, 422)
    db.expire_all()
    assert db.get(NaveZona, zona.id).plano_path is None


def test_sin_plano_el_campo_viaja_vacio(client, db):
    _, zona = _setup(db)
    cabeceras = _login(client)
    zonas = client.get("/api/nave/3d", headers=cabeceras).json()["zonas"]
    assert zonas[0]["plano"] == ""


def test_quien_no_puede_editar_la_nave_no_pone_plano(client, db):
    _, zona = _setup(db, rol="encargado")
    cabeceras = _login(client)
    r = client.post(f"/api/nave/zonas/{zona.id}/plano",
                    files={"plano": ("nave.png", PNG, "image/png")}, headers=cabeceras)
    assert r.status_code == 403
    db.expire_all()
    assert db.get(NaveZona, zona.id).plano_path is None
