"""El PDF de etiquetas de hueco se abre en el navegador y trae una por pagina."""
import re

import main
from auth import hash_password
from models import Almacen, Ubicacion, Usuario


def _setup(db):
    almacen = Almacen(nombre="Almacén Madrid", codigo="MRD-ETI", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="admin-eti", password_hash=hash_password("ClaveSegura123!"),
                   nombre="Admin Etiquetas", rol="admin", activo=True,
                   must_change_password=False, almacen_id=almacen.id))
    for i in range(1, 4):
        db.add(Ubicacion(almacen_id=almacen.id, nombre=f"CONTENEDOR A{i}",
                         codigo=f"MRD-UBI-ETI-{i}", zona="CONTENEDOR",
                         estanteria="A", posicion=str(i), activo=True))
    db.add(Ubicacion(almacen_id=almacen.id, nombre="ROPA B1", codigo="MRD-UBI-ETI-R1",
                     zona="CUARTO DE ROPA", estanteria="B", posicion="1", activo=True))
    db.commit()
    return almacen


def _login(client):
    resp = client.post("/login", data={"username": "admin-eti", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def _paginas(pdf: bytes) -> int:
    # Sin excluir /Pages se cuenta tambien el nodo raiz del arbol de paginas.
    return len(re.findall(rb"/Type\s*/Page(?![s])", pdf))


def test_el_pdf_se_abre_en_el_navegador_en_vez_de_descargarse(client, db):
    almacen = _setup(db)
    _login(client)

    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf")
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert r.headers["content-disposition"].startswith("inline;")


def test_el_nombre_del_fichero_no_lleva_acentos(client, db):
    almacen = _setup(db)
    _login(client)

    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf")
    disposicion = r.headers["content-disposition"]
    assert "Almacen_Madrid" in disposicion
    assert disposicion.isascii()


def test_trae_una_pagina_por_hueco_para_poder_elegir(client, db):
    almacen = _setup(db)
    _login(client)

    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf")
    assert r.content[:4] == b"%PDF"
    assert _paginas(r.content) == 4  # los 4 huecos del almacen


def test_se_puede_pedir_solo_una_zona(client, db):
    almacen = _setup(db)
    _login(client)

    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf?zona=CONTENEDOR")
    assert _paginas(r.content) == 3
    assert "CONTENEDOR" in r.headers["content-disposition"]


def test_se_pueden_pedir_huecos_sueltos(client, db):
    almacen = _setup(db)
    _login(client)
    huecos = db.query(Ubicacion).filter(Ubicacion.almacen_id == almacen.id).all()

    uno = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf?ids={huecos[0].id}")
    assert _paginas(uno.content) == 1

    dos = f"{huecos[0].id},{huecos[2].id}"
    varios = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf?ids={dos}")
    assert _paginas(varios.content) == 2
    assert "seleccion" in varios.headers["content-disposition"]


def test_no_se_cuelan_huecos_de_otro_almacen(client, db):
    almacen = _setup(db)
    otro = Almacen(nombre="Almacen Ajeno", codigo="MRD-AJE", activo=True)
    db.add(otro)
    db.flush()
    ajeno = Ubicacion(almacen_id=otro.id, nombre="AJENA A1", codigo="MRD-UBI-AJE-1",
                      zona="AJENA", activo=True)
    db.add(ajeno)
    db.commit()
    _login(client)

    mio = db.query(Ubicacion).filter(Ubicacion.almacen_id == almacen.id).first()
    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf?ids={mio.id},{ajeno.id}")
    assert _paginas(r.content) == 1  # solo el del almacen pedido


def test_una_lista_de_huecos_con_basura_se_rechaza(client, db):
    almacen = _setup(db)
    _login(client)

    r = client.get(f"/almacenes/{almacen.id}/etiquetas-ubicaciones/pdf?ids=1;DROP")
    assert r.status_code == 400


def test_nombre_de_fichero_aguanta_lo_raro():
    assert main._nombre_de_fichero("Almacén Madrid") == "Almacen_Madrid"
    assert main._nombre_de_fichero("CUARTO DE ROPA") == "CUARTO_DE_ROPA"
    assert main._nombre_de_fichero("  ../etc/passwd  ") == "etc_passwd"
    assert main._nombre_de_fichero("") == "mrd"
    assert main._nombre_de_fichero("ñ") == "n"
