"""Tests para búsqueda global mejorada (mejora TIER2.3)."""
from auth import hash_password
from models import Almacen, Herramienta, Usuario


def _login(client, db):
    db.add(Usuario(
        username="admin-autocomplete", password_hash=hash_password("ClaveSegura123!"),
        nombre="Admin Autocomplete", rol="admin", activo=True, must_change_password=False,
    ))
    db.commit()
    resp = client.post(
        "/login",
        data={"username": "admin-autocomplete", "password": "ClaveSegura123!"},
        follow_redirects=False,
    )
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def _almacen(db):
    almacen = db.query(Almacen).filter(Almacen.activo == True).first()
    if not almacen:
        almacen = Almacen(nombre="Almacen Autocomplete")
        db.add(almacen)
        db.commit()
    return almacen


def test_api_autocomplete_encuentra_herramienta(client, db):
    _login(client, db)
    almacen = _almacen(db)
    db.add(Herramienta(
        codigo="MAR-001", nombre="Martillo de acero", estado="disponible",
        activa=True, almacen_id=almacen.id,
    ))
    db.commit()

    resp = client.get("/api/buscar/autocomplete?q=MAR")
    assert resp.status_code == 200
    sugerencias = resp.json()["sugerencias"]
    assert any(s["tipo"] == "herramienta" and s["texto"] == "MAR-001" for s in sugerencias)


def test_api_autocomplete_query_corta_no_busca(client, db):
    _login(client, db)
    almacen = _almacen(db)
    db.add(Herramienta(
        codigo="MAR-002", nombre="Martillo pequeno", estado="disponible",
        activa=True, almacen_id=almacen.id,
    ))
    db.commit()

    assert client.get("/api/buscar/autocomplete?q=").json()["sugerencias"] == []
    assert client.get("/api/buscar/autocomplete?q=M").json()["sugerencias"] == []


def test_api_autocomplete_requiere_login(client):
    resp = client.get("/api/buscar/autocomplete?q=MAR", follow_redirects=False)
    assert resp.status_code in (303, 401, 307)
