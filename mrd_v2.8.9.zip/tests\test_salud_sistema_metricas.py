"""Tests para el histórico de métricas del sistema (mejora TIER1.2)."""
from datetime import date, timedelta
from models import SaludSistemaHistorico


def test_obtener_historico_metricas(db):
    """Verifica que se obtenga el histórico de métricas."""
    from main import _salud_metricas_historico

    # Agregar datos de prueba
    for i in range(5):
        fecha = date.today() - timedelta(days=i)
        db.add(SaludSistemaHistorico(
            fecha=fecha,
            hora=f"{10+i}:00",
            cpu_percent=50.0 + i,
            memoria_mb=2000.0 + i*100,
            disco_libre_gb=100.0,
            errores_dia=i,
            errores_graves=0,
            uptime_horas=24
        ))
    db.commit()

    # Obtener histórico
    historico = _salud_metricas_historico(db, 30)
    assert len(historico) > 0, "Debería haber histórico"
    assert "fecha" in historico[0], "Debería tener fecha"
    assert "cpu" in historico[0], "Debería tener CPU"
    assert "memoria" in historico[0], "Debería tener memoria"


def test_modelo_salud_historico(db):
    """Verifica que se puedan crear registros en el modelo SaludSistemaHistorico."""
    # Crear un registro
    registro = SaludSistemaHistorico(
        fecha=date.today(),
        hora="12:30",
        cpu_percent=45.5,
        memoria_mb=1024.0,
        disco_libre_gb=50.0,
        errores_dia=2,
        errores_graves=0,
        uptime_horas=24
    )
    db.add(registro)
    db.commit()

    # Verificar que se guardó
    registros = db.query(SaludSistemaHistorico).all()
    assert len(registros) == 1, "Debería haber un registro"
    assert registros[0].cpu_percent == 45.5
