﻿import sqlite3
import time
from pathlib import Path
from datetime import datetime, timedelta

SOURCE = Path(r"C:\mrd tool\mrd-tool-control-2.5.0\data\mrd_tool.db")
BACKUP_ROOT = Path(r"D:\BACKUP_MRD_TOOL_CONTROL")
RETENTION_DAYS = 90
MAX_RETRIES = 5
RETRY_DELAY = 10

today = datetime.now()
folder = BACKUP_ROOT / today.strftime("%Y-%m-%d")
folder.mkdir(parents=True, exist_ok=True)

destination = folder / "mrd_tool.db"

for attempt in range(MAX_RETRIES):
    try:
        source_db = sqlite3.connect(str(SOURCE), timeout=30)
        backup_db = sqlite3.connect(str(destination))
        try:
            source_db.backup(backup_db)
        finally:
            backup_db.close()
            source_db.close()
        break
    except sqlite3.OperationalError as e:
        if attempt < MAX_RETRIES - 1:
            print(f"DB locked, retry {attempt+1}/{MAX_RETRIES} in {RETRY_DELAY}s: {e}")
            time.sleep(RETRY_DELAY)
        else:
            raise

# Comprobar integridad de la copia
check_db = sqlite3.connect(str(destination))
try:
    result = check_db.execute("PRAGMA integrity_check;").fetchone()[0]
finally:
    check_db.close()

if result.lower() != "ok":
    raise RuntimeError(f"Backup SQLite no valido: {result}")

# Eliminar copias con mas de 90 dias
limit = today - timedelta(days=RETENTION_DAYS)

for item in BACKUP_ROOT.iterdir():
    if not item.is_dir():
        continue

    try:
        date = datetime.strptime(item.name, "%Y-%m-%d")
    except ValueError:
        continue

    if date < limit:
        for file in item.iterdir():
            file.unlink()
        item.rmdir()

print(f"BACKUP OK: {destination}")
