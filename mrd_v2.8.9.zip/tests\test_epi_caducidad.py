"""Caducidad del EPI individual: un arnes caduca aunque no se haya usado."""
from datetime import date, timedelta

from auth import hash_password
from models import Almacen, EPIIndividual, Usuario
from security import generar_csrf_token


def _setup(db):
    almacen = Almacen(nombre="Almacen EPI", codigo="MRD-EPI", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="admin-epi", password_hash=hash_password("ClaveSegura123!"),
                   nombre="Admin EPI", rol="admin", activo=True, must_change_password=False,
                   almacen_id=almacen.id))
    db.commit()
    return almacen


def _login(client):
    resp = client.post("/login", data={"username": "admin-epi", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])
    token = generar_csrf_token()
    client.cookies.set("mrd_csrf", token)
    return {"X-CSRF-Token": token}


def _epi(db, almacen, codigo, caducidad=None):
    epi = EPIIndividual(tipo="ARNES", codigo_fabricacion=codigo, estado="activo",
                        almacen_id=almacen.id, fecha_caducidad=caducidad)
    db.add(epi)
    db.commit()
    return epi


def test_un_equipo_pasado_de_fecha_esta_caducado(client, db):
    almacen = _setup(db)
    epi = _epi(db, almacen, "ARNES-VIEJO", date.today() - timedelta(days=30))
    assert epi.caducado is True
    assert epi.dias_para_caducar == -30


def test_un_equipo_en_fecha_no_esta_caducado(client, db):
    almacen = _setup(db)
    epi = _epi(db, almacen, "ARNES-BUENO", date.today() + timedelta(days=45))
    assert epi.caducado is False
    assert epi.dias_para_caducar == 45


def test_el_ultimo_dia_todavia_vale(client, db):
    almacen = _setup(db)
    epi = _epi(db, almacen, "ARNES-HOY", date.today())
    assert epi.caducado is False
    assert epi.dias_para_caducar == 0


def test_sin_fecha_no_se_inventa_una_caducidad(client, db):
    almacen = _setup(db)
    epi = _epi(db, almacen, "ARNES-SIN-FECHA")
    assert epi.caducado is False
    assert epi.dias_para_caducar is None


def test_el_alta_guarda_la_caducidad(client, db):
    _setup(db)
    cabeceras = _login(client)
    caduca = date.today() + timedelta(days=365)
    r = client.post("/epis/individuales", data={
        "tipo": "ARNES", "codigo_fabricacion": "ARNES-ALTA-1",
        "fecha_caducidad": caduca.isoformat(),
    }, headers=cabeceras, follow_redirects=False)
    assert r.status_code in (200, 303)

    epi = db.query(EPIIndividual).filter(EPIIndividual.codigo_fabricacion == "ARNES-ALTA-1").one()
    assert epi.fecha_caducidad == caduca


def test_la_ficha_avisa_de_que_esta_caducado(client, db):
    almacen = _setup(db)
    epi = _epi(db, almacen, "ARNES-FICHA", date.today() - timedelta(days=5))
    _login(client)

    texto = client.get(f"/epis/individuales/{epi.id}").text
    assert "caducado hace 5 días" in texto
    assert "hay que retirarlo del uso" in texto
