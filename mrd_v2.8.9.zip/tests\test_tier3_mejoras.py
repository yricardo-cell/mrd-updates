"""Tests para mejoras TIER3 (Portal del Trabajador v2, Auditoría Completa)."""
from models import NotificacionTrabajador, CambioAuditoria, AuditoriaLog


def test_modelo_notificacion_trabajador(db):
    """Verifica que se puede crear una notificación."""
    from models import Trabajador

    t = Trabajador(nombre="Test", codigo="TST", activo=True)
    db.add(t)
    db.flush()

    notif = NotificacionTrabajador(
        trabajador_id=t.id,
        titulo="Prueba",
        mensaje="Mensaje de prueba"
    )
    db.add(notif)
    db.commit()

    registros = db.query(NotificacionTrabajador).all()
    assert len(registros) == 1
    assert registros[0].titulo == "Prueba"


def test_modelo_cambio_auditoria(db):
    """Verifica que se registran cambios detallados en auditoría."""
    from models import Trabajador, Usuario

    u = Usuario(nombre="admin", email="admin@test.com", password_hash="test", username="admin")
    db.add(u)
    db.flush()

    # Crear log de auditoría
    log = AuditoriaLog(
        tabla="trabajadores",
        registro_id=1,
        accion="editar",
        resumen="Cambio de nombre",
        usuario_id=u.id
    )
    db.add(log)
    db.flush()

    # Registrar cambio de campo
    cambio = CambioAuditoria(
        auditoria_log_id=log.id,
        campo="nombre",
        valor_anterior="Old Name",
        valor_nuevo="New Name",
        tipo_campo="string"
    )
    db.add(cambio)
    db.commit()

    registros = db.query(CambioAuditoria).all()
    assert len(registros) == 1
    assert registros[0].campo == "nombre"
    assert registros[0].valor_anterior == "Old Name"
    assert registros[0].valor_nuevo == "New Name"
