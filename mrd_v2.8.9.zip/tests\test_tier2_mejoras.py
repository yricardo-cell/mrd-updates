"""Tests para mejoras TIER2 (búsqueda mejorada, reportes automáticos, lazy-loading)."""
from models import ReporteProgramado, ReporteEnvio, Movimiento, Herramienta


def test_api_lazy_loading_movimientos(client):
    """Verifica que la API de lazy-loading devuelve un formato JSON válido."""
    # Llamar API (probablemente requiera autenticación)
    response = client.get("/api/movimientos/lazy?page=1&per_page=10")
    # Puede requerir autenticación (401) o puede tener éxito (200)
    # Lo importante es que devuelva un formato JSON válido cuando funciona
    if response.status_code == 200:
        data = response.json()
        assert "datos" in data or "total" in data, "API debe devolver JSON con datos o total"


def test_modelo_reporte_programado(db):
    """Verifica que se puede crear un ReporteProgramado."""
    from models import Almacen

    # Crear almacén de prueba
    alm = Almacen(nombre="Test", codigo="TST", activo=True)
    db.add(alm)
    db.flush()

    # Crear reporte programado
    rep = ReporteProgramado(
        nombre="Reporte de Prueba",
        tipo="inventario-valorado",
        almacen_id=alm.id,
        formato="pdf",
        frecuencia="semanal",
        hora_envio="09:00",
        destinatarios="test@example.com"
    )
    db.add(rep)
    db.commit()

    # Verificar
    registros = db.query(ReporteProgramado).all()
    assert len(registros) == 1
    assert registros[0].nombre == "Reporte de Prueba"


def test_modelo_reporte_envio(db):
    """Verifica que se registra el envío de reportes."""
    from models import Almacen

    alm = Almacen(nombre="Test", codigo="TST", activo=True)
    db.add(alm)
    db.flush()

    rep = ReporteProgramado(
        nombre="Test Report",
        tipo="inventario-valorado",
        almacen_id=alm.id,
        formato="excel",
        frecuencia="diario",
        destinatarios="admin@test.com"
    )
    db.add(rep)
    db.flush()

    # Registrar envío
    envio = ReporteEnvio(
        programado_id=rep.id,
        destinatarios="admin@test.com",
        asunto="Reporte diario",
        estado="enviado"
    )
    db.add(envio)
    db.commit()

    # Verificar
    registros = db.query(ReporteEnvio).all()
    assert len(registros) == 1
    assert registros[0].estado == "enviado"
