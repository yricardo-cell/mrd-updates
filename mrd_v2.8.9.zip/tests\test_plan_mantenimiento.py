"""El plan de mantenimiento puntua todos los activos sin consultar uno por uno."""
from datetime import datetime, timedelta

import mantenimiento as mant
from models import Almacen, Herramienta, Incidencia, MantenimientoProgramado, Reparacion


def _almacen(db):
    almacen = db.query(Almacen).filter(Almacen.activo == True).first()
    if not almacen:
        almacen = Almacen(nombre="Almacen Mantenimiento")
        db.add(almacen)
        db.commit()
    return almacen


def _herramienta(db, almacen, codigo):
    h = Herramienta(codigo=codigo, nombre=f"Herramienta {codigo}", estado="disponible",
                    activa=True, almacen_id=almacen.id)
    db.add(h)
    db.commit()
    return h


def test_puntua_todas_las_herramientas_activas(client, db):
    almacen = _almacen(db)
    for i in range(5):
        _herramienta(db, almacen, f"MANT-{i}")

    plan = mant.generar_plan_mantenimiento(db)

    # Si el calculo revienta, el except de dentro lo silencia y la lista sale
    # corta: por eso se comprueba el recuento, no solo que no haya excepcion.
    codigos = {s.get("codigo") for s in plan["scores"]}
    assert {f"MANT-{i}" for i in range(5)} <= codigos


def test_el_calculo_rapido_da_lo_mismo_que_el_de_una_en_una(client, db):
    almacen = _almacen(db)
    h = _herramienta(db, almacen, "MANT-COMPARA")
    db.add(Reparacion(numero="REP-MANT-1", herramienta_id=h.id))
    db.add(Reparacion(numero="REP-MANT-2", herramienta_id=h.id))
    db.add(Incidencia(numero="INC-MANT-1", titulo="Se atasca", herramienta_id=h.id))
    db.add(MantenimientoProgramado(
        tipo_activo="herramienta", activo_id=h.id, nombre_activo=h.nombre,
        fecha_programada=datetime.now() - timedelta(days=40),
        fecha_realizada=datetime.now() - timedelta(days=30), estado="completado"))
    db.commit()

    uno_a_uno = mant.calcular_score_herramienta(h, db)
    previos = mant._previos_por_activo(db, "herramienta", [h.id])
    de_golpe = mant.calcular_score_herramienta(h, db, previos[h.id])

    assert de_golpe["score"] == uno_a_uno["score"]
    assert de_golpe["nivel"] == uno_a_uno["nivel"]
    assert de_golpe["factores"] == uno_a_uno["factores"]


def test_cuenta_bien_reparaciones_e_incidencias(client, db):
    almacen = _almacen(db)
    con = _herramienta(db, almacen, "MANT-CON-HISTORIAL")
    sin = _herramienta(db, almacen, "MANT-SIN-HISTORIAL")
    db.add(Reparacion(numero="REP-CUENTA-1", herramienta_id=con.id))
    db.add(Reparacion(numero="REP-CUENTA-2", herramienta_id=con.id))
    db.add(Incidencia(numero="INC-CUENTA-1", titulo="Ruido raro", herramienta_id=con.id))
    db.commit()

    previos = mant._previos_por_activo(db, "herramienta", [con.id, sin.id])
    assert previos[con.id]["reparaciones"] == 2
    assert previos[con.id]["incidencias"] == 1
    assert previos[sin.id] == {"reparaciones": 0, "incidencias": 0, "ultimo_mantenimiento": None}


def test_se_queda_con_el_mantenimiento_mas_reciente(client, db):
    almacen = _almacen(db)
    h = _herramienta(db, almacen, "MANT-VARIOS")
    for dias in (200, 90, 15):
        db.add(MantenimientoProgramado(
            tipo_activo="herramienta", activo_id=h.id, nombre_activo=h.nombre,
            fecha_programada=datetime.now() - timedelta(days=dias + 5),
            fecha_realizada=datetime.now() - timedelta(days=dias), estado="completado"))
    db.commit()

    previos = mant._previos_por_activo(db, "herramienta", [h.id])
    dias_pasados = (datetime.now() - previos[h.id]["ultimo_mantenimiento"]).days
    assert dias_pasados == 15


def test_sin_activos_no_consulta_nada(client, db):
    assert mant._previos_por_activo(db, "herramienta", []) == {}
