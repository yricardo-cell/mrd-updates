"""Tests para mejoras TIER3 (Portal del Trabajador v2, Auditoría Completa)."""
from models import NotificacionTrabajador


def test_modelo_notificacion_trabajador(db):
    """Verifica que se puede crear una notificación."""
    from models import Trabajador

    t = Trabajador(nombre="Test", codigo="TST", activo=True)
    db.add(t)
    db.flush()

    notif = NotificacionTrabajador(
        trabajador_id=t.id,
        titulo="Prueba",
        mensaje="Mensaje de prueba"
    )
    db.add(notif)
    db.commit()

    registros = db.query(NotificacionTrabajador).all()
    assert len(registros) == 1
    assert registros[0].titulo == "Prueba"


# El test de CambioAuditoria se retira con el modelo en la 2.9.0: la tabla
# existía pero nunca la escribió nadie.
