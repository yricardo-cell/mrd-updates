"""Nave con su forma real (2.9.5): contorno dibujado sobre el plano y zonas giradas dentro."""
import json

import main
from auth import hash_password
from models import Almacen, AuditoriaLog, NaveZona, Usuario
from security import generar_csrf_token

# Una nave en L de 60 x 40 m dentro de un plano de 80 x 50 m (en cm).
L_FORMA = [[1000, 500], [7000, 500], [7000, 2500], [4000, 2500], [4000, 4500], [1000, 4500]]


def _setup(db, rol="admin", plano=True):
    almacen = Almacen(nombre="Nave forma", codigo="MRD-FOR", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="forma", password_hash=hash_password("ClaveSegura123!"), nombre="Forma",
                   rol=rol, activo=True, must_change_password=False, almacen_id=almacen.id))
    nave = NaveZona(almacen_id=almacen.id, nombre="NAVE", tipo="nave", largo=3000, ancho=1500, alto=800,
                    plano_path="plano_prueba.jpg" if plano else None, activo=True)
    cont = NaveZona(almacen_id=almacen.id, nombre="CONTENEDOR", tipo="contenedor", largo=732, ancho=244, alto=259,
                    pos_x=1500, pos_z=1000, activo=True)
    db.add_all([nave, cont])
    db.commit()
    return almacen, nave, cont


def _login(client):
    resp = client.post("/login", data={"username": "forma", "password": "ClaveSegura123!"}, follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])
    token = generar_csrf_token()
    client.cookies.set("mrd_csrf", token)
    return {"X-CSRF-Token": token, "Accept": "application/json"}


def _guardar(client, h, zona_id, puntos=L_FORMA, largo=8000, ancho=5000):
    return client.post(f"/api/nave/zonas/{zona_id}/contorno", json={"puntos": puntos, "largo": largo, "ancho": ancho}, headers=h)


# ── Cuentas ─────────────────────────────────────────────────────────────────

def test_superficie_de_la_nave_en_l():
    assert main._poligono_area(L_FORMA) == 6000 * 2000 + 3000 * 2000  # 18 000 000 cm² = 1800 m²


def test_detecta_paredes_que_se_cruzan():
    assert not main._poligono_se_cruza(L_FORMA)
    assert main._poligono_se_cruza([[0, 0], [100, 100], [100, 0], [0, 100]])  # forma de ocho


def test_punto_dentro_y_fuera_de_la_l():
    assert main._punto_en_poligono(2000, 1000, L_FORMA)
    assert not main._punto_en_poligono(6000, 4000, L_FORMA)  # el hueco de la L


def test_girar_90_cambia_largo_por_ancho():
    z = NaveZona(largo=600, ancho=200, pos_x=0, pos_z=0, giro=90)
    xs = [p[0] for p in main._zona_esquinas(z)]
    zs = [p[1] for p in main._zona_esquinas(z)]
    assert round(max(xs) - min(xs)) == 200 and round(max(zs) - min(zs)) == 600


def test_zona_dentro_o_fuera_de_la_forma():
    dentro = NaveZona(largo=732, ancho=244, pos_x=1500, pos_z=1000, giro=0)
    en_el_hueco = NaveZona(largo=732, ancho=244, pos_x=5000, pos_z=3500, giro=0)
    sin_colocar = NaveZona(largo=732, ancho=244, pos_x=None, pos_z=None)
    assert main._zona_dentro_de(dentro, L_FORMA) is True
    assert main._zona_dentro_de(en_el_hueco, L_FORMA) is False
    assert main._zona_dentro_de(sin_colocar, L_FORMA) is None
    assert main._zona_dentro_de(dentro, None) is None


# ── Guardar la forma ────────────────────────────────────────────────────────

def test_guardar_la_forma(client, db):
    _, nave, _ = _setup(db)
    h = _login(client)

    r = _guardar(client, h, nave.id)
    assert r.status_code == 200, r.text
    assert r.json() == {"ok": True, "esquinas": 6, "superficie_m2": 1800}
    db.expire_all()
    z = db.get(NaveZona, nave.id)
    assert json.loads(z.contorno) == L_FORMA
    assert (z.largo, z.ancho) == (8000, 5000)   # el plano entero, a escala
    assert db.query(AuditoriaLog).filter(AuditoriaLog.tabla == "nave_zonas", AuditoriaLog.accion == "contorno").count() == 1


def test_rechaza_formas_malas(client, db):
    _, nave, _ = _setup(db)
    h = _login(client)

    assert _guardar(client, h, nave.id, puntos=[[0, 0], [100, 0]]).status_code == 422                     # 2 esquinas
    assert _guardar(client, h, nave.id, puntos=[[0, 0], [5000, 5000], [5000, 0], [0, 5000]]).status_code == 400  # se cruza
    assert _guardar(client, h, nave.id, puntos=[[0, 0], [9000, 0], [9000, 100]]).status_code == 400        # se sale del plano
    assert _guardar(client, h, nave.id, puntos=[[0, 0], [50, 0], [50, 50]]).status_code == 400             # menos de 1 m²
    db.expire_all()
    assert db.get(NaveZona, nave.id).contorno is None


def test_solo_una_nave_con_plano_tiene_forma(client, db):
    _, nave, cont = _setup(db, plano=False)
    h = _login(client)

    assert _guardar(client, h, cont.id).status_code == 400   # no es una nave
    r = _guardar(client, h, nave.id)
    assert r.status_code == 400 and "plano" in r.json()["detail"]


def test_quien_no_edita_la_nave_no_cambia_la_forma(client, db):
    _, nave, _ = _setup(db, rol="operario")
    h = _login(client)

    assert _guardar(client, h, nave.id).status_code == 403
    assert client.get(f"/nave/3d/contorno/{nave.id}").status_code == 403


def test_volver_al_rectangulo(client, db):
    _, nave, _ = _setup(db)
    h = _login(client)
    _guardar(client, h, nave.id)

    r = client.post(f"/api/nave/zonas/{nave.id}/contorno/eliminar", headers=h)
    assert r.status_code == 200
    db.expire_all()
    z = db.get(NaveZona, nave.id)
    assert z.contorno is None and (z.largo, z.ancho) == (8000, 5000)


def test_con_forma_el_formulario_no_cambia_largo_ni_ancho(client, db):
    _, nave, _ = _setup(db)
    h = _login(client)
    _guardar(client, h, nave.id)

    r = client.post("/api/nave/zonas", json={"id": nave.id, "nombre": "NAVE", "tipo": "nave", "largo": 100, "ancho": 100, "alto": 900}, headers=h)
    assert r.status_code == 200
    db.expire_all()
    z = db.get(NaveZona, nave.id)
    assert (z.largo, z.ancho, z.alto) == (8000, 5000, 900)


# ── Giro y dentro/fuera en el 3D ────────────────────────────────────────────

def test_el_giro_se_guarda_y_sin_giro_se_conserva(client, db):
    _, _, cont = _setup(db)
    h = _login(client)
    base = {"id": cont.id, "nombre": "CONTENEDOR", "tipo": "contenedor", "largo": 732, "ancho": 244, "alto": 259,
            "pos_x": 1500, "pos_z": 1000}

    assert client.post("/api/nave/zonas", json={**base, "giro": 32}, headers=h).status_code == 200
    assert client.post("/api/nave/zonas", json=base, headers=h).status_code == 200     # formulario sin giro
    db.expire_all()
    assert db.get(NaveZona, cont.id).giro == 32
    assert client.post("/api/nave/zonas", json={**base, "giro": 400}, headers=h).status_code == 422


def test_el_3d_manda_forma_giro_y_si_cabe(client, db):
    _, nave, cont = _setup(db)
    h = _login(client)
    _guardar(client, h, nave.id)

    zonas = {z["nombre"]: z for z in client.get("/api/nave/3d").json()["zonas"]}
    assert zonas["NAVE"]["contorno"] == L_FORMA and zonas["NAVE"]["dentro"] is None
    assert zonas["CONTENEDOR"]["dentro"] is True and zonas["CONTENEDOR"]["giro"] == 0

    client.post(f"/api/nave/zonas/{cont.id}/mover", json={"x": 5000, "z": 3500}, headers=h)   # al hueco de la L
    zonas = {z["nombre"]: z for z in client.get("/api/nave/3d").json()["zonas"]}
    assert zonas["CONTENEDOR"]["dentro"] is False


def test_sin_forma_no_hay_aviso(client, db):
    _setup(db)
    _login(client)
    zonas = {z["nombre"]: z for z in client.get("/api/nave/3d").json()["zonas"]}
    assert zonas["NAVE"]["contorno"] is None and zonas["CONTENEDOR"]["dentro"] is None


# ── Páginas ─────────────────────────────────────────────────────────────────

def test_la_pagina_del_editor(client, db):
    _, nave, cont = _setup(db)
    _login(client)

    html = client.get(f"/nave/3d/contorno/{nave.id}").text
    assert 'id="nc-svg"' in html and "/static/uploads/planos/plano_prueba.jpg" in html
    assert "Solo una zona de tipo" in client.get(f"/nave/3d/contorno/{cont.id}").text


def test_el_editor_pide_el_plano_si_no_hay(client, db):
    _, nave, _ = _setup(db, plano=False)
    _login(client)
    html = client.get(f"/nave/3d/contorno/{nave.id}").text
    assert "Primero pon el" in html and 'id="nc-svg"' not in html


def test_zonas_en_3d_tiene_forma_y_giro(client, db):
    _setup(db)
    _login(client)
    html = client.get("/nave/3d").text
    assert 'id="z-forma-editar"' in html and 'id="z-giro"' in html and 'id="z-alinear"' in html
