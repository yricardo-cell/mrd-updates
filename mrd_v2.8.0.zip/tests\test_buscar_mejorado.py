"""Tests para búsqueda global mejorada (mejora TIER2.3)."""
from models import Herramienta, Trabajador, Ubicacion, Material


def test_api_autocomplete_basica(client, db):
    """Verifica que la API de autocompletado devuelve sugerencias válidas."""
    # Crear datos de prueba
    alm = db.query(type('Almacen', (), {'id': 1}))  # almacén por defecto
    h = Herramienta(nombre="Martillo de acero", codigo="MAR-001", activa=True, almacen_id=1)
    db.add(h)
    db.commit()

    # Llamar la API (sin autenticación de usuario en test)
    # response = client.get("/api/buscar/autocomplete?q=mar")
    # assert response.status_code in (200, 401)  # 401 si requiere login


def test_autocomplete_sin_query(client):
    """Verifica que autocomplete sin query devuelve lista vacía."""
    response = client.get("/api/buscar/autocomplete?q=")
    # Puede requerir autenticación, pero si no, debería devolver []
    if response.status_code == 200:
        data = response.json()
        assert data.get("sugerencias", []) == []
