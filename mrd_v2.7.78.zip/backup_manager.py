"""
MRD TOOL CONTROL — Gestor de Backups
Sprint 5.6 — v1.9.6-alpha
- Backup automático diario/semanal/mensual
- Backup pre-acción (antes de actualizar, importar, migrar)
- Compresión gzip
- Cifrado AES opcional (clave en .env)
- Verificación automática de integridad
- Restauración guiada
- Historial y limpieza automática
"""
import gzip
import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import sqlite3
import tarfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock, RLock, Thread

logger = logging.getLogger("mrd.backup")

BASE_DIR    = Path(__file__).parent
BACKUPS_DIR = BASE_DIR / "backups"
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)

# Directorios de fotos que no viven en la BD SQLite y por tanto quedan fuera
# del hot-backup de create_backup() salvo que se archiven aparte.
UPLOADS_HERRAMIENTAS_DIR = BASE_DIR / "uploads" / "herramientas"
UPLOADS_EPI_DIR          = BASE_DIR / "static" / "uploads" / "epis"

_backup_lock = Lock()


def _photo_sources():
    """(prefijo, directorio) de cada carpeta de fotos a respaldar.

    Se lee en cada llamada (no en import) para que los tests puedan
    monkeypatchear UPLOADS_HERRAMIENTAS_DIR/UPLOADS_EPI_DIR sin recargar
    el módulo.
    """
    return [
        ("herramientas", UPLOADS_HERRAMIENTAS_DIR),
        ("epis", UPLOADS_EPI_DIR),
    ]


def _photos_archive_path(base_name: str, backup_subdir: Path) -> Path:
    return backup_subdir / f"{base_name}.photos.tar.gz"


def _backup_group_key(filename: str) -> str:
    """Nombre base común entre un backup .db[.gz][.enc] y su .photos.tar.gz
    hermano, para que cleanup_old_backups() los trate como una sola unidad
    de retención en vez de como ficheros independientes."""
    name = re.sub(r"\.photos\.tar\.gz$", "", filename)
    return re.sub(r"\.db(\.gz)?(\.enc)?$", "", name)


def _archive_photos(base_name: str, backup_subdir: Path) -> dict | None:
    """Empaqueta las fotos de herramientas/EPI en un .tar.gz junto al backup.

    Devuelve None si ninguna de las dos carpetas tiene ficheros (evita crear
    un archivo vacío), o un dict con filename/sha256/size_bytes si se creó.
    """
    sources = [(prefix, d) for prefix, d in _photo_sources() if d.exists() and any(d.rglob("*"))]
    if not sources:
        return None

    archive_path = _photos_archive_path(base_name, backup_subdir)
    tmp_path = archive_path.with_suffix(".tmp")
    try:
        with tarfile.open(tmp_path, "w:gz", compresslevel=6) as tar:
            for prefix, directory in sources:
                tar.add(directory, arcname=prefix)
        tmp_path.replace(archive_path)
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise

    return {
        "filename":   archive_path.name,
        "size_bytes": archive_path.stat().st_size,
        "sha256":     _sha256_file(archive_path),
    }


def _restore_photos(archive_path: Path) -> dict:
    """Extrae el .tar.gz de fotos a las rutas UPLOADS_HERRAMIENTAS_DIR/UPLOADS_EPI_DIR actuales."""
    targets = dict(_photo_sources())
    restored = 0
    with tarfile.open(archive_path, "r:gz") as tar:
        for member in tar.getmembers():
            if "/" not in member.name:
                continue
            prefix, rel = member.name.split("/", 1)
            target_dir = targets.get(prefix)
            if target_dir is None or not rel:
                continue
            dest = (target_dir / rel).resolve()
            # Defensa en profundidad contra path traversal en el .tar.gz
            if not dest.is_relative_to(target_dir.resolve()):
                continue
            if member.isdir():
                dest.mkdir(parents=True, exist_ok=True)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            fobj = tar.extractfile(member)
            if fobj is None:
                continue
            dest.write_bytes(fobj.read())
            restored += 1
    return {"restored_files": restored}

# ─── Configuración ────────────────────────────────────────────────────────────
def _get_config() -> dict:
    return {
        "backup_dir":           str(BACKUPS_DIR),
        "retention_daily":      int(os.getenv("MRD_BACKUP_RETAIN_DAILY",   "7")),
        "retention_weekly":     int(os.getenv("MRD_BACKUP_RETAIN_WEEKLY",  "4")),
        "retention_monthly":    int(os.getenv("MRD_BACKUP_RETAIN_MONTHLY", "12")),
        "retention_pre_action": int(os.getenv("MRD_BACKUP_RETAIN_PRE",     "10")),
        "encrypt":              os.getenv("MRD_BACKUP_ENCRYPT", "0") == "1",
        "encrypt_key":          os.getenv("MRD_BACKUP_KEY", ""),
        "compress":             True,
        "max_size_mb":          int(os.getenv("MRD_BACKUP_MAX_MB", "500")),
    }


# ─── Copia fuera del PC (2.7.56) ─────────────────────────────────────────────
EXTERNO_CFG = BASE_DIR / "config" / "backup_externo.json"
EXTERNO_SUBDIR = "MRD Tool Control"


def _externo_leer() -> dict:
    try:
        return json.loads(EXTERNO_CFG.read_text(encoding="utf-8")) if EXTERNO_CFG.exists() else {}
    except Exception:
        return {}


def _externo_escribir(data: dict) -> None:
    EXTERNO_CFG.parent.mkdir(parents=True, exist_ok=True)
    EXTERNO_CFG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get_externo_config() -> dict:
    d = _externo_leer()
    ruta = str(d.get("ruta") or "").strip()
    return {"ruta": ruta, "activo": bool(d.get("activo")) and bool(ruta), "ultimo_ok": d.get("ultimo_ok"),
            "ultimo_error": d.get("ultimo_error"), "ultimo_error_en": d.get("ultimo_error_en")}


def set_externo_config(ruta: str, activo: bool) -> dict:
    d = _externo_leer()
    d["ruta"] = str(ruta or "").strip()
    d["activo"] = bool(activo) and bool(d["ruta"])
    _externo_escribir(d)
    return get_externo_config()


def _externo_estado_guardar(**campos) -> None:
    d = _externo_leer()
    d.update(campos)
    _externo_escribir(d)


def _externo_destino(ruta: str) -> Path | None:
    ruta = str(ruta or "").strip()
    return Path(ruta) / EXTERNO_SUBDIR if ruta else None


def probar_externo(ruta: str) -> dict:
    """Comprueba que la carpeta (USB, disco externo, OneDrive, Google Drive) existe y se puede escribir."""
    ruta = str(ruta or "").strip()
    if not ruta:
        return {"ok": False, "error": "Indica una carpeta: por ejemplo E:\\ (un USB) o la carpeta de OneDrive o Google Drive."}
    base = Path(ruta)
    if not base.exists():
        return {"ok": False, "error": f"La carpeta no existe o no está conectada: {base}"}
    dest = base / EXTERNO_SUBDIR
    try:
        dest.mkdir(parents=True, exist_ok=True)
        prueba = dest / f".mrd_prueba_{secrets.token_hex(4)}.tmp"
        prueba.write_text("ok", encoding="utf-8")
        prueba.unlink()
    except Exception as exc:
        return {"ok": False, "error": f"No se puede escribir en {dest}: {exc}"}
    libre = None
    try:
        libre = round(shutil.disk_usage(base).free / 1024 ** 2)
    except Exception:
        pass
    return {"ok": True, "destino": str(dest), "libre_mb": libre}


def _externo_relativa(origen: Path) -> Path:
    try:
        return origen.resolve().relative_to(BACKUPS_DIR.resolve())
    except ValueError:
        return Path(origen.name)


def _externo_copiar(rutas, dest: Path) -> tuple[list, list]:
    copiados, errores = [], []
    for origen in rutas:
        origen = Path(origen)
        if not origen.is_file():
            continue
        destino = dest / _externo_relativa(origen)
        try:
            if not dest.parent.exists():
                raise FileNotFoundError(f"la carpeta {dest.parent} no está conectada")
            destino.parent.mkdir(parents=True, exist_ok=True)
            if destino.exists() and destino.stat().st_size == origen.stat().st_size:
                copiados.append(str(destino))
                continue
            tmp = destino.with_name(destino.name + ".parcial")
            shutil.copy2(origen, tmp)
            os.replace(tmp, destino)
            if destino.stat().st_size != origen.stat().st_size:
                raise OSError("el tamaño no coincide tras copiar")
            copiados.append(str(destino))
        except Exception as exc:
            errores.append(f"{origen.name}: {exc}")
    return copiados, errores


def _aviso_externo(error: str) -> None:
    """Aviso interno (uno al día) cuando la copia externa falla."""
    try:
        from database import SessionLocal as _SLx
        from models import Aviso as _Aviso
        db = _SLx()
        try:
            titulo = f"Copia fuera del PC fallida {datetime.now().strftime('%d/%m/%Y')}"
            if not db.query(_Aviso).filter(_Aviso.titulo == titulo).first():
                db.add(_Aviso(titulo=titulo, tipo="alerta", prioridad="alta", enlace="/backup",
                              mensaje=f"No se pudo copiar la copia de seguridad a la carpeta externa: {error}. "
                                      "Comprueba que el USB, el disco o la carpeta de la nube estén conectados."))
                db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.warning("No se pudo crear el aviso de copia externa: %s", exc)


def copiar_a_externo(rutas) -> dict | None:
    """Copia ficheros de backup al destino externo. None si la copia externa no está activa."""
    cfg = get_externo_config()
    if not cfg["activo"]:
        return None
    dest = _externo_destino(cfg["ruta"])
    copiados, errores = _externo_copiar(rutas, dest)
    ahora = datetime.utcnow().isoformat(timespec="seconds")
    if errores:
        texto = "; ".join(errores)[:500]
        _externo_estado_guardar(ultimo_error=texto, ultimo_error_en=ahora)
        _aviso_externo(texto[:300])
        return {"ok": False, "copiados": copiados, "error": texto, "destino": str(dest)}
    _externo_estado_guardar(ultimo_ok=ahora, ultimo_error=None, ultimo_error_en=None)
    return {"ok": True, "copiados": copiados, "destino": str(dest)}


def _archivos_backup_locales() -> list:
    out = []
    for m in _load_history():
        p = Path(str(m.get("path") or ""))
        if p.is_file():
            out.append(p)
        if m.get("photos_filename"):
            f = p.parent / m["photos_filename"]
            if f.is_file():
                out.append(f)
    return out


def sincronizar_externo() -> dict:
    """Copia a la carpeta externa todos los backups que falten y quita de allí los que ya no existen aquí."""
    cfg = get_externo_config()
    if not cfg["ruta"]:
        return {"ok": False, "error": "No hay carpeta externa configurada"}
    dest = _externo_destino(cfg["ruta"])
    ahora = datetime.utcnow().isoformat(timespec="seconds")
    if not dest.parent.exists():
        error = f"La carpeta no está conectada: {dest.parent}"
        _externo_estado_guardar(ultimo_error=error, ultimo_error_en=ahora)
        _aviso_externo(error)
        return {"ok": False, "error": error}
    locales = _archivos_backup_locales()
    copiados, errores = _externo_copiar(locales, dest)
    relativas = {str(_externo_relativa(p)) for p in locales}
    borrados = 0
    if dest.exists():
        for f in dest.rglob("*"):
            if f.is_file() and f.suffix in (".db", ".gz", ".enc", ".tar", ".parcial") and str(f.relative_to(dest)) not in relativas:
                try:
                    f.unlink()
                    borrados += 1
                except Exception:
                    pass
    if errores:
        texto = "; ".join(errores)[:500]
        _externo_estado_guardar(ultimo_error=texto, ultimo_error_en=ahora)
        _aviso_externo(texto[:300])
        return {"ok": False, "copiados": len(copiados), "borrados": borrados, "error": texto}
    _externo_estado_guardar(ultimo_ok=ahora, ultimo_error=None, ultimo_error_en=None)
    return {"ok": True, "copiados": len(copiados), "borrados": borrados, "destino": str(dest)}


def externo_estado() -> dict:
    cfg = get_externo_config()
    dest = _externo_destino(cfg["ruta"]) if cfg["ruta"] else None
    disponible = bool(dest and dest.parent.exists())
    locales = _archivos_backup_locales()
    copiados = pendientes = 0
    libre = None
    if dest and disponible:
        for p in locales:
            d = dest / _externo_relativa(p)
            if d.exists() and d.stat().st_size == p.stat().st_size:
                copiados += 1
            else:
                pendientes += 1
        try:
            libre = round(shutil.disk_usage(dest.parent).free / 1024 ** 2)
        except Exception:
            pass
    else:
        pendientes = len(locales)
    return {**cfg, "destino": str(dest) if dest else "", "disponible": disponible, "copiados": copiados,
            "pendientes": pendientes, "locales": len(locales), "libre_mb": libre}


def _externo_tras_programados(result: dict) -> None:
    cfg = get_externo_config()
    if not cfg["activo"]:
        return
    est = externo_estado()
    if not est["disponible"]:
        _aviso_externo(f"la carpeta {est['destino']} no está conectada")
        result.setdefault("errors", []).append({"tipo": "externo", "error": "carpeta externa no conectada"})


# ─── Cifrado AES (usando Fernet si disponible, fallback XOR) ─────────────────
def _encrypt_data(data: bytes, key: str) -> bytes:
    """Cifra con Fernet (AES-128-CBC + HMAC). Requiere cryptography."""
    try:
        from cryptography.fernet import Fernet
        import base64, hashlib
        # Derivar clave Fernet desde la clave maestra
        dk = hashlib.sha256(key.encode()).digest()
        fkey = base64.urlsafe_b64encode(dk)
        f = Fernet(fkey)
        return f.encrypt(data)
    except ImportError:
        raise RuntimeError(
            "El cifrado requiere 'cryptography'. Instala con: pip install cryptography"
        )


def _decrypt_data(data: bytes, key: str) -> bytes:
    try:
        from cryptography.fernet import Fernet
        import base64, hashlib
        dk = hashlib.sha256(key.encode()).digest()
        fkey = base64.urlsafe_b64encode(dk)
        f = Fernet(fkey)
        return f.decrypt(data)
    except ImportError:
        raise RuntimeError("El cifrado requiere 'cryptography'.")


# ─── Crear backup ─────────────────────────────────────────────────────────────
def create_backup(
    tipo: str = "manual",
    label: str = "",
    compress: bool = True,
    encrypt: bool = None,
) -> dict:
    """
    Crea un backup de la base de datos activa.
    tipo: "daily" | "weekly" | "monthly" | "pre_update" | "pre_import" | "pre_migrate" | "manual"
    Devuelve {ok, path, size_bytes, sha256, elapsed_ms, ...}
    """
    from config import DATABASE_URL, DATA_DIR
    cfg = _get_config()
    if encrypt is None:
        encrypt = cfg["encrypt"]
    # Guardián Fase 4: nunca cifrar con una clave que no esté guardada. Antes,
    # sin MRD_BACKUP_KEY se generaba una clave al azar que no se conservaba y
    # la copia quedaba irrecuperable.
    if encrypt and not cfg.get("encrypt_key"):
        logger.error("Copia cifrada pedida sin MRD_BACKUP_KEY: no se crea la copia.")
        return {
            "ok": False,
            "error": "MRD_BACKUP_ENCRYPT=1 pero falta MRD_BACKUP_KEY en config/local.env: "
                     "no se cifra con una clave que no se guarda.",
        }

    t0 = time.perf_counter()

    # Solo soportamos SQLite nativamente; PostgreSQL requiere pg_dump
    if not DATABASE_URL.startswith("sqlite"):
        return _pg_backup(tipo, label, cfg)

    # Resolver ruta del fichero SQLite
    db_path = Path(str(DATABASE_URL).replace("sqlite:///", "").replace("sqlite://", ""))
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path
    if not db_path.exists():
        return {"ok": False, "error": f"Base de datos no encontrada: {db_path}"}

    # Nombre del fichero de backup
    ts    = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    label = label.replace(" ", "_").replace("/", "-")[:30]
    parts = [ts, tipo]
    if label:
        parts.append(label)
    base_name = "_".join(parts)

    # Directorio por tipo
    backup_subdir = BACKUPS_DIR / tipo
    backup_subdir.mkdir(parents=True, exist_ok=True)

    # Extensión
    ext = ".db"
    if compress:
        ext += ".gz"
    if encrypt:
        ext += ".enc"
    backup_path = backup_subdir / (base_name + ext)

    with _backup_lock:
        try:
            # Leer DB original (hot backup con SQLite connection)
            tmp_path = backup_path.with_suffix(".tmp")
            _sqlite_hot_backup(db_path, tmp_path)

            # Leer bytes
            raw_data = tmp_path.read_bytes()
            tmp_path.unlink(missing_ok=True)

            # Comprimir
            if compress:
                raw_data = gzip.compress(raw_data, compresslevel=6)

            # Cifrar
            if encrypt:
                raw_data = _encrypt_data(raw_data, cfg["encrypt_key"])

            # Escribir
            backup_path.write_bytes(raw_data)

            size_bytes = backup_path.stat().st_size
            sha256     = _sha256_file(backup_path)

            # Fotos de herramientas y EPI: no viven en la BD, se archivan
            # en un .tar.gz hermano. Fallo aquí no debe invalidar el backup
            # de la BD, que es la parte crítica.
            photos_meta = None
            try:
                photos_meta = _archive_photos(base_name, backup_subdir)
            except Exception as exc:
                logger.warning("No se pudieron archivar las fotos del backup: %s", exc)

            elapsed = round((time.perf_counter() - t0) * 1000)

            # Guardar metadatos
            meta = {
                "path":       str(backup_path),
                "filename":   backup_path.name,
                "tipo":       tipo,
                "label":      label,
                "size_bytes": size_bytes,
                "sha256":     sha256,
                "compressed": compress,
                "encrypted":  encrypt,
                "created_at": datetime.utcnow().isoformat(timespec="seconds"),
                "elapsed_ms": elapsed,
                "photos_included":  photos_meta is not None,
            }
            if photos_meta:
                meta["photos_filename"]   = photos_meta["filename"]
                meta["photos_sha256"]     = photos_meta["sha256"]
                meta["photos_size_bytes"] = photos_meta["size_bytes"]
            # Copia fuera del PC (2.7.56): segunda copia en USB / disco / nube si está activa.
            externo = copiar_a_externo([backup_path] + ([backup_subdir / photos_meta["filename"]] if photos_meta else []))
            if externo is not None:
                meta["externo_ok"] = bool(externo.get("ok"))
                meta["externo_error"] = externo.get("error")
            _save_meta(meta)
            logger.info("Backup creado: %s (%.1f KB, %d ms)", backup_path.name, size_bytes/1024, elapsed)

            return {"ok": True, **meta}

        except Exception as exc:
            logger.error("Error en backup: %s", exc)
            backup_path.unlink(missing_ok=True)
            return {"ok": False, "error": str(exc), "tipo": tipo}


def _sqlite_hot_backup(src: Path, dst: Path):
    """Hot backup de SQLite usando la API de backup de sqlite3."""
    src_conn = sqlite3.connect(str(src))
    dst_conn = sqlite3.connect(str(dst))
    try:
        src_conn.backup(dst_conn, pages=100)
    finally:
        dst_conn.close()
        src_conn.close()


def _pg_backup(tipo: str, label: str, cfg: dict) -> dict:
    """Backup PostgreSQL usando pg_dump (si está disponible)."""
    from config import DATABASE_URL
    import subprocess
    ts        = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    subdir    = BACKUPS_DIR / tipo
    subdir.mkdir(parents=True, exist_ok=True)
    out_file  = subdir / f"{ts}_{tipo}_postgres.sql.gz"
    t0        = time.perf_counter()
    try:
        proc = subprocess.run(
            ["pg_dump", "--no-password", "--format=custom", DATABASE_URL],
            capture_output=True, timeout=300,
        )
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr.decode()[:500], "tipo": tipo}
        data    = gzip.compress(proc.stdout, compresslevel=6)
        out_file.write_bytes(data)
        sha256  = _sha256_file(out_file)
        elapsed = round((time.perf_counter() - t0) * 1000)
        meta    = {
            "path": str(out_file), "filename": out_file.name, "tipo": tipo,
            "size_bytes": out_file.stat().st_size, "sha256": sha256,
            "compressed": True, "encrypted": False,
            "created_at": datetime.utcnow().isoformat(timespec="seconds"),
            "elapsed_ms": elapsed,
        }
        _save_meta(meta)
        return {"ok": True, **meta}
    except FileNotFoundError:
        return {"ok": False, "error": "pg_dump no encontrado en PATH. Instala postgresql-client.", "tipo": tipo}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "tipo": tipo}


# ─── Verificación ─────────────────────────────────────────────────────────────
def verify_backup(backup_path: str) -> dict:
    """
    Verifica la integridad de un backup:
    - SHA-256 contra el registrado en metadatos
    - Descomprime y abre con sqlite3 (solo SQLite)
    """
    path = Path(backup_path)
    if not path.exists():
        return {"ok": False, "error": "Fichero no encontrado"}

    t0     = time.perf_counter()
    sha256 = _sha256_file(path)

    # Buscar metadatos
    meta    = _find_meta(path.name)
    sha_ok  = (meta.get("sha256") == sha256) if meta else None

    # Intentar abrir (SQLite .gz y, con MRD_BACKUP_KEY, tambien .enc)
    db_ok   = None
    err_msg = None
    name    = path.name.lower()
    if ".enc" in name and not _get_config().get("encrypt_key"):
        err_msg = "Copia cifrada: sin MRD_BACKUP_KEY no se puede comprobar el contenido"
    else:
        try:
            raw = path.read_bytes()
            if ".enc" in name:
                raw = _decrypt_data(raw, _get_config()["encrypt_key"])
            if ".gz" in name:
                raw = gzip.decompress(raw)
            if ".sql" not in name:
                # SQLite: verificar magic bytes
                db_ok = raw[:16] == b"SQLite format 3\x00"
        except Exception as exc:
            db_ok   = False
            err_msg = str(exc)

    elapsed = round((time.perf_counter() - t0) * 1000)
    return {
        "ok":         (sha_ok is not False) and (db_ok is not False),
        "path":       str(path),
        "sha256":     sha256,
        "sha256_match": sha_ok,
        "db_readable": db_ok,
        "error":      err_msg,
        "size_bytes": path.stat().st_size,
        "elapsed_ms": elapsed,
    }


# ─── Restaurar ────────────────────────────────────────────────────────────────
def restore_backup(
    backup_path: str,
    target_db_path: str = None,
    dry_run: bool = False,
) -> dict:
    """
    Restaura un backup SQLite.
    dry_run=True: solo verifica sin restaurar.
    Antes de restaurar hace un backup automático del estado actual.
    """
    path = Path(backup_path)
    if not path.exists():
        return {"ok": False, "error": "Fichero no encontrado"}

    # Verificar integridad primero
    ver = verify_backup(backup_path)
    if not ver["ok"]:
        return {"ok": False, "error": f"Integridad fallida: {ver.get('error')}", "verify": ver}

    if dry_run:
        return {"ok": True, "dry_run": True, "verify": ver, "message": "Verificación OK. Usa dry_run=False para restaurar."}

    from config import DATABASE_URL
    if not DATABASE_URL.startswith("sqlite"):
        return {"ok": False, "error": "Restauración automática solo disponible para SQLite."}

    db_path = Path(str(DATABASE_URL).replace("sqlite:///", "").replace("sqlite://", ""))
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path
    if target_db_path:
        db_path = Path(target_db_path)

    t0 = time.perf_counter()

    # Backup de seguridad del estado actual
    pre_bk = create_backup(tipo="pre_migrate", label="pre_restore")

    with _backup_lock:
        try:
            # Descomprimir
            raw = path.read_bytes()
            name = path.name.lower()
            if ".enc" in name:
                cfg = _get_config()
                key = cfg.get("encrypt_key", "")
                if not key:
                    return {"ok": False, "error": "Se requiere MRD_BACKUP_KEY para descifrar"}
                raw = _decrypt_data(raw, key)
            if ".gz" in name:
                raw = gzip.decompress(raw)

            # Verificar magic SQLite
            if raw[:16] != b"SQLite format 3\x00":
                return {"ok": False, "error": "El fichero no es una base de datos SQLite válida"}

            # Escribir
            db_path.parent.mkdir(parents=True, exist_ok=True)
            db_path.write_bytes(raw)

            # Restaurar fotos de herramientas/EPI si el backup las incluye.
            # Fallo aquí no debe invalidar la restauración de la BD, que ya
            # se completó y es la parte crítica.
            photos_result = None
            photos_archive = _photos_archive_path(_backup_group_key(path.name), path.parent)
            if photos_archive.exists():
                try:
                    photos_result = _restore_photos(photos_archive)
                except Exception as exc:
                    logger.warning("No se pudieron restaurar las fotos del backup: %s", exc)

            elapsed = round((time.perf_counter() - t0) * 1000)
            logger.info("Restaurado: %s → %s (%d ms)", path.name, db_path, elapsed)
            return {
                "ok":         True,
                "restored_to": str(db_path),
                "from_backup": path.name,
                "pre_backup":  pre_bk.get("filename"),
                "elapsed_ms":  elapsed,
                "photos_restored": photos_result.get("restored_files") if photos_result else 0,
            }
        except Exception as exc:
            logger.error("Error restaurando: %s", exc)
            return {"ok": False, "error": str(exc)}


# ─── Historial ────────────────────────────────────────────────────────────────
_META_FILE = BACKUPS_DIR / "backup_history.json"
# _save_meta() consulta el historial mientras conserva este bloqueo. Debe ser
# reentrante para no bloquear el mismo hilo indefinidamente.
_meta_lock = RLock()


def _load_history() -> list:
    with _meta_lock:
        try:
            return json.loads(_META_FILE.read_text()) if _META_FILE.exists() else []
        except Exception:
            return []


def _save_meta(meta: dict):
    with _meta_lock:
        history = _load_history()
        history.append(meta)
        try:
            _META_FILE.write_text(json.dumps(history, ensure_ascii=False, indent=2))
        except Exception as exc:
            logger.warning("No se pudo guardar historial de backup: %s", exc)


def _find_meta(filename: str) -> dict:
    for m in reversed(_load_history()):
        if m.get("filename") == filename:
            return m
    return {}


def get_history(limit: int = 50) -> list:
    """Devuelve el historial de backups (más recientes primero)."""
    history = _load_history()
    # Verificar que los archivos aún existen
    result = []
    for m in reversed(history[-200:]):
        m2 = dict(m)
        m2["exists"] = Path(m.get("path", "")).exists()
        result.append(m2)
    return result[:limit]


# ─── Limpieza automática ──────────────────────────────────────────────────────
def cleanup_old_backups() -> dict:
    """
    Elimina backups antiguos según política de retención.
    Retorna {deleted, freed_bytes}.
    """
    cfg     = _get_config()
    deleted = 0
    freed   = 0

    policies = {
        "daily":      cfg["retention_daily"],
        "weekly":     cfg["retention_weekly"],
        "monthly":    cfg["retention_monthly"],
        "pre_update": cfg["retention_pre_action"],
        "pre_import": cfg["retention_pre_action"],
        "pre_migrate":cfg["retention_pre_action"],
        "manual":     30,  # guardar 30 manuales
    }

    for tipo, keep in policies.items():
        subdir = BACKUPS_DIR / tipo
        if not subdir.exists():
            continue

        # Agrupar cada backup con su .photos.tar.gz hermano (si existe) para
        # que la retención cuente copias de seguridad completas, no ficheros
        # sueltos: de lo contrario "keep" ficheros equivale a la mitad de
        # backups reales una vez hay fotos, y una pareja puede partirse por
        # el corte dejando una BD sin fotos o unas fotos sin su BD.
        groups: dict = {}
        for f in subdir.glob("*"):
            groups.setdefault(_backup_group_key(f.name), []).append(f)

        ordered_groups = sorted(
            groups.values(),
            key=lambda group: max(f.stat().st_mtime for f in group),
            reverse=True,
        )
        for group in ordered_groups[keep:]:
            for old in group:
                try:
                    size = old.stat().st_size
                    old.unlink()
                    freed   += size
                    deleted += 1
                    logger.info("Backup eliminado: %s", old.name)
                except Exception:
                    pass

    return {"deleted": deleted, "freed_bytes": freed, "freed_mb": round(freed / 1024**2, 2)}


# ─── SHA-256 ──────────────────────────────────────────────────────────────────
def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ─── Status general ──────────────────────────────────────────────────────────
def get_backup_status() -> dict:
    """Estado general del sistema de backups."""
    cfg     = _get_config()
    history = get_history(100)

    last_ok = next((b for b in history if b.get("tipo") in ("daily","weekly","monthly") and b.get("exists")), None)

    total_size = sum(
        f.stat().st_size
        for f in BACKUPS_DIR.rglob("*")
        if f.is_file() and f.name != "backup_history.json"
    )

    counts_by_type: dict = {}
    for b in history:
        t = b.get("tipo", "?")
        counts_by_type[t] = counts_by_type.get(t, 0) + 1

    return {
        "backup_dir":     cfg["backup_dir"],
        "total_backups":  len(history),
        "total_size_mb":  round(total_size / 1024**2, 2),
        "max_size_mb":    cfg["max_size_mb"],
        "last_backup":    last_ok,
        "counts_by_type": counts_by_type,
        "retention": {
            "daily":      cfg["retention_daily"],
            "weekly":     cfg["retention_weekly"],
            "monthly":    cfg["retention_monthly"],
            "pre_action": cfg["retention_pre_action"],
        },
        "encrypt_enabled": cfg["encrypt"],
        "externo": externo_estado(),
        "ensayo": ensayo_estado(),
        "checked_at":     datetime.utcnow().isoformat(timespec="seconds"),
    }


# ─── Programación automática ────────────────────────────────────────────────
_scheduler_started = False
_scheduler_lock = Lock()


def run_scheduled_backups(now: datetime = None) -> dict:
    """Crea las copias que falten en el día, semana y mes actuales."""
    now = now or datetime.utcnow()
    history = [
        item for item in _load_history()
        if item.get("tipo") in ("daily", "weekly", "monthly")
        and Path(item.get("path", "")).exists()
    ]

    def _period_exists(tipo: str) -> bool:
        for item in history:
            if item.get("tipo") != tipo:
                continue
            try:
                created = datetime.fromisoformat(item["created_at"])
            except (KeyError, TypeError, ValueError):
                continue
            if tipo == "daily" and created.date() == now.date():
                return True
            if tipo == "weekly" and created.isocalendar()[:2] == now.isocalendar()[:2]:
                return True
            if tipo == "monthly" and (created.year, created.month) == (now.year, now.month):
                return True
        return False

    result = {"created": [], "skipped": [], "errors": []}
    for tipo in ("daily", "weekly", "monthly"):
        if _period_exists(tipo):
            result["skipped"].append(tipo)
            continue
        backup = create_backup(tipo=tipo, label="automatico")
        if backup.get("ok"):
            result["created"].append(tipo)
            history.append(backup)
        else:
            result["errors"].append({"tipo": tipo, "error": backup.get("error", "desconocido")})

    result["cleanup"] = cleanup_old_backups()
    _externo_tras_programados(result)
    return result


def start_scheduler() -> bool:
    """Arranca una única comprobación periódica de backups en segundo plano."""
    global _scheduler_started
    with _scheduler_lock:
        if _scheduler_started:
            return False
        _scheduler_started = True

    initial_delay = max(5, int(os.getenv("MRD_BACKUP_INITIAL_DELAY_SECONDS", "90")))
    interval = max(60, int(os.getenv("MRD_BACKUP_CHECK_SECONDS", "3600")))

    def _worker():
        time.sleep(initial_delay)
        while True:
            try:
                outcome = run_scheduled_backups()
                logger.info("Backups automáticos: %s", outcome)
            except Exception as exc:
                logger.exception("Error en scheduler de backups: %s", exc)
            time.sleep(interval)

    Thread(target=_worker, daemon=True, name="backup_scheduler").start()
    return True


# ─── Ensayo de restauración (2.7.69) ─────────────────────────────────────────
# Una copia solo vale si se puede restaurar. El ensayo coge la última copia,
# la restaura en un fichero aparte (nunca toca la base de datos real), comprueba
# su integridad y cuadra los recuentos de las tablas principales con el programa.
ENSAYO_CFG = BASE_DIR / "config" / "ensayo_restauracion.json"
ENSAYO_TABLAS = ["herramientas", "trabajadores", "movimientos", "ubicaciones", "albaranes_salida", "materiales",
                 "stock_epi", "epis_individuales", "usuarios", "maquinaria", "obras"]
ENSAYO_TABLAS_CLAVE = ("herramientas", "trabajadores", "movimientos")
ENSAYO_MAX_HORAS = 36
ENSAYO_CADA_DIAS = 7


def _ensayo_leer() -> dict:
    try:
        return json.loads(ENSAYO_CFG.read_text(encoding="utf-8")) if ENSAYO_CFG.exists() else {}
    except Exception:
        return {}


def _ensayo_escribir(data: dict) -> None:
    ENSAYO_CFG.parent.mkdir(parents=True, exist_ok=True)
    ENSAYO_CFG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _ultimo_backup_path() -> Path | None:
    """La copia más reciente de la base de datos (según el historial; si no, la más nueva en disco)."""
    for m in get_history(200):
        nombre = str(m.get("filename") or "")
        if m.get("exists") and m.get("tipo") in ("daily", "weekly", "monthly", "manual") and re.search(r"\.db(\.gz)?(\.enc)?$", nombre):
            return Path(m["path"])
    cands = [f for f in BACKUPS_DIR.rglob("*") if f.is_file() and re.search(r"\.db(\.gz)?(\.enc)?$", f.name)]
    return max(cands, key=lambda f: f.stat().st_mtime) if cands else None


def _leer_backup_sqlite(path: Path) -> bytes:
    raw = path.read_bytes()
    name = path.name.lower()
    if ".enc" in name:
        key = _get_config().get("encrypt_key", "")
        if not key:
            raise ValueError("Se requiere MRD_BACKUP_KEY para descifrar la copia")
        raw = _decrypt_data(raw, key)
    if ".gz" in name:
        raw = gzip.decompress(raw)
    if raw[:16] != b"SQLite format 3\x00":
        raise ValueError("El fichero no es una base de datos SQLite válida")
    return raw


def _conteos_sqlite(con) -> dict:
    existentes = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    return {t: int(con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]) for t in ENSAYO_TABLAS if t in existentes}


def _conteos_actuales() -> dict:
    from config import DATABASE_URL
    if not str(DATABASE_URL).startswith("sqlite"):
        return {}
    db_path = Path(str(DATABASE_URL).replace("sqlite:///", "").replace("sqlite://", ""))
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path
    if not db_path.exists():
        return {}
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        return _conteos_sqlite(con)
    finally:
        con.close()


def ensayo_restauracion(backup_path: str | None = None) -> dict:
    """Restaura la última copia en un fichero temporal y comprueba que abre y cuadra."""
    import tempfile
    t0 = time.perf_counter()
    ahora = datetime.now()
    path = Path(backup_path) if backup_path else _ultimo_backup_path()
    res = {"ok": False, "fecha": ahora.strftime("%d/%m/%Y %H:%M"), "fecha_iso": ahora.isoformat(timespec="seconds"),
           "archivo": path.name if path else "", "tamano_mb": 0.0, "antiguedad_horas": None, "integridad": "",
           "tablas": {}, "avisos": [], "error": "", "duracion_ms": 0}
    if path is None or not path.exists():
        res["error"] = "No hay ninguna copia de seguridad que ensayar"
    else:
        try:
            st = path.stat()
            res["tamano_mb"] = round(st.st_size / 1024 ** 2, 2)
            res["antiguedad_horas"] = round((ahora.timestamp() - st.st_mtime) / 3600, 1)
            raw = _leer_backup_sqlite(path)
            fd, tmp = tempfile.mkstemp(prefix="mrd_ensayo_", suffix=".db")
            with os.fdopen(fd, "wb") as fh:
                fh.write(raw)
            try:
                con = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True)
                try:
                    res["integridad"] = str(con.execute("PRAGMA integrity_check").fetchone()[0])
                    copia = _conteos_sqlite(con)
                finally:
                    con.close()
            finally:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
            actual = _conteos_actuales()
            for t, n in copia.items():
                res["tablas"][t] = {"copia": n, "actual": actual.get(t)}
            if res["integridad"] != "ok":
                res["avisos"].append(f"La copia tiene errores de integridad: {res['integridad'][:120]}")
            for t in ENSAYO_TABLAS_CLAVE:
                n, a = copia.get(t), actual.get(t)
                if n is None and t in actual:
                    res["avisos"].append(f"La copia no tiene la tabla {t}: parece incompleta")
                elif n is not None and a and n < a * 0.9:
                    res["avisos"].append(f"{t}: la copia tiene {n} y el programa {a}: parece incompleta")
            if res["antiguedad_horas"] is not None and res["antiguedad_horas"] > ENSAYO_MAX_HORAS:
                res["avisos"].append(f"La última copia tiene {res['antiguedad_horas']:.0f} horas: la copia diaria no está funcionando")
            res["ok"] = not res["avisos"]
        except Exception as exc:
            res["error"] = f"No se pudo restaurar la copia: {exc}"
    res["duracion_ms"] = round((time.perf_counter() - t0) * 1000)
    datos = _ensayo_leer()
    datos["ultimo"] = res
    _ensayo_escribir(datos)
    if not res["ok"]:
        _aviso_ensayo(res)
    logger.info("Ensayo de restauración %s: %s", "OK" if res["ok"] else "FALLIDO", res["archivo"] or res["error"])
    return res


def _aviso_ensayo(res: dict) -> None:
    """Aviso interno (uno al día) cuando el ensayo de restauración falla."""
    try:
        from database import SessionLocal as _SLe
        from models import Aviso as _Aviso
        db = _SLe()
        try:
            titulo = f"Ensayo de restauración fallido {datetime.now().strftime('%d/%m/%Y')}"
            if not db.query(_Aviso).filter(_Aviso.titulo == titulo).first():
                motivo = res.get("error") or "; ".join(res.get("avisos") or [])
                db.add(_Aviso(titulo=titulo, tipo="alerta", prioridad="alta", enlace="/backup",
                              mensaje=f"La última copia de seguridad ({res.get('archivo') or 'ninguna'}) no ha pasado el ensayo de restauración: {motivo}. "
                                      "Revisa la página de Copias de seguridad."))
                db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.warning("No se pudo crear el aviso del ensayo: %s", exc)


def ensayo_estado() -> dict:
    return _ensayo_leer().get("ultimo") or {}


def ensayo_automatico(now: datetime | None = None) -> dict | None:
    """Ensayo semanal automático: corre si el último tiene más de ENSAYO_CADA_DIAS días."""
    now = now or datetime.now()
    ultimo = ensayo_estado()
    try:
        ultima_fecha = datetime.fromisoformat(ultimo["fecha_iso"]) if ultimo.get("fecha_iso") else None
    except ValueError:
        ultima_fecha = None
    if ultima_fecha and (now - ultima_fecha) < timedelta(days=ENSAYO_CADA_DIAS):
        return None
    return ensayo_restauracion()
