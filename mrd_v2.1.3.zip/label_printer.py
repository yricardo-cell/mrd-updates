"""
Impresión de etiquetas ZPL y PDF - MRD TOOL CONTROL
Soporta Zebra ZT231 (38x25mm)
"""
import io
import sys
import os
from typing import List, Dict


def generar_zpl_herramienta(
    codigo: str,
    nombre: str,
    num_serie: str = "",
    marca: str = "",
    empresa: str = "MRD Estructuras"
) -> str:
    """
    Genera ZPL para etiqueta de 38x25mm en Zebra ZT231.
    Incluye código de barras Code128 y QR del código.
    """
    nombre_corto = nombre[:28] if len(nombre) > 28 else nombre
    serie_txt = f"S/N: {num_serie}" if num_serie else ""
    marca_txt = marca[:20] if marca else ""

    zpl = f"""^XA
^PW304
^LL200
^CI28
^FO10,5^A0N,18,18^FD{empresa}^FS
^FO10,25^A0N,22,22^FD{nombre_corto}^FS
^FO10,50^A0N,16,16^FD{marca_txt}^FS
^FO10,68^A0N,16,16^FD{serie_txt}^FS
^FO10,88^BY2,3.0,40^BCN,40,N,N,N^FD{codigo}^FS
^FO10,140^A0N,14,14^FD{codigo}^FS
^FO200,10^BQN,2,4^FDQA,{codigo}^FS
^XZ"""
    return zpl


def generar_zpl_lote(herramientas: List[Dict]) -> str:
    zpl_total = ""
    for h in herramientas:
        zpl_total += generar_zpl_herramienta(
            codigo=h.get("codigo", ""),
            nombre=h.get("nombre", ""),
            num_serie=h.get("num_serie", ""),
            marca=h.get("marca", ""),
        )
    return zpl_total


def _generar_barcode_png(codigo: str) -> bytes | None:
    """Genera imagen PNG de código de barras Code128 usando python-barcode."""
    try:
        _this_dir = os.path.dirname(os.path.abspath(__file__))
        if _this_dir in sys.path:
            sys.path.remove(_this_dir)
            import barcode as _bc
            from barcode.writer import ImageWriter
            sys.path.insert(0, _this_dir)
        else:
            import barcode as _bc
            from barcode.writer import ImageWriter

        code128 = _bc.get("code128", codigo, writer=ImageWriter())
        buf = io.BytesIO()
        code128.write(buf, options={
            "write_text": True,
            "text_distance": 3,
            "module_height": 10.0,
            "module_width": 0.8,
            "quiet_zone": 4.0,
            "font_size": 8,
            "dpi": 200,
        })
        return buf.getvalue()
    except Exception:
        return None


def generar_pdf_etiquetas(herramientas: List, empresa: str = "MRD Estructuras") -> bytes:
    """
    Genera PDF A4 con etiquetas en rejilla 2 columnas.
    Cada etiqueta muestra: empresa, nombre, código de barras Code128 + número, QR.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas
        from reportlab.lib import colors
        from reportlab.lib.utils import ImageReader
        import qrcode
        from PIL import Image

        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        w_page, h_page = A4

        # Dimensiones etiqueta (90x50mm — formato estándar impresora etiquetas)
        etiq_w = 90 * mm
        etiq_h = 50 * mm
        margin_x = 10 * mm
        margin_y = 10 * mm
        gap_x = 5 * mm
        gap_y = 4 * mm

        cols = 2
        x_positions = [margin_x, margin_x + etiq_w + gap_x]

        col = 0
        y = h_page - margin_y - etiq_h

        for idx, h in enumerate(herramientas):
            x = x_positions[col]

            # Fondo blanco + borde azul MRD
            c.setFillColor(colors.white)
            c.rect(x, y, etiq_w, etiq_h, fill=1, stroke=0)
            c.setStrokeColor(colors.HexColor("#1B4F8A"))
            c.setLineWidth(0.8)
            c.rect(x, y, etiq_w, etiq_h, fill=0, stroke=1)

            # Franja superior azul
            c.setFillColor(colors.HexColor("#1B4F8A"))
            c.rect(x, y + etiq_h - 9 * mm, etiq_w, 9 * mm, fill=1, stroke=0)

            # Empresa en franja
            c.setFillColor(colors.white)
            c.setFont("Helvetica-Bold", 7)
            c.drawString(x + 3 * mm, y + etiq_h - 6 * mm, empresa.upper())

            # QR (esquina superior derecha)
            codigo = h.codigo if hasattr(h, 'codigo') else h.get('codigo', '')
            qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=3, border=1)
            qr.add_data(codigo)
            qr.make(fit=True)
            qr_img = qr.make_image(fill_color="black", back_color="white")
            qr_buf = io.BytesIO()
            qr_img.save(qr_buf, format="PNG")
            qr_buf.seek(0)
            qr_size = 18 * mm
            c.drawImage(
                ImageReader(qr_buf),
                x + etiq_w - qr_size - 2 * mm,
                y + etiq_h - qr_size - 10 * mm,
                width=qr_size, height=qr_size
            )

            # Nombre herramienta
            nombre = h.nombre if hasattr(h, 'nombre') else h.get('nombre', '')
            nombre_corto = nombre[:32] if len(nombre) > 32 else nombre
            c.setFillColor(colors.black)
            c.setFont("Helvetica-Bold", 9)
            c.drawString(x + 3 * mm, y + etiq_h - 16 * mm, nombre_corto)

            # Marca (si existe)
            marca = h.marca if hasattr(h, 'marca') else h.get('marca', '')
            if marca:
                c.setFont("Helvetica", 7)
                c.setFillColor(colors.HexColor("#555555"))
                c.drawString(x + 3 * mm, y + etiq_h - 22 * mm, marca[:28])

            # Código de barras Code128
            barcode_png = _generar_barcode_png(codigo)
            if barcode_png:
                bc_buf = io.BytesIO(barcode_png)
                bc_w = 55 * mm
                bc_h = 14 * mm
                c.drawImage(ImageReader(bc_buf), x + 3 * mm, y + 3 * mm, width=bc_w, height=bc_h)
            else:
                c.setFont("Helvetica-Bold", 11)
                c.setFillColor(colors.HexColor("#E8600A"))
                c.drawString(x + 3 * mm, y + 8 * mm, codigo)

            col += 1
            if col >= cols:
                col = 0
                y -= (etiq_h + gap_y)
                if y < margin_y:
                    c.showPage()
                    y = h_page - margin_y - etiq_h

        c.save()
        return buffer.getvalue()

    except Exception as e:
        buffer = io.BytesIO()
        try:
            from reportlab.pdfgen import canvas
            from reportlab.lib.pagesizes import A4
            c = canvas.Canvas(buffer, pagesize=A4)
            c.drawString(100, 750, f"Error generando PDF: {str(e)}")
            c.save()
        except Exception:
            pass
        return buffer.getvalue()
