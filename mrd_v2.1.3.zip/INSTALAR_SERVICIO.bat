@echo off
title MRD TOOL CONTROL — Instalar Servicio Windows
color 0A
echo.
echo  =====================================================
echo   MRD TOOL CONTROL — Instalacion de Servicio Windows
echo  =====================================================
echo.
echo  Este script registra MRD Tool Control para que se
echo  inicie AUTOMATICAMENTE con Windows y se reinicie
echo  si el servidor se cae.
echo.
echo  Se necesitan permisos de Administrador.
echo.

:: Verificar que corremos como admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: Ejecuta este archivo como Administrador.
    echo  Haz clic derecho sobre INSTALAR_SERVICIO.bat
    echo  y selecciona "Ejecutar como administrador".
    echo.
    pause
    exit /b 1
)

set TASK_NAME=MRD Tool Control
set PS_SCRIPT="C:\mrd tool\mrd_tool_control\SERVICIO_MRD.ps1"
set COMANDO=powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NonInteractive -File %PS_SCRIPT%

:: Eliminar tarea anterior si existe
echo  Eliminando tarea anterior (si existe)...
schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1

:: Crear tarea en el Programador de Tareas Windows
echo  Registrando en Programador de Tareas de Windows...
schtasks /create ^
  /tn "%TASK_NAME%" ^
  /tr "%COMANDO%" ^
  /sc onlogon ^
  /rl highest ^
  /f ^
  /delay 0000:30

if %errorlevel% neq 0 (
    echo.
    echo  ERROR al registrar la tarea. Intentando con ONIDLE...
    schtasks /create ^
      /tn "%TASK_NAME%" ^
      /tr "%COMANDO%" ^
      /sc onstart ^
      /rl highest ^
      /f
)

if %errorlevel% equ 0 (
    echo.
    echo  =====================================================
    echo   OK: Servicio instalado correctamente.
    echo.
    echo   El servidor MRD se iniciara automaticamente
    echo   cada vez que inicies sesion en Windows.
    echo.
    echo   Si se cae, se reiniciara solo en 5 segundos.
    echo   Los logs se guardan en: logs\servicio_mrd.log
    echo  =====================================================
    echo.
    echo  Iniciando el servicio ahora...
    schtasks /run /tn "%TASK_NAME%"
    echo  Listo. Espera unos segundos y abre localhost:8000
) else (
    echo.
    echo  ERROR al instalar. Revisa que tienes permisos de Admin.
)

echo.
pause
