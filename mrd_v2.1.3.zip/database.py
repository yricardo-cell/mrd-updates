"""
MRD TOOL CONTROL — Base de Datos
Sprint 5.5 — v1.9.5-alpha
Soporte dual: SQLite (desarrollo/instalaciones pequeñas) + PostgreSQL (producción)
"""
import logging
import os
import time
from collections import deque
from datetime import datetime
from threading import Lock

from sqlalchemy import create_engine, event, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool, StaticPool

from config import DATABASE_URL

logger = logging.getLogger("mrd.database")

# ─── Detección de motor ────────────────────────────────────────────────────────
_IS_SQLITE     = DATABASE_URL.startswith("sqlite")
_IS_POSTGRESQL = DATABASE_URL.startswith("postgresql") or DATABASE_URL.startswith("postgres")

# ─── Monitor de rendimiento ───────────────────────────────────────────────────
SLOW_QUERY_MS   = int(os.getenv("MRD_SLOW_QUERY_MS", "200"))   # umbral en ms
_slow_queries   = deque(maxlen=100)                              # circular buffer
_query_stats    = {"total": 0, "slow": 0, "errors": 0}
_pool_events    = deque(maxlen=50)
_stats_lock     = Lock()


def _record_slow_query(statement: str, duration_ms: float):
    with _stats_lock:
        _query_stats["total"] += 1
        if duration_ms >= SLOW_QUERY_MS:
            _query_stats["slow"] += 1
            _slow_queries.append({
                "ts":       datetime.utcnow().isoformat(timespec="seconds"),
                "ms":       round(duration_ms, 1),
                "sql":      statement[:300].replace("\n", " "),
            })
            logger.warning("SLOW QUERY %.0fms: %.120s", duration_ms, statement)
        else:
            pass  # contar sin loggear


# ─── Crear engine ──────────────────────────────────────────────────────────────
def _build_engine():
    if _IS_SQLITE:
        eng = create_engine(
            DATABASE_URL,
            connect_args={"check_same_thread": False},
            echo=False,
            pool_pre_ping=True,
        )

        @event.listens_for(eng, "connect")
        def _sqlite_pragmas(dbapi_conn, _rec):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA cache_size=-64000")
            cur.execute("PRAGMA temp_store=MEMORY")
            cur.close()

        return eng

    elif _IS_POSTGRESQL:
        pool_size    = int(os.getenv("MRD_DB_POOL_SIZE",    "10"))
        max_overflow = int(os.getenv("MRD_DB_MAX_OVERFLOW", "20"))
        pool_timeout = int(os.getenv("MRD_DB_POOL_TIMEOUT", "30"))
        pool_recycle = int(os.getenv("MRD_DB_POOL_RECYCLE", "3600"))

        eng = create_engine(
            DATABASE_URL,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            pool_pre_ping=True,
            echo=False,
        )

        @event.listens_for(eng, "connect")
        def _pg_connect(dbapi_conn, _rec):
            with _stats_lock:
                _pool_events.append({
                    "ts":   datetime.utcnow().isoformat(timespec="seconds"),
                    "ev":   "connect",
                })

        @event.listens_for(eng, "close")
        def _pg_close(dbapi_conn, _rec):
            with _stats_lock:
                _pool_events.append({
                    "ts":   datetime.utcnow().isoformat(timespec="seconds"),
                    "ev":   "close",
                })

        return eng

    else:
        # Motor genérico (MySQL, etc.)
        return create_engine(DATABASE_URL, pool_pre_ping=True, echo=False)


engine = _build_engine()


# ─── Slow-query listener (todos los motores) ──────────────────────────────────
@event.listens_for(engine, "before_cursor_execute")
def _before_execute(conn, cursor, statement, parameters, context, executemany):
    conn.info.setdefault("query_start", time.perf_counter())


@event.listens_for(engine, "after_cursor_execute")
def _after_execute(conn, cursor, statement, parameters, context, executemany):
    t0 = conn.info.pop("query_start", None)
    if t0 is not None:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        _record_slow_query(statement, elapsed_ms)


@event.listens_for(engine, "handle_error")
def _on_error(exception_context):
    with _stats_lock:
        _query_stats["errors"] += 1
    logger.error("DB error: %s", exception_context.original_exception)


# ─── Sesiones ─────────────────────────────────────────────────────────────────
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ─── Estado del motor ─────────────────────────────────────────────────────────
def get_db_info() -> dict:
    """Información del motor activo (para el panel de administración)."""
    info = {
        "engine":       "PostgreSQL" if _IS_POSTGRESQL else ("SQLite" if _IS_SQLITE else "Otro"),
        "url_safe":     _safe_url(DATABASE_URL),
        "slow_query_ms": SLOW_QUERY_MS,
        "stats":         dict(_query_stats),
        "slow_queries":  list(_slow_queries)[-10:],   # últimas 10
    }
    if _IS_POSTGRESQL:
        try:
            pool = engine.pool
            info["pool"] = {
                "size":        pool.size(),
                "checked_in":  pool.checkedin(),
                "checked_out": pool.checkedout(),
                "overflow":    pool.overflow(),
            }
        except Exception:
            info["pool"] = {}
    return info


def _safe_url(url: str) -> str:
    """Oculta usuario/contraseña de la URL para mostrarla en UI."""
    try:
        from urllib.parse import urlparse, urlunparse
        p = urlparse(url)
        safe = p._replace(netloc=f"***:***@{p.hostname}" + (f":{p.port}" if p.port else ""))
        return urlunparse(safe)
    except Exception:
        return url.split("@")[-1] if "@" in url else url


def check_connection() -> dict:
    """Comprueba conectividad y latencia."""
    t0 = time.perf_counter()
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        ms = round((time.perf_counter() - t0) * 1000, 1)
        return {"ok": True, "ms": ms}
    except Exception as exc:
        return {"ok": False, "ms": None, "error": str(exc)}


def check_integrity() -> dict:
    """Verificación de integridad (SQLite) o validación básica (PostgreSQL)."""
    results = []
    try:
        with engine.connect() as conn:
            if _IS_SQLITE:
                rows = conn.execute(text("PRAGMA integrity_check")).fetchall()
                ok = all(r[0] == "ok" for r in rows)
                results = [r[0] for r in rows]
                return {"ok": ok, "checks": results, "engine": "sqlite"}
            elif _IS_POSTGRESQL:
                # Verificar tablas y foreign keys
                tbls = conn.execute(text(
                    "SELECT tablename FROM pg_tables WHERE schemaname='public'"
                )).fetchall()
                tables = [r[0] for r in tbls]
                return {"ok": True, "tables": tables, "count": len(tables), "engine": "postgresql"}
            else:
                return {"ok": True, "engine": "other"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def reset_stats():
    """Reinicia contadores de rendimiento."""
    with _stats_lock:
        _query_stats.update({"total": 0, "slow": 0, "errors": 0})
        _slow_queries.clear()
        _pool_events.clear()


# ─── Migraciones incrementales (SQLite) ───────────────────────────────────────
def apply_migrations():
    """
    Migraciones incrementales para SQLite.
    Para PostgreSQL usa Alembic (run_alembic_upgrade).
    """
    if not _IS_SQLITE:
        logger.info("apply_migrations() saltada: motor no es SQLite. Usar Alembic.")
        return

    migrations = [
        # usuarios
        ("usuarios", "telefono",           "VARCHAR(20)"),
        ("usuarios", "delegacion_id",      "INTEGER"),
        ("usuarios", "avatar",             "VARCHAR(255)"),
        ("usuarios", "must_change_password","BOOLEAN DEFAULT 0"),
        # trabajadores
        ("trabajadores", "codigo",         "VARCHAR(50)"),
        ("trabajadores", "apellidos",      "VARCHAR(100)"),
        ("trabajadores", "empresa",        "VARCHAR(100)"),
        ("trabajadores", "cargo",          "VARCHAR(100)"),
        ("trabajadores", "departamento",   "VARCHAR(100)"),
        ("trabajadores", "delegacion_id",  "INTEGER"),
        ("trabajadores", "foto",           "VARCHAR(255)"),
        ("trabajadores", "especialidad",   "VARCHAR(100)"),
        ("trabajadores", "categoria_profesional", "VARCHAR(100)"),
        ("trabajadores", "obra_id",        "INTEGER"),
        ("trabajadores", "observaciones",  "TEXT"),
        ("trabajadores", "updated_at",     "DATETIME"),
        # almacenes
        ("almacenes", "codigo",            "VARCHAR(50)"),
        ("almacenes", "responsable",       "VARCHAR(100)"),
        ("almacenes", "delegacion_id",     "INTEGER"),
        # obras
        ("obras", "responsable_id",        "INTEGER"),
        ("obras", "presupuesto",           "REAL"),
        ("obras", "coste_acumulado",       "REAL DEFAULT 0"),
        ("obras", "delegacion_id",         "INTEGER"),
        ("obras", "observaciones",         "TEXT"),
        ("obras", "updated_at",            "DATETIME"),
        # vehiculos
        ("vehiculos", "tipo",              "VARCHAR(50)"),
        ("vehiculos", "anio",              "INTEGER"),
        ("vehiculos", "conductor_id",      "INTEGER"),
        ("vehiculos", "delegacion_id",     "INTEGER"),
        ("vehiculos", "estado",            "VARCHAR(50) DEFAULT 'activo'"),
        ("vehiculos", "itv_hasta",         "DATE"),
        ("vehiculos", "seguro_hasta",      "DATE"),
        ("vehiculos", "kilometros",        "INTEGER DEFAULT 0"),
        ("vehiculos", "foto",              "VARCHAR(255)"),
        ("vehiculos", "observaciones",     "TEXT"),
        ("vehiculos", "updated_at",        "DATETIME"),
        # herramientas
        ("herramientas", "descripcion",    "TEXT"),
        ("herramientas", "subcategoria",   "VARCHAR(100)"),
        ("herramientas", "familia",        "VARCHAR(100)"),
        ("herramientas", "fabricante",     "VARCHAR(100)"),
        ("herramientas", "activo_fijo",    "VARCHAR(100)"),
        ("herramientas", "peso",           "REAL"),
        ("herramientas", "color",          "VARCHAR(50)"),
        ("herramientas", "potencia",       "VARCHAR(50)"),
        ("herramientas", "voltaje",        "VARCHAR(50)"),
        ("herramientas", "capacidad",      "VARCHAR(50)"),
        ("herramientas", "ubicacion_texto","VARCHAR(200)"),
        ("herramientas", "almacen_id",     "INTEGER"),
        ("herramientas", "obra_id",        "INTEGER"),
        ("herramientas", "vehiculo_id",    "INTEGER"),
        ("herramientas", "responsable_id", "INTEGER"),
        ("herramientas", "delegacion_id",  "INTEGER"),
        ("herramientas", "proveedor_id",   "INTEGER"),
        ("herramientas", "proveedor_texto","VARCHAR(200)"),
        ("herramientas", "precio_compra",  "REAL"),
        ("herramientas", "valor_actual",   "REAL"),
        ("herramientas", "numero_factura", "VARCHAR(100)"),
        ("herramientas", "garantia_hasta", "DATE"),
        ("herramientas", "vida_util_anos", "INTEGER"),
        ("herramientas", "fecha_ultimo_mantenimiento",  "DATE"),
        ("herramientas", "fecha_proximo_mantenimiento", "DATE"),
        ("herramientas", "intervalo_mantenimiento_dias","INTEGER"),
        ("herramientas", "dimensiones",    "VARCHAR(100)"),
        # movimientos
        ("movimientos", "vehiculo_id",     "INTEGER"),
        ("movimientos", "almacen_id",      "INTEGER"),
        ("movimientos", "motivo",          "VARCHAR(200)"),
        ("movimientos", "firma_nombre",    "VARCHAR(100)"),
        ("movimientos", "firma_datos",     "TEXT"),
        ("movimientos", "created_at",      "DATETIME"),
        # proveedores
        ("proveedores", "notas",           "TEXT"),
        # Sprint 4.1 - automatizaciones
        ("automatizaciones", "descripcion",        "TEXT"),
        ("automatizaciones", "condiciones_json",   "TEXT"),
        ("automatizaciones", "acciones_json",      "TEXT"),
        ("automatizaciones", "disparador",         "VARCHAR(50)"),
        ("automatizaciones", "activa",             "BOOLEAN DEFAULT 1"),
        ("automatizaciones", "intervalo_minutos",  "INTEGER"),
        ("automatizaciones", "proxima_ejecucion",  "DATETIME"),
        ("automatizaciones", "ultima_ejecucion",   "DATETIME"),
        ("automatizaciones", "total_ejecuciones",  "INTEGER DEFAULT 0"),
        ("automatizaciones", "total_errores",      "INTEGER DEFAULT 0"),
        ("automatizaciones", "estado",             "VARCHAR(30) DEFAULT 'activa'"),
        ("automatizaciones", "creado_por_id",      "INTEGER"),
        ("automatizaciones", "creado_en",          "DATETIME"),
        ("automatizaciones", "actualizado_en",     "DATETIME"),
        # Sprint 4.1 - ejecuciones_automatizacion
        ("ejecuciones_automatizacion", "modo",               "VARCHAR(20) DEFAULT 'auto'"),
        ("ejecuciones_automatizacion", "resultado",          "VARCHAR(20)"),
        ("ejecuciones_automatizacion", "acciones_ejecutadas","INTEGER DEFAULT 0"),
        ("ejecuciones_automatizacion", "items_afectados",    "INTEGER DEFAULT 0"),
        ("ejecuciones_automatizacion", "detalle",            "TEXT"),
        ("ejecuciones_automatizacion", "error_msg",          "TEXT"),
        ("ejecuciones_automatizacion", "duracion_ms",        "INTEGER"),
        ("ejecuciones_automatizacion", "usuario_id",         "INTEGER"),
        # Sprint 4.1 - avisos
        ("avisos", "mensaje",            "TEXT"),
        ("avisos", "tipo",               "VARCHAR(50) DEFAULT 'sistema'"),
        ("avisos", "automatizacion_id",  "INTEGER"),
        ("avisos", "usuario_id",         "INTEGER"),
        ("avisos", "enlace",             "VARCHAR(500)"),
        ("avisos", "datos",              "TEXT"),
        ("avisos", "leido_en",           "DATETIME"),
        # Sprint 4.3 - canales_notificacion
        ("canales_notificacion", "activo",            "BOOLEAN DEFAULT 1"),
        ("canales_notificacion", "prioridad_minima",  "VARCHAR(20) DEFAULT 'media'"),
        ("canales_notificacion", "config",            "TEXT"),
        ("canales_notificacion", "total_enviados",    "INTEGER DEFAULT 0"),
        ("canales_notificacion", "total_errores",     "INTEGER DEFAULT 0"),
        ("canales_notificacion", "ultimo_envio",      "DATETIME"),
        # Sprint 4.3 - notificaciones_enviadas
        ("notificaciones_enviadas", "aviso_id",          "INTEGER"),
        ("notificaciones_enviadas", "resultado",         "VARCHAR(20) DEFAULT 'ok'"),
        ("notificaciones_enviadas", "detalle",           "TEXT"),
        ("notificaciones_enviadas", "reintentos",        "INTEGER DEFAULT 0"),
        ("notificaciones_enviadas", "proximo_reintento", "DATETIME"),
        ("notificaciones_enviadas", "aviso_titulo",      "VARCHAR(255)"),
        ("notificaciones_enviadas", "aviso_prioridad",   "VARCHAR(30)"),
        # Sprint 4.9 - mantenimientos_programados
        ("mantenimientos_programados", "codigo_activo",    "VARCHAR(80)"),
        ("mantenimientos_programados", "tipo",             "VARCHAR(30) DEFAULT 'preventivo'"),
        ("mantenimientos_programados", "descripcion",      "TEXT"),
        ("mantenimientos_programados", "intervalo_dias",   "INTEGER"),
        ("mantenimientos_programados", "coste_estimado",   "REAL"),
        ("mantenimientos_programados", "coste_real",       "REAL"),
        ("mantenimientos_programados", "proveedor_texto",  "VARCHAR(200)"),
        ("mantenimientos_programados", "score_riesgo",     "INTEGER"),
        ("mantenimientos_programados", "notas",            "TEXT"),
        ("mantenimientos_programados", "creado_por_id",    "INTEGER"),
        ("mantenimientos_programados", "actualizado_en",   "DATETIME"),
    ]

    with engine.connect() as conn:
        for table, col, typedef in migrations:
            try:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {typedef}"))
                conn.commit()
            except Exception:
                pass

        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_herr_activa ON herramientas(activa)",
            "CREATE INDEX IF NOT EXISTS idx_herr_estado ON herramientas(estado)",
            "CREATE INDEX IF NOT EXISTS idx_herr_activa_estado ON herramientas(activa, estado)",
            "CREATE INDEX IF NOT EXISTS idx_herr_categoria ON herramientas(categoria)",
            "CREATE INDEX IF NOT EXISTS idx_mov_fecha ON movimientos(fecha)",
            "CREATE INDEX IF NOT EXISTS idx_mov_herramienta ON movimientos(herramienta_id)",
        ]
        for idx_sql in indexes:
            try:
                conn.execute(text(idx_sql))
                conn.commit()
            except Exception:
                pass

        for src, dst, tbl in [
            ("ubicacion", "ubicacion_texto", "herramientas"),
            ("precio",    "precio_compra",   "herramientas"),
            ("proveedor", "proveedor_texto",  "herramientas"),
        ]:
            try:
                conn.execute(text(
                    f"UPDATE {tbl} SET {dst} = {src} "
                    f"WHERE {dst} IS NULL AND {src} IS NOT NULL"
                ))
                conn.commit()
            except Exception:
                pass
