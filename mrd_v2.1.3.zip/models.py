"""
Modelos SQLAlchemy V2 - MRD TOOL CONTROL
Basado en especificaciones completas Vol I + Tomo III
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, Boolean,
    DateTime, Text, ForeignKey, Date, Index, UniqueConstraint, text
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


# ─── Configuración y Metadatos ───────────────────────────────────────────────

class Delegacion(Base):
    __tablename__ = "delegaciones"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(20), unique=True, index=True, nullable=False)
    nombre = Column(String(100), nullable=False)
    direccion = Column(String(255), nullable=True)
    telefono = Column(String(20), nullable=True)
    email = Column(String(100), nullable=True)
    responsable = Column(String(100), nullable=True)
    activa = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())


class ConfigSistema(Base):
    __tablename__ = "config_sistema"

    id = Column(Integer, primary_key=True)
    clave = Column(String(100), unique=True, nullable=False, index=True)
    valor = Column(Text, nullable=True)
    tipo = Column(String(20), default="string")  # string, int, bool, json, color
    descripcion = Column(String(255), nullable=True)
    modulo = Column(String(50), nullable=True)
    updated_at = Column(DateTime, onupdate=func.now())
    updated_by_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)


class Categoria(Base):
    __tablename__ = "categorias"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    tipo = Column(String(50), nullable=False, index=True)  # herramienta, material, vehiculo
    descripcion = Column(Text, nullable=True)
    icono = Column(String(50), nullable=True)
    color = Column(String(20), nullable=True)
    activa = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())


class Proveedor(Base):
    __tablename__ = "proveedores"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(50), unique=True, index=True, nullable=True)
    nombre = Column(String(200), nullable=False)
    cif = Column(String(20), nullable=True)
    direccion = Column(String(255), nullable=True)
    telefono = Column(String(20), nullable=True)
    email = Column(String(100), nullable=True)
    web = Column(String(255), nullable=True)
    contacto = Column(String(100), nullable=True)
    observaciones = Column(Text, nullable=True)
    activo = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())

    herramientas = relationship("Herramienta", back_populates="proveedor_rel",
                                foreign_keys="Herramienta.proveedor_id")
    reparaciones = relationship("Reparacion", back_populates="proveedor",
                                foreign_keys="Reparacion.proveedor_id")


# ─── Usuarios ────────────────────────────────────────────────────────────────

class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    nombre = Column(String(100), nullable=False)
    email = Column(String(100), nullable=True)
    telefono = Column(String(20), nullable=True)
    rol = Column(String(20), default="consulta", index=True)
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    activo = Column(Boolean, default=True)
    avatar = Column(String(255), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    last_login = Column(DateTime, nullable=True)
    must_change_password = Column(Boolean, default=True, nullable=False, server_default='1')

    movimientos = relationship("Movimiento", back_populates="usuario",
                               foreign_keys="Movimiento.usuario_id")
    auditorias = relationship("AuditoriaLog", back_populates="usuario",
                              foreign_keys="AuditoriaLog.usuario_id")


# ─── Trabajadores ────────────────────────────────────────────────────────────

class Trabajador(Base):
    __tablename__ = "trabajadores"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(50), unique=True, index=True, nullable=True)
    nombre = Column(String(100), nullable=False)
    apellidos = Column(String(100), nullable=True, default="")
    dni = Column(String(20), nullable=True)
    telefono = Column(String(20), nullable=True)
    email = Column(String(100), nullable=True)
    empresa = Column(String(100), nullable=True, default="MRD Estructuras")
    cargo = Column(String(100), nullable=True)
    departamento = Column(String(100), nullable=True)
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    activo = Column(Boolean, default=True)
    foto = Column(String(255), nullable=True)
    observaciones = Column(Text, nullable=True)
    portal_token = Column(String(64), nullable=True, unique=True, index=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

    herramientas = relationship("Herramienta", back_populates="responsable",
                                foreign_keys="Herramienta.responsable_id")
    movimientos = relationship("Movimiento", back_populates="trabajador",
                               foreign_keys="Movimiento.trabajador_id")

    @property
    def nombre_completo(self):
        return f"{self.nombre} {self.apellidos or ''}".strip()


# ─── Almacenes y Ubicaciones ─────────────────────────────────────────────────

class Almacen(Base):
    __tablename__ = "almacenes"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(50), unique=True, index=True, nullable=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(Text, nullable=True)
    direccion = Column(String(255), nullable=True)
    responsable = Column(String(100), nullable=True)
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    foto = Column(String(255), nullable=True)
    activo = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())

    herramientas = relationship("Herramienta", back_populates="almacen",
                                foreign_keys="Herramienta.almacen_id")
    materiales  = relationship("Material",   back_populates="almacen",
                                foreign_keys="Material.almacen_id")
    ubicaciones = relationship("Ubicacion",  back_populates="almacen",
                                cascade="all, delete-orphan",
                                order_by="Ubicacion.nombre")


class Ubicacion(Base):
    """Sub-ubicación dentro de un almacén: estantería, cajón, zona, vehículo…"""
    __tablename__ = "ubicaciones"

    id          = Column(Integer, primary_key=True, index=True)
    almacen_id  = Column(Integer, ForeignKey("almacenes.id"), nullable=False, index=True)
    nombre      = Column(String(100), nullable=False)          # "Estantería A"
    codigo      = Column(String(50),  nullable=True, unique=True, index=True)
    descripcion = Column(Text, nullable=True)
    activo      = Column(Boolean, default=True)
    created_at  = Column(DateTime, server_default=func.now())

    almacen     = relationship("Almacen",    back_populates="ubicaciones")
    herramientas= relationship("Herramienta",back_populates="ubicacion",
                                foreign_keys="Herramienta.ubicacion_id")
    materiales  = relationship("Material",   back_populates="ubicacion",
                                foreign_keys="Material.ubicacion_id")


# ─── Obras ───────────────────────────────────────────────────────────────────

class Obra(Base):
    __tablename__ = "obras"

    id = Column(Integer, primary_key=True, index=True)
    numero = Column(String(50), unique=True, index=True, nullable=False)
    nombre = Column(String(200), nullable=False)
    cliente = Column(String(200), nullable=True)
    direccion = Column(String(255), nullable=True)
    responsable = Column(String(100), nullable=True)
    responsable_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    estado = Column(String(50), default="activa", index=True)
    fecha_inicio = Column(Date, nullable=True)
    fecha_fin = Column(Date, nullable=True)
    presupuesto = Column(Float, nullable=True)
    coste_acumulado = Column(Float, default=0.0)
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    observaciones = Column(Text, nullable=True)
    activa = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

    herramientas = relationship("Herramienta", back_populates="obra",
                                foreign_keys="Herramienta.obra_id")
    movimientos = relationship("Movimiento", back_populates="obra",
                               foreign_keys="Movimiento.obra_id")
    incidencias = relationship("Incidencia", back_populates="obra",
                               foreign_keys="Incidencia.obra_id")


# ─── Vehículos ───────────────────────────────────────────────────────────────

class Vehiculo(Base):
    __tablename__ = "vehiculos"

    id = Column(Integer, primary_key=True, index=True)
    matricula = Column(String(20), unique=True, index=True, nullable=False)
    marca = Column(String(50), nullable=True)
    modelo = Column(String(50), nullable=True)
    tipo = Column(String(50), nullable=True, default="furgoneta")  # furgoneta, camion, maquinaria
    anio = Column(Integer, nullable=True)
    descripcion = Column(String(200), nullable=True)
    conductor_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    estado = Column(String(50), default="activo", index=True)
    itv_hasta = Column(Date, nullable=True)
    seguro_hasta = Column(Date, nullable=True)
    proxima_revision = Column(Date, nullable=True)
    compania_seguro = Column(String(100), nullable=True)
    num_poliza = Column(String(100), nullable=True)
    kilometros = Column(Integer, default=0)
    foto = Column(String(255), nullable=True)
    observaciones = Column(Text, nullable=True)
    activo = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

    herramientas = relationship("Herramienta", back_populates="vehiculo",
                                foreign_keys="Herramienta.vehiculo_id")
    incidencias = relationship("Incidencia", back_populates="vehiculo",
                               foreign_keys="Incidencia.vehiculo_id")


# ─── HERRAMIENTA (Modelo principal) ──────────────────────────────────────────

class Herramienta(Base):
    """
    Modelo central de MRD TOOL CONTROL.
    Tomo III - Módulo 1: Gestión de Herramientas.
    """
    __tablename__ = "herramientas"

    id = Column(Integer, primary_key=True, index=True)

    # ── Identificación ────────────────────────────────────────────────────────
    codigo = Column(String(50), unique=True, index=True, nullable=False)
    nombre = Column(String(200), nullable=False, index=True)
    descripcion = Column(Text, nullable=True)

    # ── Clasificación ─────────────────────────────────────────────────────────
    categoria = Column(String(100), nullable=True, default="Otro", index=True)
    subcategoria = Column(String(100), nullable=True)
    familia = Column(String(100), nullable=True)

    # ── Datos técnicos ────────────────────────────────────────────────────────
    marca = Column(String(100), nullable=True)
    modelo = Column(String(100), nullable=True)
    fabricante = Column(String(100), nullable=True)
    num_serie = Column(String(100), nullable=True, index=True)
    activo_fijo = Column(String(100), nullable=True)
    dimensiones = Column(String(100), nullable=True)   # LxAxH cm o libre
    peso = Column(Float, nullable=True)          # kg
    color = Column(String(50), nullable=True)
    potencia = Column(String(50), nullable=True) # W, CV, etc.
    voltaje = Column(String(50), nullable=True)
    capacidad = Column(String(50), nullable=True)

    # ── Estado ────────────────────────────────────────────────────────────────
    estado = Column(String(50), default="disponible", index=True)
    # nueva | disponible | reservada | entregada | en_obra | en_transporte
    # en_mantenimiento | en_reparacion | fuera_servicio | extraviada | robada | baja | archivada

    # ── Ubicación ─────────────────────────────────────────────────────────────
    ubicacion_texto = Column(String(200), nullable=True, default="Almacén principal")
    delegacion_id = Column(Integer, ForeignKey("delegaciones.id"), nullable=True)
    almacen_id = Column(Integer, ForeignKey("almacenes.id"), nullable=True)
    obra_id = Column(Integer, ForeignKey("obras.id"), nullable=True)
    vehiculo_id = Column(Integer, ForeignKey("vehiculos.id"), nullable=True)
    responsable_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)

    # ── Adquisición ───────────────────────────────────────────────────────────
    fecha_compra = Column(Date, nullable=True)
    proveedor_id = Column(Integer, ForeignKey("proveedores.id"), nullable=True)
    proveedor_texto = Column(String(200), nullable=True)
    precio_compra = Column(Float, nullable=True)
    valor_actual = Column(Float, nullable=True)
    numero_factura = Column(String(100), nullable=True)
    garantia_hasta = Column(Date, nullable=True)
    vida_util_anos = Column(Integer, nullable=True)

    # ── Mantenimiento ─────────────────────────────────────────────────────────
    fecha_ultimo_mantenimiento = Column(Date, nullable=True)
    fecha_proximo_mantenimiento = Column(Date, nullable=True)
    intervalo_mantenimiento_dias = Column(Integer, nullable=True)

    # ── Imagen ────────────────────────────────────────────────────────────────
    foto = Column(String(255), nullable=True)
    foto_path = Column(String(255), nullable=True)

    # ── Control ───────────────────────────────────────────────────────────────
    observaciones = Column(Text, nullable=True)
    activa = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

    # ── Relaciones ────────────────────────────────────────────────────────────
    ubicacion_id = Column(Integer, ForeignKey("ubicaciones.id"), nullable=True, index=True)

    almacen   = relationship("Almacen",   back_populates="herramientas",
                             foreign_keys=[almacen_id])
    ubicacion = relationship("Ubicacion", back_populates="herramientas",
                             foreign_keys="Herramienta.ubicacion_id")
    obra = relationship("Obra", back_populates="herramientas",
                        foreign_keys=[obra_id])
    vehiculo = relationship("Vehiculo", back_populates="herramientas",
                            foreign_keys=[vehiculo_id])
    responsable = relationship("Trabajador", back_populates="herramientas",
                               foreign_keys=[responsable_id])
    proveedor_rel = relationship("Proveedor", back_populates="herramientas",
                                 foreign_keys=[proveedor_id])
    movimientos = relationship("Movimiento", back_populates="herramienta",
                               order_by="Movimiento.fecha.desc()",
                               foreign_keys="Movimiento.herramienta_id")
    incidencias = relationship("Incidencia", back_populates="herramienta",
                               foreign_keys="Incidencia.herramienta_id",
                               order_by="Incidencia.fecha_apertura.desc()")
    reparaciones = relationship("Reparacion", back_populates="herramienta",
                                foreign_keys="Reparacion.herramienta_id",
                                order_by="Reparacion.fecha_entrada.desc()")
    documentos = relationship("Documento", back_populates="herramienta",
                              foreign_keys="Documento.herramienta_id")


# ─── Motor de Movimientos ────────────────────────────────────────────────────

class Movimiento(Base):
    """
    Todo cambio de estado/ubicación pasa por aquí.
    Registro inmutable - nunca se borra.
    """
    __tablename__ = "movimientos"

    id = Column(Integer, primary_key=True, index=True)
    fecha = Column(DateTime, server_default=func.now(), index=True)
    tipo = Column(String(50), nullable=False, index=True)
    # alta | entrega | devolucion | traslado | reparacion | retorno_reparacion
    # inventario | baja | restauracion | perdida | robo | mantenimiento

    estado_anterior = Column(String(50), nullable=True)
    estado_nuevo = Column(String(50), nullable=False)
    origen = Column(String(200), nullable=True)
    destino = Column(String(200), nullable=True)
    motivo = Column(String(200), nullable=True)
    observaciones = Column(Text, nullable=True)

    # Firma digital (opcional)
    firma_nombre = Column(String(100), nullable=True)
    firma_datos = Column(Text, nullable=True)  # base64

    # ── Referencias ───────────────────────────────────────────────────────────
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    herramienta_id = Column(Integer, ForeignKey("herramientas.id"),
                            nullable=False, index=True)
    trabajador_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    obra_id = Column(Integer, ForeignKey("obras.id"), nullable=True)

    usuario = relationship("Usuario", back_populates="movimientos",
                           foreign_keys=[usuario_id])
    herramienta = relationship("Herramienta", back_populates="movimientos",
                               foreign_keys=[herramienta_id])
    trabajador = relationship("Trabajador", back_populates="movimientos",
                              foreign_keys=[trabajador_id])
    obra = relationship("Obra", back_populates="movimientos",
                        foreign_keys=[obra_id])


# ─── Incidencias ─────────────────────────────────────────────────────────────

class Incidencia(Base):
    __tablename__ = "incidencias"

    id = Column(Integer, primary_key=True, index=True)
    numero = Column(String(50), unique=True, index=True, nullable=False)
    titulo = Column(String(200), nullable=False)
    descripcion = Column(Text, nullable=True)
    tipo = Column(String(50), nullable=True, index=True)
    # golpe | rotura | perdida | robo | mal_funcionamiento | mantenimiento | otro
    prioridad = Column(String(20), default="media", index=True)
    # baja | media | alta | critica
    estado = Column(String(20), default="abierta", index=True)
    # abierta | en_curso | pendiente | resuelta | cerrada

    herramienta_id = Column(Integer, ForeignKey("herramientas.id"), nullable=True)
    vehiculo_id = Column(Integer, ForeignKey("vehiculos.id"), nullable=True)
    obra_id = Column(Integer, ForeignKey("obras.id"), nullable=True)
    responsable_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    creado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    fecha_apertura = Column(DateTime, server_default=func.now(), index=True)
    fecha_resolucion = Column(DateTime, nullable=True)
    observaciones = Column(Text, nullable=True)
    solucion = Column(Text, nullable=True)
    foto_path = Column(String(255), nullable=True)

    herramienta = relationship("Herramienta", back_populates="incidencias",
                               foreign_keys=[herramienta_id])
    vehiculo = relationship("Vehiculo", back_populates="incidencias",
                            foreign_keys=[vehiculo_id])
    obra = relationship("Obra", back_populates="incidencias",
                        foreign_keys=[obra_id])
    reparaciones = relationship("Reparacion", back_populates="incidencia",
                                foreign_keys="Reparacion.incidencia_id")


# ─── Reparaciones ────────────────────────────────────────────────────────────

class Reparacion(Base):
    __tablename__ = "reparaciones"

    id = Column(Integer, primary_key=True, index=True)
    numero = Column(String(50), unique=True, index=True, nullable=False)
    descripcion = Column(Text, nullable=True)
    diagnostico = Column(Text, nullable=True)
    estado = Column(String(50), default="recibida", index=True)
    # recibida | diagnostico | esperando_repuestos | en_reparacion | finalizada | sin_reparacion
    prioridad = Column(String(20), default="media")

    herramienta_id = Column(Integer, ForeignKey("herramientas.id"), nullable=True)
    incidencia_id = Column(Integer, ForeignKey("incidencias.id"), nullable=True)
    proveedor_id = Column(Integer, ForeignKey("proveedores.id"), nullable=True)
    responsable_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    creado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    fecha_entrada = Column(DateTime, server_default=func.now())
    fecha_prevista = Column(Date, nullable=True)
    fecha_salida = Column(DateTime, nullable=True)

    coste_estimado = Column(Float, nullable=True)
    coste_final = Column(Float, nullable=True)
    garantia_reparacion_hasta = Column(Date, nullable=True)
    resultado = Column(String(50), nullable=True)  # reparada | no_reparable | pendiente

    observaciones = Column(Text, nullable=True)

    herramienta = relationship("Herramienta", back_populates="reparaciones",
                               foreign_keys=[herramienta_id])
    incidencia = relationship("Incidencia", back_populates="reparaciones",
                              foreign_keys=[incidencia_id])
    proveedor = relationship("Proveedor", back_populates="reparaciones",
                             foreign_keys=[proveedor_id])


# ─── Documentos ──────────────────────────────────────────────────────────────

class Documento(Base):
    __tablename__ = "documentos"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(200), nullable=False)
    tipo = Column(String(50), nullable=True)  # factura | garantia | manual | certificado | otro
    archivo = Column(String(255), nullable=True)
    tamano = Column(Integer, nullable=True)  # bytes
    extension = Column(String(10), nullable=True)

    herramienta_id = Column(Integer, ForeignKey("herramientas.id"), nullable=True)
    subido_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    created_at = Column(DateTime, server_default=func.now())

    herramienta = relationship("Herramienta", back_populates="documentos",
                               foreign_keys=[herramienta_id])


# ─── Materiales ──────────────────────────────────────────────────────────────

class Material(Base):
    __tablename__ = "materiales"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(50), unique=True, index=True, nullable=False)
    nombre = Column(String(200), nullable=False, index=True)
    descripcion = Column(Text, nullable=True)
    categoria = Column(String(100), nullable=True, index=True)
    subcategoria = Column(String(100), nullable=True)
    unidad = Column(String(20), nullable=True, default="ud")  # ud, kg, m, m2, m3, l
    stock_actual = Column(Float, default=0.0)
    stock_minimo = Column(Float, default=0.0)
    stock_maximo = Column(Float, nullable=True)
    precio_unidad = Column(Float, nullable=True)
    proveedor_id = Column(Integer, ForeignKey("proveedores.id"), nullable=True)
    almacen_id    = Column(Integer, ForeignKey("almacenes.id"),   nullable=True, index=True)
    ubicacion_id  = Column(Integer, ForeignKey("ubicaciones.id"), nullable=True, index=True)
    ubicacion_texto = Column(String(200), nullable=True)  # texto libre legacy
    foto = Column(String(255), nullable=True)
    referencia_proveedor = Column(String(100), nullable=True)
    observaciones = Column(Text, nullable=True)
    activo = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

    almacen   = relationship("Almacen",   back_populates="materiales",
                           foreign_keys="Material.almacen_id")
    ubicacion = relationship("Ubicacion", back_populates="materiales",
                             foreign_keys="Material.ubicacion_id")

    # Relación con movimientos de almacén (añadida en v2.2)
    movimientos_almacen = relationship('MovimientoMaterial', back_populates='material',
                                       cascade='all, delete-orphan',
                                       order_by='MovimientoMaterial.fecha.desc()')

    @property
    def bajo_minimo(self):
        return self.stock_actual <= self.stock_minimo and self.stock_minimo > 0


# ─── Auditoría ───────────────────────────────────────────────────────────────

class AuditoriaLog(Base):
    """
    Registro de auditoría. NUNCA se borra. Solo se archiva.
    """
    __tablename__ = "auditoria_logs"

    id = Column(Integer, primary_key=True, index=True)
    fecha = Column(DateTime, server_default=func.now(), index=True)
    tabla = Column(String(50), nullable=False, index=True)
    registro_id = Column(Integer, nullable=True, index=True)
    accion = Column(String(50), nullable=False, index=True)
    # crear | editar | borrar | ver | exportar | importar | login | logout | config
    datos_anteriores = Column(Text, nullable=True)   # JSON string
    datos_nuevos = Column(Text, nullable=True)        # JSON string
    resumen = Column(String(500), nullable=True)

    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    ip = Column(String(45), nullable=True)
    user_agent = Column(String(255), nullable=True)

    usuario = relationship("Usuario", back_populates="auditorias",
                           foreign_keys=[usuario_id])


# ─── Logs del Sistema ────────────────────────────────────────────────────────

class SistemaLog(Base):
    """
    Logs técnicos del sistema (Motor de Logs DOC-41).
    """
    __tablename__ = "sistema_logs"

    id = Column(Integer, primary_key=True, index=True)
    fecha = Column(DateTime, server_default=func.now(), index=True)
    nivel = Column(String(10), nullable=False, index=True)  # DEBUG | INFO | WARNING | ERROR | CRITICAL
    modulo = Column(String(50), nullable=True, index=True)
    mensaje = Column(Text, nullable=False)
    detalle = Column(Text, nullable=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    ip = Column(String(45), nullable=True)


# ─── Maquinaria ──────────────────────────────────────────────────────────────

ESTADOS_MAQUINARIA = {
    "disponible":    "Disponible",
    "en_uso":        "En uso",
    "en_obra":       "En obra",
    "en_taller":     "En taller",
    "en_transito":   "En tránsito",
    "baja":          "Baja",
}

TIPOS_MAQUINARIA = [
    "Toro", "Carretilla", "Carretilla elevadora",
    "Excavadora", "Retroexcavadora", "Grúa",
    "Furgoneta", "Camión", "Compactadora", "Generador", "Compresor",
    "Hormigonera", "Plataforma elevadora", "Otro",
]


class Maquinaria(Base):
    """
    Activos de maquinaria pesada / vehículos — identificados por código de barras.
    El Zebra DS3678-SR (HID) escribe el codigo_barras + Enter directamente.
    """
    __tablename__ = "maquinaria"

    id              = Column(Integer, primary_key=True, index=True)
    codigo_barras   = Column(String(100), unique=True, index=True, nullable=True)
    codigo_interno  = Column(String(50), unique=True, index=True, nullable=True)
    nombre          = Column(String(200), nullable=False)
    tipo            = Column(String(50), nullable=True)
    marca           = Column(String(100), nullable=True)
    modelo          = Column(String(100), nullable=True)
    matricula       = Column(String(20), nullable=True, index=True)
    num_serie       = Column(String(100), nullable=True)
    anio            = Column(Integer, nullable=True)
    color           = Column(String(50), nullable=True)

    # Estado y ubicación
    estado          = Column(String(30), default="disponible", index=True)
    ubicacion       = Column(String(200), nullable=True)
    responsable     = Column(String(100), nullable=True)
    obra_actual     = Column(String(200), nullable=True)

    # Datos económicos
    valor_compra    = Column(Float, nullable=True)
    fecha_compra    = Column(Date, nullable=True)
    num_bastidor    = Column(String(50), nullable=True)

    # Mantenimiento
    ultima_itv      = Column(Date, nullable=True)
    proxima_itv     = Column(Date, nullable=True)
    km_actuales     = Column(Integer, nullable=True)
    horas_uso       = Column(Float, nullable=True)

    foto            = Column(String(255), nullable=True)
    notas           = Column(Text, nullable=True)
    activa          = Column(Boolean, default=True, index=True)
    creado_en       = Column(DateTime, server_default=func.now())
    actualizado_en  = Column(DateTime, onupdate=func.now())

    # Documentación legal
    fecha_seguro    = Column(Date, nullable=True)
    vencimiento_seguro = Column(Date, nullable=True)
    num_poliza      = Column(String(100), nullable=True)


# ─── Formación y Habilitaciones ──────────────────────────────────────────────

TIPOS_FORMACION = [
    "Trabajo en altura", "Plataformas elevadoras", "Carretilla elevadora",
    "Prevención de riesgos", "Primeros auxilios", "Soldadura", "Electricidad BT",
    "Gruista / Aparejador", "Conducción segura", "Otro",
]

class FormacionTrabajador(Base):
    """Cursos, certificados y habilitaciones por trabajador con caducidad."""
    __tablename__ = "formacion_trabajadores"

    id               = Column(Integer, primary_key=True, index=True)
    trabajador_id    = Column(Integer, ForeignKey("trabajadores.id"), nullable=False, index=True)
    nombre_curso     = Column(String(200), nullable=False)
    tipo             = Column(String(100), nullable=True)
    entidad          = Column(String(200), nullable=True)
    fecha_realizacion = Column(Date, nullable=True)
    fecha_caducidad  = Column(Date, nullable=True)
    num_certificado  = Column(String(100), nullable=True)
    archivo_path     = Column(String(255), nullable=True)
    notas            = Column(Text, nullable=True)
    usuario_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at       = Column(DateTime, server_default=func.now())

    trabajador = relationship("Trabajador", backref="formaciones")
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])

    @property
    def caducada(self):
        if not self.fecha_caducidad:
            return False
        from datetime import date as _d
        return _d.today() > self.fecha_caducidad

    @property
    def dias_para_caducidad(self):
        if not self.fecha_caducidad:
            return None
        from datetime import date as _d
        return (self.fecha_caducidad - _d.today()).days


# ─── Reconocimientos Médicos ──────────────────────────────────────────────────

class ReconocimientoMedico(Base):
    """Reconocimientos médicos por trabajador."""
    __tablename__ = "reconocimientos_medicos"

    id               = Column(Integer, primary_key=True, index=True)
    trabajador_id    = Column(Integer, ForeignKey("trabajadores.id"), nullable=False, index=True)
    fecha            = Column(Date, nullable=False)
    resultado        = Column(String(50), nullable=False, default="apto")
    # apto | apto_con_restricciones | no_apto | pendiente
    fecha_proxima    = Column(Date, nullable=True)
    medico           = Column(String(150), nullable=True)
    centro           = Column(String(200), nullable=True)
    restricciones    = Column(Text, nullable=True)
    archivo_path     = Column(String(255), nullable=True)
    usuario_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at       = Column(DateTime, server_default=func.now())

    trabajador = relationship("Trabajador", backref="reconocimientos")
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])

    @property
    def vencido(self):
        if not self.fecha_proxima:
            return False
        from datetime import date as _d
        return _d.today() > self.fecha_proxima

    @property
    def dias_para_vencimiento(self):
        if not self.fecha_proxima:
            return None
        from datetime import date as _d
        return (self.fecha_proxima - _d.today()).days


# ─── Documentación del Trabajador ────────────────────────────────────────────

TIPOS_DOCUMENTO_TRABAJADOR = [
    "DNI", "NIE", "Pasaporte", "Carné de conducir", "Tarjeta Seguridad Social",
    "Permiso de trabajo", "Tarjeta de residencia", "Certificado de delitos sexuales", "Otro",
]

class DocumentoTrabajador(Base):
    """Documentos oficiales del trabajador con fecha de caducidad."""
    __tablename__ = "documentos_trabajadores"

    id             = Column(Integer, primary_key=True, index=True)
    trabajador_id  = Column(Integer, ForeignKey("trabajadores.id"), nullable=False, index=True)
    tipo           = Column(String(100), nullable=False)
    numero         = Column(String(100), nullable=True)
    fecha_emision  = Column(Date, nullable=True)
    fecha_caducidad = Column(Date, nullable=True)
    archivo_path   = Column(String(255), nullable=True)
    notas          = Column(Text, nullable=True)
    usuario_id     = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at     = Column(DateTime, server_default=func.now())

    trabajador = relationship("Trabajador", backref="documentos_oficiales")
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])

    @property
    def caducado(self):
        if not self.fecha_caducidad:
            return False
        from datetime import date as _d
        return _d.today() > self.fecha_caducidad

    @property
    def dias_para_caducidad(self):
        if not self.fecha_caducidad:
            return None
        from datetime import date as _d
        return (self.fecha_caducidad - _d.today()).days


# ─── Partes de Presencia ─────────────────────────────────────────────────────

class PartePresencia(Base):
    """Registro diario de presencia de trabajadores en obras."""
    __tablename__ = "partes_presencia"

    id            = Column(Integer, primary_key=True, index=True)
    trabajador_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=False, index=True)
    obra_id       = Column(Integer, ForeignKey("obras.id"), nullable=True, index=True)
    fecha         = Column(Date, nullable=False, index=True)
    hora_entrada  = Column(String(10), nullable=True)   # "08:00"
    hora_salida   = Column(String(10), nullable=True)   # "17:00"
    horas_extras  = Column(Float, default=0.0)
    notas         = Column(Text, nullable=True)
    usuario_id    = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at    = Column(DateTime, server_default=func.now())

    trabajador = relationship("Trabajador", backref="partes_presencia")
    obra       = relationship("Obra", backref="partes_presencia")
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])


# ─── Planning de Obras ───────────────────────────────────────────────────────

class PlanningObra(Base):
    """Asignación de trabajadores y maquinaria a obras en fechas concretas."""
    __tablename__ = "planning_obras"

    id            = Column(Integer, primary_key=True, index=True)
    obra_id       = Column(Integer, ForeignKey("obras.id"), nullable=False, index=True)
    trabajador_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True, index=True)
    maquinaria_id = Column(Integer, ForeignKey("maquinaria.id"), nullable=True, index=True)
    fecha_inicio  = Column(Date, nullable=False, index=True)
    fecha_fin     = Column(Date, nullable=True)
    rol           = Column(String(100), nullable=True)
    notas         = Column(Text, nullable=True)
    usuario_id    = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at    = Column(DateTime, server_default=func.now())

    obra       = relationship("Obra", backref="planning")
    trabajador = relationship("Trabajador", backref="planning")
    maquinaria = relationship("Maquinaria", backref="planning")
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])


# ─── Sprint 4.1 — Motor de Automatizaciones ──────────────────────────────────

ESTADOS_AUTOMATIZACION = {
    "activa":     "Activa",
    "inactiva":   "Inactiva",
    "pausada":    "Pausada",
    "error":      "Error",
    "archivada":  "Archivada",
}

PRIORIDADES_AUTOMATIZACION = {
    "baja":    "Baja",
    "media":   "Media",
    "alta":    "Alta",
    "critica": "Crítica",
}

# Disparadores disponibles (Sprint 4.1 + 4.2)
TIPOS_DISPARADOR = {
    "intervalo":              "Cada N minutos",
    "diario":                 "Diario a una hora",
    "manual":                 "Solo manual",
    "evento_herramienta":     "Al cambiar estado de herramienta",
    "evento_maquinaria":      "Al cambiar estado de maquinaria",
}

# Condiciones disponibles (Sprint 4.1 + 4.2)
TIPOS_CONDICION = {
    # Sprint 4.1
    "herramienta_dias_entregada":    "Herramienta lleva X días entregada",
    "reparacion_retrasada":          "Reparación supera X días sin resolver",
    "mantenimiento_proximo_itv":     "ITV vence en menos de X días",
    "maquinaria_sin_movimiento":     "Maquinaria sin cambio de estado en X días",
    "siempre":                       "Siempre (sin condición adicional)",
    # Sprint 4.2
    "stock_material_bajo":           "Stock de material por debajo del mínimo",
    "incidencia_abierta_dias":       "Incidencia abierta más de X días",
    "herramienta_garantia_vence":    "Garantía de herramienta vence en X días",
    "herramienta_estado_es":         "Herramienta en estado específico",
    "maquinaria_estado_es":          "Maquinaria en estado específico",
}

# Acciones disponibles (Sprint 4.1 + 4.2)
TIPOS_ACCION = {
    # Sprint 4.1
    "crear_aviso":                   "Crear aviso en el sistema",
    "registrar_log":                 "Registrar en el log del sistema",
    # Sprint 4.2
    "cambiar_estado_herramienta":    "Cambiar estado de herramienta",
    "notificar_usuario":             "Crear aviso para usuario específico",
}

PRIORIDADES_AVISO = {
    "informacion": "Información",
    "baja":        "Baja",
    "media":       "Media",
    "alta":        "Alta",
    "critica":     "Crítica",
    "urgente":     "Urgente",
}


class Automatizacion(Base):
    """
    Regla de automatización configurable por el usuario.
    Evalúa condiciones sobre datos del sistema y ejecuta acciones si se cumplen.
    """
    __tablename__ = "automatizaciones"

    id                  = Column(Integer, primary_key=True, index=True)
    nombre              = Column(String(200), nullable=False)
    descripcion         = Column(Text, nullable=True)

    # Estado del ciclo de vida
    estado              = Column(String(20), default="activa", index=True)
    prioridad           = Column(String(20), default="media")
    version             = Column(Integer, default=1)

    # Disparador
    tipo_disparador     = Column(String(50), default="manual")
    config_disparador   = Column(Text, nullable=True)   # JSON: {"intervalo_min": 60} | {"hora": "08:00"}

    # Condiciones (JSON array)
    condiciones         = Column(Text, default="[]")    # [{"tipo":"herramienta_dias_entregada","dias":30}]

    # Acciones (JSON array)
    acciones            = Column(Text, default="[]")    # [{"tipo":"crear_aviso","titulo":"...","prioridad":"alta","mensaje":"..."}]

    # Estadísticas de ejecución
    total_ejecuciones   = Column(Integer, default=0)
    total_acciones      = Column(Integer, default=0)
    ultimo_resultado    = Column(String(20), nullable=True)   # ok | error | sin_accion
    ultimo_error        = Column(Text, nullable=True)

    # Timestamps
    creado_por_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    creado_en           = Column(DateTime, server_default=func.now())
    actualizado_en      = Column(DateTime, onupdate=func.now())
    ultima_ejecucion    = Column(DateTime, nullable=True)
    proxima_ejecucion   = Column(DateTime, nullable=True)

    # Relaciones
    ejecuciones         = relationship("EjecucionAutomatizacion", back_populates="automatizacion",
                                       cascade="all, delete-orphan", lazy="dynamic")


class EjecucionAutomatizacion(Base):
    """
    Registro de cada ejecución de una automatización (manual, automática o simulación).
    """
    __tablename__ = "ejecuciones_automatizacion"

    id                  = Column(Integer, primary_key=True, index=True)
    automatizacion_id   = Column(Integer, ForeignKey("automatizaciones.id"), nullable=False, index=True)
    fecha               = Column(DateTime, server_default=func.now(), index=True)
    modo                = Column(String(20), default="auto")    # auto | manual | simulacion | prueba
    resultado           = Column(String(20), nullable=True)     # ok | error | sin_accion
    acciones_ejecutadas = Column(Integer, default=0)
    items_afectados     = Column(Integer, default=0)
    detalle             = Column(Text, nullable=True)           # JSON: {"acciones": [...]}
    error               = Column(Text, nullable=True)
    duracion_ms         = Column(Integer, nullable=True)
    usuario_id          = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    # Relación
    automatizacion      = relationship("Automatizacion", back_populates="ejecuciones")


class Aviso(Base):
    """
    Avisos y notificaciones generados por automatizaciones o manualmente.
    Visible en el panel de control. Base para Sprint 4.3 (notificaciones).
    """
    __tablename__ = "avisos"

    id                  = Column(Integer, primary_key=True, index=True)
    titulo              = Column(String(200), nullable=False)
    mensaje             = Column(Text, nullable=True)
    prioridad           = Column(String(20), default="media", index=True)
    tipo                = Column(String(50), default="sistema")   # automatizacion | sistema | manual

    # Estado de lectura
    leido               = Column(Boolean, default=False, index=True)
    archivado           = Column(Boolean, default=False, index=True)

    # Origen
    automatizacion_id   = Column(Integer, ForeignKey("automatizaciones.id"), nullable=True, index=True)
    usuario_id          = Column(Integer, ForeignKey("usuarios.id"), nullable=True, index=True)

    # Enlace al activo relacionado (opcional)
    enlace              = Column(String(500), nullable=True)
    datos               = Column(Text, nullable=True)  # JSON con contexto adicional

    # Timestamps
    creado_en           = Column(DateTime, server_default=func.now(), index=True)
    leido_en            = Column(DateTime, nullable=True)


# ═══════════════════════════════════════════════════════════════════
# SPRINT 4.3 — CENTRO INTELIGENTE DE NOTIFICACIONES
# ═══════════════════════════════════════════════════════════════════

TIPOS_CANAL = {
    "email":   "Correo electrónico (SMTP)",
    "webhook": "Webhook HTTP (POST)",
}

PRIORIDADES_CANAL = {
    "baja":   "Baja y superior",
    "media":  "Media y superior",
    "alta":   "Solo Alta y Crítica",
    "critica":"Solo Crítica",
}

RESULTADOS_NOTIF = {
    "ok":      "Enviado",
    "error":   "Error",
    "reintento": "Pendiente reintento",
}


class CanalNotificacion(Base):
    """Canal de salida: email SMTP o webhook HTTP."""
    __tablename__ = "canales_notificacion"

    id              = Column(Integer, primary_key=True, index=True)
    nombre          = Column(String(120), nullable=False)
    tipo            = Column(String(30), nullable=False, index=True)  # email | webhook
    activo          = Column(Boolean, default=True, index=True)

    # JSON con config específica del canal:
    # email:   {smtp_host, smtp_port, smtp_user, smtp_pass, smtp_tls, destinatarios:[]}
    # webhook: {url, metodo:"POST", headers:{}, incluir_enlace:true}
    config          = Column(Text, nullable=False, default="{}")

    # Filtro de prioridad mínima para activar el canal
    prioridad_minima = Column(String(20), default="media")

    # Estadísticas
    total_enviados  = Column(Integer, default=0)
    total_errores   = Column(Integer, default=0)
    ultimo_envio    = Column(DateTime, nullable=True)

    creado_en       = Column(DateTime, server_default=func.now())
    actualizado_en  = Column(DateTime, server_default=func.now(), onupdate=func.now())

    notificaciones  = relationship("NotificacionEnviada", back_populates="canal",
                                   cascade="all, delete-orphan")


class NotificacionEnviada(Base):
    """Registro de cada notificación enviada o fallida."""
    __tablename__ = "notificaciones_enviadas"

    id              = Column(Integer, primary_key=True, index=True)
    canal_id        = Column(Integer, ForeignKey("canales_notificacion.id"), nullable=False, index=True)
    aviso_id        = Column(Integer, ForeignKey("avisos.id"), nullable=True, index=True)

    fecha_envio     = Column(DateTime, server_default=func.now(), index=True)
    resultado       = Column(String(20), default="ok", index=True)  # ok | error | reintento
    detalle         = Column(Text, nullable=True)   # error message o response body
    reintentos      = Column(Integer, default=0)
    proximo_reintento = Column(DateTime, nullable=True)

    # Snapshot del aviso al momento del envío
    aviso_titulo    = Column(String(255), nullable=True)
    aviso_prioridad = Column(String(30), nullable=True)

    canal           = relationship("CanalNotificacion", back_populates="notificaciones")


# ═══════════════════════════════════════════════════════════════════
# SPRINT 4.9 — MANTENIMIENTO PREDICTIVO
# ═══════════════════════════════════════════════════════════════════

TIPOS_MANTENIMIENTO = {
    "preventivo":  "Preventivo (programado)",
    "correctivo":  "Correctivo (avería)",
    "predictivo":  "Predictivo (recomendado por sistema)",
    "itv":         "ITV / Inspección técnica",
    "calibracion": "Calibración / Verificación",
    "limpieza":    "Limpieza / Conservación",
}

ESTADOS_MANTENIMIENTO = {
    "pendiente":   "Pendiente",
    "en_proceso":  "En proceso",
    "completado":  "Completado",
    "vencido":     "Vencido",
    "cancelado":   "Cancelado",
}

NIVELES_RIESGO = {
    "critico":  (75, 100),
    "alto":     (50, 74),
    "medio":    (25, 49),
    "bajo":     (0,  24),
}


class MantenimientoProgramado(Base):
    """Registro de mantenimientos programados y realizados por activo."""
    __tablename__ = "mantenimientos_programados"

    id               = Column(Integer, primary_key=True, index=True)

    # Activo asociado (herramienta o maquinaria)
    tipo_activo      = Column(String(30), nullable=False, index=True)  # herramienta | maquinaria
    activo_id        = Column(Integer, nullable=False, index=True)
    nombre_activo    = Column(String(200), nullable=False)
    codigo_activo    = Column(String(80), nullable=True)

    # Tipo y descripción
    tipo             = Column(String(30), nullable=False, default="preventivo")
    descripcion      = Column(Text, nullable=True)

    # Fechas
    fecha_programada = Column(DateTime, nullable=False, index=True)
    fecha_realizada  = Column(DateTime, nullable=True)
    intervalo_dias   = Column(Integer, nullable=True)  # Para calcular siguiente

    # Estado
    estado           = Column(String(30), default="pendiente", index=True)

    # Costes
    coste_estimado   = Column(Float, nullable=True)
    coste_real       = Column(Float, nullable=True)

    # Proveedor / técnico
    proveedor_texto  = Column(String(200), nullable=True)

    # Score de riesgo al programar
    score_riesgo     = Column(Integer, nullable=True)

    notas            = Column(Text, nullable=True)

    creado_por_id    = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    creado_en        = Column(DateTime, server_default=func.now(), index=True)
    actualizado_en   = Column(DateTime, server_default=func.now(), onupdate=func.now())


# ─── Sprint EPI — Entregas de EPIs y Ropa ────────────────────────────────────

KIT_EPI_INICIAL = [
    {"nombre": "CASCO",               "cantidad": 1},
    {"nombre": "CHALECO",             "cantidad": 1},
    {"nombre": "ARNES",               "cantidad": 1},
    {"nombre": "ABSORBEDOR",          "cantidad": 1},
    {"nombre": "CINTURON",            "cantidad": 1},
    {"nombre": "MARTILLO",            "cantidad": 1},
    {"nombre": "CARRACA",             "cantidad": 1},
    {"nombre": "METRO",               "cantidad": 1},
    {"nombre": "PORTAMARTILLO",       "cantidad": 1},
    {"nombre": "PORTAMETRO",          "cantidad": 1},
    {"nombre": "GAFAS TRANSPARENTES", "cantidad": 1},
    {"nombre": "GAFAS DE SOL",        "cantidad": 1},
]

KIT_ROPA_SEMESTRAL = [
    {"nombre": "FORRO",     "cantidad": 1},
    {"nombre": "JERSEI",    "cantidad": 2},
    {"nombre": "CAMISETA",  "cantidad": 5},
    {"nombre": "PANTALON",  "cantidad": 2},
    {"nombre": "BOTAS",     "cantidad": 1},
]

INTERVALO_ROPA_DIAS = 180  # 6 meses


class EntregaEPI(Base):
    __tablename__ = "entregas_epi"

    id            = Column(Integer, primary_key=True, index=True)
    trabajador_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=False, index=True)
    tipo          = Column(String(20), nullable=False, default="epi")   # 'epi' | 'ropa'
    items_json    = Column(Text, nullable=False)                        # JSON lista de items
    fecha         = Column(DateTime, nullable=False, server_default=func.now(), index=True)
    entregado_por = Column(String(100), nullable=True)
    firmado_por   = Column(String(100), nullable=True)
    observaciones = Column(Text, nullable=True)
    firma_base64  = Column(Text, nullable=True)
    usuario_id    = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    trabajador = relationship("Trabajador", backref="entregas_epi",
                              foreign_keys=[trabajador_id])


class StockEPI(Base):
    __tablename__ = "stock_epi"
    __table_args__ = (
        UniqueConstraint('nombre', 'talla', name='uq_stock_nombre_talla'),
    )

    id           = Column(Integer, primary_key=True, index=True)
    nombre       = Column(String(100), nullable=False)
    categoria    = Column(String(20), nullable=False, default="epi")  # 'epi' | 'ropa'
    talla        = Column(String(20), nullable=True)   # None para EPIs; talla para ropa ('M', '42', ...)
    cantidad     = Column(Integer, nullable=False, default=0)
    stock_minimo = Column(Integer, nullable=False, default=3)
    updated_at   = Column(DateTime, onupdate=func.now(), server_default=func.now())

    @property
    def bajo_minimo(self):
        return self.cantidad <= self.stock_minimo

    @property
    def sin_stock(self):
        return self.cantidad <= 0

    @property
    def nombre_display(self):
        return f"{self.nombre} T.{self.talla}" if self.talla else self.nombre


# ─── Sprint EPI — EPIs individuales con número de serie y revisiones ──────────

TIPOS_EPI_INDIVIDUAL = ["ARNES", "ABSORBEDOR"]
INTERVALO_REVISION_EPI_DIAS = 365  # revisión anual


class EPIIndividual(Base):
    __tablename__ = "epis_individuales"

    id                    = Column(Integer, primary_key=True, index=True)
    tipo                  = Column(String(50), nullable=False)          # ARNES, ABSORBEDOR
    codigo_fabricacion    = Column(String(150), nullable=False)
    marca                 = Column(String(100), nullable=True)
    modelo                = Column(String(100), nullable=True)
    fecha_fabricacion     = Column(Date, nullable=True)
    fecha_puesta_servicio = Column(Date, nullable=True)
    trabajador_id         = Column(Integer, ForeignKey("trabajadores.id"), nullable=True, index=True)
    estado                = Column(String(20), nullable=False, default="activo")  # activo | en_revision | baja
    proxima_revision      = Column(Date, nullable=True)
    notas                 = Column(Text, nullable=True)
    foto_path             = Column(String(255), nullable=True)
    created_at            = Column(DateTime, server_default=func.now())

    trabajador = relationship("Trabajador", backref="epis_individuales")
    revisiones = relationship("RevisionEPI", back_populates="epi",
                              cascade="all, delete-orphan")
    historial  = relationship("HistorialEPIIndividual", back_populates="epi",
                              cascade="all, delete-orphan", order_by="HistorialEPIIndividual.fecha_asignacion.desc()")

    @property
    def revision_vencida(self):
        if not self.proxima_revision:
            return False
        from datetime import date as _d
        return _d.today() >= self.proxima_revision

    @property
    def dias_para_revision(self):
        if not self.proxima_revision:
            return None
        from datetime import date as _d
        return (self.proxima_revision - _d.today()).days


class RevisionEPI(Base):
    __tablename__ = "revisiones_epi"

    id               = Column(Integer, primary_key=True, index=True)
    epi_id           = Column(Integer, ForeignKey("epis_individuales.id"), nullable=False, index=True)
    fecha            = Column(DateTime, nullable=False, server_default=func.now())
    resultado        = Column(String(30), nullable=False)   # apto | apto_con_obs | retirar
    tecnico          = Column(String(150), nullable=True)
    proxima_revision = Column(Date, nullable=True)
    observaciones    = Column(Text, nullable=True)
    usuario_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)

    epi     = relationship("EPIIndividual", back_populates="revisiones")
    usuario = relationship("Usuario", foreign_keys=[usuario_id])


class HistorialEPIIndividual(Base):
    """Registro histórico de asignaciones de cada EPI individual."""
    __tablename__ = "historial_epis_individuales"

    id               = Column(Integer, primary_key=True, index=True)
    epi_id           = Column(Integer, ForeignKey("epis_individuales.id"), nullable=False, index=True)
    trabajador_id    = Column(Integer, ForeignKey("trabajadores.id"), nullable=True, index=True)
    fecha_asignacion = Column(DateTime, nullable=False, server_default=func.now())
    fecha_devolucion = Column(DateTime, nullable=True)
    usuario_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    notas            = Column(Text, nullable=True)

    epi        = relationship("EPIIndividual", back_populates="historial")
    trabajador = relationship("Trabajador", foreign_keys=[trabajador_id])
    usuario    = relationship("Usuario", foreign_keys=[usuario_id])


# ─── Catálogo dinámico de EPIs y Ropa ────────────────────────────────────────
# Permite añadir/editar/eliminar artículos sin tocar el código.

class CatalogoEPI(Base):
    """Catálogo editable de artículos EPI y ropa de trabajo."""
    __tablename__ = "catalogo_epi"

    id           = Column(Integer, primary_key=True, index=True)
    nombre       = Column(String(100), nullable=False, unique=True)
    categoria    = Column(String(20),  nullable=False, default="epi")   # 'epi' | 'ropa'
    cantidad_kit = Column(Integer,     nullable=False, default=1)       # uds por kit/dotación
    activo       = Column(Boolean,     nullable=False, default=True)    # aparece en kits y stock
    orden        = Column(Integer,     nullable=False, default=0)       # orden en la UI
    created_at   = Column(DateTime, server_default=func.now())


# ─── Materiales / Consumibles de almacén ─────────────────────────────────────

UNIDADES_MATERIAL = ['ud', 'm', 'm²', 'm³', 'kg', 'l', 'caja', 'rollo', 'saco', 'ml', 't']
TIPOS_MOVIMIENTO_MAT = ['salida', 'entrada', 'ajuste']
CATEGORIAS_MATERIAL = [
    'Tornillería y fijaciones', 'Cables y electricidad', 'Tuberías y fontanería',
    'Herramientas de consumo', 'Productos químicos', 'Madera y tableros',
    'Áridos y morteros', 'Hierro y acero', 'Impermeabilización', 'Pintura',
    'Señalización y seguridad', 'Varios',
]


class MovimientoMaterial(Base):
    """Registro de entrada/salida de un material del almacén."""
    __tablename__ = "movimientos_materiales"

    id            = Column(Integer, primary_key=True, index=True)
    material_id   = Column(Integer, ForeignKey("materiales.id"), nullable=False, index=True)
    tipo          = Column(String(20), nullable=False)          # salida | entrada | ajuste
    cantidad      = Column(Float, nullable=False)
    obra_id       = Column(Integer, ForeignKey("obras.id"), nullable=True)
    trabajador_id = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    fecha         = Column(DateTime, default=datetime.utcnow)
    referencia    = Column(String(100), nullable=True)          # nº albarán, pedido …
    notas         = Column(Text, nullable=True)
    usuario_id    = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at    = Column(DateTime, default=datetime.utcnow)

    material    = relationship('Material', back_populates='movimientos_almacen')
    obra        = relationship('Obra', foreign_keys=[obra_id])
    trabajador  = relationship('Trabajador', foreign_keys=[trabajador_id])
    usuario     = relationship('Usuario', foreign_keys=[usuario_id])


# ─── Movimientos de Vehículos ────────────────────────────────────────────────

class MovimientoVehiculo(Base):
    """Registro de salida/retorno de un vehículo de la nave."""
    __tablename__ = "movimientos_vehiculos"

    id              = Column(Integer, primary_key=True, index=True)
    vehiculo_id     = Column(Integer, ForeignKey("vehiculos.id"), nullable=False, index=True)
    conductor_id    = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    obra_id         = Column(Integer, ForeignKey("obras.id"), nullable=True)
    destino         = Column(String(200), nullable=True)
    fecha_salida    = Column(DateTime, nullable=False, default=datetime.utcnow)
    km_salida       = Column(Integer, nullable=True)
    fecha_retorno   = Column(DateTime, nullable=True)
    km_retorno      = Column(Integer, nullable=True)
    observaciones   = Column(Text, nullable=True)
    usuario_id      = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)

    vehiculo    = relationship('Vehiculo', foreign_keys=[vehiculo_id])
    conductor   = relationship('Trabajador', foreign_keys=[conductor_id])
    obra        = relationship('Obra', foreign_keys=[obra_id])
    usuario     = relationship('Usuario', foreign_keys=[usuario_id])

    @property
    def en_ruta(self):
        return self.fecha_retorno is None

    @property
    def km_recorridos(self):
        if self.km_salida is not None and self.km_retorno is not None:
            return self.km_retorno - self.km_salida
        return None


# ─── Albarán de Salida Unificado ─────────────────────────────────────────────

ESTADOS_ALBARAN = ['abierto', 'cerrado', 'parcial']


class AlbaranSalida(Base):
    """Documento que agrupa todo lo que sale de la nave en una misma salida."""
    __tablename__ = "albaranes_salida"

    id                    = Column(Integer, primary_key=True, index=True)
    numero                = Column(String(30), unique=True, nullable=False, index=True)
    obra_id               = Column(Integer, ForeignKey("obras.id"), nullable=True)
    responsable_id        = Column(Integer, ForeignKey("trabajadores.id"), nullable=True)
    fecha_salida          = Column(DateTime, default=datetime.utcnow, nullable=False)
    fecha_retorno_prevista = Column(DateTime, nullable=True)
    fecha_retorno_real    = Column(DateTime, nullable=True)
    estado                = Column(String(20), default='abierto')  # abierto | parcial | cerrado
    notas                 = Column(Text, nullable=True)
    firma_datos           = Column(Text, nullable=True)   # base64
    firma_nombre          = Column(String(100), nullable=True)
    usuario_id            = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at            = Column(DateTime, default=datetime.utcnow)

    items       = relationship('ItemAlbaranSalida', back_populates='albaran',
                               cascade='all, delete-orphan')
    obra        = relationship('Obra', foreign_keys=[obra_id])
    responsable = relationship('Trabajador', foreign_keys=[responsable_id])
    usuario     = relationship('Usuario', foreign_keys=[usuario_id])

    @property
    def dias_fuera(self):
        fin = self.fecha_retorno_real or datetime.utcnow()
        return (fin - self.fecha_salida).days

    @property
    def todo_retornado(self):
        return all(i.retornado for i in self.items) if self.items else False


class ItemAlbaranSalida(Base):
    """Línea de un albarán: herramienta, material o descripción libre."""
    __tablename__ = "items_albaran_salida"

    id               = Column(Integer, primary_key=True, index=True)
    albaran_id       = Column(Integer, ForeignKey("albaranes_salida.id"), nullable=False, index=True)
    tipo             = Column(String(20), nullable=False)   # herramienta | material | libre
    herramienta_id   = Column(Integer, ForeignKey("herramientas.id"), nullable=True)
    material_id      = Column(Integer, ForeignKey("materiales.id"), nullable=True)
    cantidad         = Column(Float, default=1.0, nullable=False)
    descripcion_libre = Column(String(255), nullable=True)
    retornado        = Column(Boolean, default=False)
    fecha_retorno    = Column(DateTime, nullable=True)
    notas            = Column(Text, nullable=True)

    albaran     = relationship('AlbaranSalida', back_populates='items')
    herramienta = relationship('Herramienta', foreign_keys=[herramienta_id])
    material    = relationship('Material', foreign_keys=[material_id])

    @property
    def descripcion(self):
        if self.herramienta:
            return self.herramienta.nombre
        if self.material:
            return self.material.nombre
        return self.descripcion_libre or "—"


# ─── Repostaje de Vehículos (histórico externo) ───────────────────────────────

class RepostajeVehiculo(Base):
    """Repostaje de vehículo en gasolinera externa.
    Solo vincula a un Vehiculo; para el surtidor interno usar RepostajeSurtidor.
    """
    __tablename__ = "repostajes_vehiculos"

    id           = Column(Integer, primary_key=True, index=True)
    vehiculo_id  = Column(Integer, ForeignKey("vehiculos.id"), nullable=True, index=True)
    fecha        = Column(DateTime, default=datetime.utcnow)
    litros       = Column(Float, nullable=False)
    precio_litro = Column(Float, nullable=True)
    total_euros  = Column(Float, nullable=True)
    km_actuales  = Column(Integer, nullable=True)
    gasolinera   = Column(String(100), nullable=True)
    notas        = Column(Text, nullable=True)
    usuario_id   = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at   = Column(DateTime, default=datetime.utcnow)

    vehiculo = relationship('Vehiculo', foreign_keys=[vehiculo_id])
    usuario  = relationship('Usuario',  foreign_keys=[usuario_id])

    @property
    def activo_nombre(self):
        if self.vehiculo:
            v = self.vehiculo
            return f"{v.matricula} {v.marca or ''}".strip()
        return "—"

    @property
    def activo_tipo(self):
        if self.vehiculo:
            return (self.vehiculo.tipo or "vehículo").capitalize()
        return "Vehículo"


# ─── Surtidor interno (toros + furgonetas en la nave) ─────────────────────────

class RepostajeSurtidor(Base):
    """Registro del surtidor propio de la nave.
    Puede ser un Vehiculo (furgoneta) O una Maquinaria (toro/carretilla).
    Exactamente uno de vehiculo_id / maquinaria_id debe estar relleno.
    """
    __tablename__ = "repostajes_surtidor"

    id               = Column(Integer, primary_key=True, index=True)
    # 'repostaje' = un activo echa combustible | 'compra' = se compra combustible para el depósito
    tipo_registro    = Column(String(20), nullable=False, default='repostaje')
    vehiculo_id      = Column(Integer, ForeignKey("vehiculos.id"),  nullable=True, index=True)
    maquinaria_id    = Column(Integer, ForeignKey("maquinaria.id"), nullable=True, index=True)
    tipo_combustible = Column(String(20), nullable=True, default='gasoil')  # gasoil | gasolina
    fecha            = Column(DateTime, default=datetime.utcnow)
    litros           = Column(Float, nullable=False)
    precio_litro     = Column(Float, nullable=True)
    total_euros      = Column(Float, nullable=True)
    km_actuales      = Column(Integer, nullable=True)
    proveedor        = Column(String(100), nullable=True)   # para compras: quién suministra
    notas            = Column(Text, nullable=True)
    usuario_id       = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    created_at       = Column(DateTime, default=datetime.utcnow)

    vehiculo   = relationship('Vehiculo',   foreign_keys=[vehiculo_id])
    maquinaria = relationship('Maquinaria', foreign_keys=[maquinaria_id])
    usuario    = relationship('Usuario',    foreign_keys=[usuario_id])

    @property
    def activo_nombre(self):
        if self.tipo_registro == 'compra':
            return self.proveedor or "Compra combustible"
        if self.vehiculo:
            v = self.vehiculo
            return f"{v.matricula} {v.marca or ''}".strip()
        if self.maquinaria:
            return self.maquinaria.nombre
        return "—"

    @property
    def activo_tipo(self):
        if self.tipo_registro == 'compra':
            return "Compra"
        if self.vehiculo:
            return (self.vehiculo.tipo or "furgoneta").capitalize()
        if self.maquinaria:
            return (self.maquinaria.tipo or "maquinaria").capitali