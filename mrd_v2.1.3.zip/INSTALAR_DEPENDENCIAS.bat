@echo off
title MRD TOOL — Instalar dependencias faltantes
echo.
echo  Instalando dependencias faltantes en el entorno virtual...
echo.

cd /d "C:\mrd tool\mrd_tool_control"

venv\Scripts\pip.exe install -r requirements.txt

echo.
echo  Listo. Reinicia el servidor para que los cambios tengan efecto.
pause
