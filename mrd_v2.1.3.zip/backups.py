"""
Sistema de copias de seguridad - MRD TOOL CONTROL
"""
import shutil
from datetime import datetime
from pathlib import Path
from config import DATA_DIR, BACKUPS_DIR


def crear_backup() -> dict:
    db_path = DATA_DIR / "mrd_tool_control.db"
    if not db_path.exists():
        return {"ok": False, "error": "Base de datos no encontrada"}

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    nombre = f"backup_{timestamp}.db"
    destino = BACKUPS_DIR / nombre

    try:
        shutil.copy2(db_path, destino)
        tamaño = destino.stat().st_size
        return {
            "ok": True,
            "archivo": nombre,
            "ruta": str(destino),
            "tamaño": tamaño,
            "fecha": datetime.now().isoformat(),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def listar_backups() -> list:
    backups = []
    for f in sorted(BACKUPS_DIR.glob("backup_*.db"), reverse=True):
        stat = f.stat()
        backups.append({
            "nombre": f.name,
            "ruta": str(f),
            "tamaño": stat.st_size,
            "tamaño_str": _formato_tamaño(stat.st_size),
            "fecha": datetime.fromtimestamp(stat.st_mtime).strftime("%d/%m/%Y %H:%M"),
        })
    return backups


def restaurar_backup(nombre_archivo: str) -> dict:
    origen = BACKUPS_DIR / nombre_archivo
    if not origen.exists():
        return {"ok": False, "error": "Archivo de backup no encontrado"}

    db_path = DATA_DIR / "mrd_tool_control.db"
    if db_path.exists():
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.copy2(db_path, BACKUPS_DIR / f"antes_restaurar_{ts}.db")

    try:
        shutil.copy2(origen, db_path)
        return {"ok": True, "mensaje": f"Base de datos restaurada desde {nombre_archivo}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def limpiar_backups_antiguos(mantener: int = 30):
    backups = sorted(BACKUPS_DIR.glob("backup_*.db"), reverse=True)
    for f in backups[mantener:]:
        try:
            f.unlink()
        except Exception:
            pass


def _formato_tamaño(bytes_size: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} GB"
