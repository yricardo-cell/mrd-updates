# ============================================================
# MRD TOOL CONTROL — Servicio Resiliente
# Mata proceso anterior, arranca uvicorn, y reinicia si se cae
# ============================================================

$DIR = "C:\mrd tool\mrd_tool_control"
$LOG = "$DIR\logs\servicio_mrd.log"
$UVICORN = "$DIR\venv\Scripts\uvicorn.exe"
$NGROK   = "$DIR\ngrok.exe"
$PORT    = 8000

# Asegurar carpeta de logs
if (-not (Test-Path "$DIR\logs")) { New-Item -ItemType Directory -Path "$DIR\logs" | Out-Null }

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    Write-Host $line
    Add-Content -Path $LOG -Value $line -Encoding UTF8
}

function Kill-Port($port) {
    $conns = netstat -aon 2>$null | Select-String ":$port\s" | Select-String "LISTENING"
    foreach ($c in $conns) {
        $pid_ = ($c.Line -split '\s+')[-1]
        if ($pid_ -match '^\d+$' -and $pid_ -ne '0') {
            Write-Log "Matando proceso PID $pid_ en puerto $port"
            Stop-Process -Id ([int]$pid_) -Force -ErrorAction SilentlyContinue
        }
    }
    Start-Sleep -Seconds 2
}

Write-Log "=== MRD TOOL CONTROL - Servicio iniciado ==="
Set-Location $DIR

# Matar proceso anterior en puerto 8000
Kill-Port $PORT

# Arrancar ngrok si existe (en background)
if (Test-Path $NGROK) {
    Write-Log "Iniciando ngrok en puerto $PORT..."
    Start-Process -FilePath $NGROK -ArgumentList "http $PORT" -WindowStyle Hidden
}

# Loop principal: arranca uvicorn y reinicia si se cae
$intentos = 0
while ($true) {
    $intentos++
    Write-Log "Iniciando uvicorn (intento #$intentos)..."

    # Matar proceso residual antes de cada intento
    Kill-Port $PORT

    try {
        # Ejecutar uvicorn — bloquea hasta que termine
        & $UVICORN main:app --host 0.0.0.0 --port $PORT 2>&1 | ForEach-Object {
            $ts = Get-Date -Format "HH:mm:ss"
            $line = "[$ts] $_"
            Write-Host $line
            Add-Content -Path $LOG -Value $line -Encoding UTF8
        }
    } catch {
        Write-Log "ERROR: $_"
    }

    Write-Log "El servicio se detuvo. Reiniciando en 5 segundos..."
    Start-Sleep -Seconds 5
}
