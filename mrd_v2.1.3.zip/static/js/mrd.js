/* ============================================================
   MRD TOOL CONTROL — App JS v2
   ============================================================ */

// ── Theme ─────────────────────────────────────────────────────
const Theme = (() => {
  const KEY = 'mrd_theme';
  const root = document.documentElement;

  function apply(t) {
    root.setAttribute('data-theme', t);
    localStorage.setItem(KEY, t);
    const icon = document.getElementById('theme-icon');
    if (icon) icon.className = t === 'dark' ? 'bi bi-sun' : 'bi bi-moon';
  }

  function toggle() {
    apply(current() === 'dark' ? 'light' : 'dark');
  }

  function current() {
    return localStorage.getItem(KEY) || 'light';
  }

  function init() {
    apply(current());
  }

  return { init, toggle, current };
})();

// ── Sidebar ───────────────────────────────────────────────────
const Sidebar = (() => {
  const KEY = 'mrd_sidebar';
  let sidebar, main;

  function init() {
    sidebar = document.getElementById('app-sidebar');
    main = document.getElementById('app-main');
    if (!sidebar) return;
    const mini = localStorage.getItem(KEY) === 'mini';
    if (mini) setMini(true);
  }

  function toggle() {
    const isMini = sidebar.classList.contains('mini');
    setMini(!isMini);
  }

  function setMini(mini) {
    sidebar.classList.toggle('mini', mini);
    if (main) main.classList.toggle('expanded', mini);
    localStorage.setItem(KEY, mini ? 'mini' : 'full');
  }

  return { init, toggle };
})();

// ── Toast ──────────────────────────────────────────────────────
const Toast = (() => {
  let container;

  const ICONS = {
    success: 'bi-check-circle-fill',
    error:   'bi-x-circle-fill',
    warning: 'bi-exclamation-triangle-fill',
    info:    'bi-info-circle-fill',
  };

  function show(msg, type = 'info', dur = 3500) {
    if (!container) {
      container = document.getElementById('toast-container');
      if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
      }
    }
    const t = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.innerHTML = `
      <i class="bi ${ICONS[type] || ICONS.info} toast-icon"></i>
      <span class="toast-msg">${msg}</span>
      <button class="toast-close" onclick="this.parentElement.remove()"><i class="bi bi-x"></i></button>`;
    container.appendChild(t);
    setTimeout(() => {
      t.classList.add('removing');
      setTimeout(() => t.remove(), 200);
    }, dur);
  }

  return { show, success: m => show(m,'success'), error: m => show(m,'error',5000),
           warning: m => show(m,'warning'), info: m => show(m,'info') };
})();

// ── Confirm dialog ────────────────────────────────────────────
function mrdConfirm(msg, onConfirm, opts = {}) {
  const {
    title = 'Confirmar acción',
    btnOk = 'Confirmar',
    btnCancel = 'Cancelar',
    danger = false,
  } = opts;

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal" style="max-width:400px">
      <div class="modal-header">
        <span class="modal-title">${title}</span>
        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()"><i class="bi bi-x"></i></button>
      </div>
      <div class="modal-body" style="padding:20px">
        <p style="color:var(--text-2)">${msg}</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-overlay').remove()">${btnCancel}</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'} btn-sm confirm-ok">${btnOk}</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add('open'));

  overlay.querySelector('.confirm-ok').addEventListener('click', () => {
    overlay.remove();
    onConfirm();
  });
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
}

// ── Modal helpers ─────────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ── Tabs ───────────────────────────────────────────────────────
function initTabs(container) {
  const ctx = container || document;
  ctx.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      const parent = btn.closest('[data-tabs]') || btn.closest('.card') || document;
      parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      const content = parent.querySelector(`.tab-content[data-tab="${target}"]`);
      if (content) content.classList.add('active');
    });
  });
}

// ── Smart Table ────────────────────────────────────────────────
function initSmartTable(tableId) {
  const table = document.getElementById(tableId);
  if (!table) return;

  // Sort
  table.querySelectorAll('th[data-sort]').forEach(th => {
    th.style.cursor = 'pointer';
    th.addEventListener('click', () => {
      const col = th.dataset.sort;
      const asc = !th.classList.contains('sorted-asc');
      table.querySelectorAll('th').forEach(h => h.classList.remove('sorted-asc','sorted-desc'));
      th.classList.add(asc ? 'sorted-asc' : 'sorted-desc');
      sortTable(table, col, asc);
    });
  });

  // Row checkbox
  const selectAll = table.querySelector('.select-all');
  if (selectAll) {
    selectAll.addEventListener('change', () => {
      table.querySelectorAll('.row-check').forEach(cb => {
        cb.checked = selectAll.checked;
        cb.closest('tr').classList.toggle('selected', selectAll.checked);
      });
      updateBulkBar(table);
    });
  }

  table.querySelectorAll('.row-check').forEach(cb => {
    cb.addEventListener('change', () => {
      cb.closest('tr').classList.toggle('selected', cb.checked);
      updateBulkBar(table);
    });
  });
}

function sortTable(table, col, asc) {
  const tbody = table.querySelector('tbody');
  const rows = Array.from(tbody.querySelectorAll('tr'));
  rows.sort((a, b) => {
    const aVal = a.querySelector(`td[data-col="${col}"]`)?.textContent.trim() || '';
    const bVal = b.querySelector(`td[data-col="${col}"]`)?.textContent.trim() || '';
    return asc ? aVal.localeCompare(bVal, 'es', { numeric: true })
               : bVal.localeCompare(aVal, 'es', { numeric: true });
  });
  rows.forEach(r => tbody.appendChild(r));
}

function updateBulkBar(table) {
  const selected = table.querySelectorAll('.row-check:checked').length;
  const bar = document.getElementById('bulk-bar');
  if (bar) {
    bar.classList.toggle('visible', selected > 0);
    const cnt = bar.querySelector('.bulk-count');
    if (cnt) cnt.textContent = selected;
  }
}

// ── Live search (filtro instantáneo sobre tabla) ───────────────
function initLiveSearch(inputId, tableId, cols) {
  const input = document.getElementById(inputId);
  const table = document.getElementById(tableId);
  if (!input || !table) return;

  input.addEventListener('input', () => {
    const q = input.value.toLowerCase().trim();
    table.querySelectorAll('tbody tr').forEach(row => {
      const text = (cols
        ? cols.map(c => row.querySelector(`td[data-col="${c}"]`)?.textContent || '').join(' ')
        : row.textContent
      ).toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    });
  });
}

// ── Buscador global (Ctrl+K + dropdown) ──────────────────────
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    const s = document.getElementById('global-search');
    if (s) { s.focus(); s.select(); }
  }
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

function initGlobalSearch() {
  const input = document.getElementById('global-search');
  if (!input) return;
  const wrap = input.closest('.search-input-wrap');
  if (!wrap) return;

  let drop = document.createElement('div');
  drop.className = 'search-dropdown';
  wrap.appendChild(drop);

  let timer;

  function closeDrop() { drop.classList.remove('open'); }

  function renderDrop(data) {
    const { herramientas = [], trabajadores = [], obras = [] } = data;
    const total = herramientas.length + trabajadores.length + obras.length;
    if (total === 0) {
      drop.innerHTML = '<div class="search-drop-empty"><i class="bi bi-search"></i> Sin resultados para "<strong>' + input.value + '</strong>"</div>';
    } else {
      let html = '';
      if (herramientas.length) {
        html += '<div class="search-drop-section">Herramientas</div>';
        herramientas.forEach(h => {
          const est = (h.estado || '').replace(/_/g, ' ');
          html += `<a href="/herramientas/${h.id}" class="search-drop-item">
            <div class="search-drop-icon" style="background:var(--primary-light);color:var(--primary)"><i class="bi bi-wrench-adjustable"></i></div>
            <div><div class="search-drop-name">${h.codigo} — ${h.nombre}</div><div class="search-drop-sub">${est}</div></div>
          </a>`;
        });
      }
      if (trabajadores.length) {
        html += '<div class="search-drop-section">Trabajadores</div>';
        trabajadores.forEach(t => {
          html += `<a href="/trabajadores" class="search-drop-item">
            <div class="search-drop-icon" style="background:var(--success-light);color:var(--success)"><i class="bi bi-person"></i></div>
            <div><div class="search-drop-name">${t.nombre}</div><div class="search-drop-sub">${t.cargo || ''}</div></div>
          </a>`;
        });
      }
      if (obras.length) {
        html += '<div class="search-drop-section">Obras</div>';
        obras.forEach(o => {
          html += `<a href="/obras/${o.id}" class="search-drop-item">
            <div class="search-drop-icon" style="background:var(--info-light);color:var(--info)"><i class="bi bi-building"></i></div>
            <div><div class="search-drop-name">${o.nombre}</div><div class="search-drop-sub">${o.numero || ''}</div></div>
          </a>`;
        });
      }
      const q = encodeURIComponent(input.value.trim());
      html += `<a href="/buscar?q=${q}" class="search-drop-footer"><i class="bi bi-arrow-right-circle"></i> Ver todos los resultados</a>`;
      drop.innerHTML = html;
    }
    drop.classList.add('open');
  }

  input.addEventListener('input', () => {
    const q = input.value.trim();
    clearTimeout(timer);
    if (q.length < 2) { closeDrop(); return; }
    timer = setTimeout(() => {
      fetch(`/api/buscar?q=${encodeURIComponent(q)}`)
        .then(r => r.json())
        .then(renderDrop)
        .catch(() => closeDrop());
    }, 220);
  });

  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && input.value.trim()) {
      e.preventDefault();
      closeDrop();
      window.location.href = `/buscar?q=${encodeURIComponent(input.value.trim())}`;
    }
    if (e.key === 'Escape') closeDrop();
  });

  document.addEventListener('click', e => {
    if (!wrap.contains(e.target)) closeDrop();
  });
}

// ── Firma digital (canvas) ────────────────────────────────────
function initFirmaCanvas(canvasId, inputId) {
  const canvas = document.getElementById(canvasId);
  const input  = document.getElementById(inputId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const ph  = canvas.parentElement.querySelector('.firma-canvas-placeholder');
  const clr = canvas.parentElement.querySelector('.firma-clear-btn');

  let drawing = false;
  let hasStrokes = false;

  function getPos(e) {
    const r = canvas.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - r.left) * (canvas.width / r.width),
             y: (src.clientY - r.top)  * (canvas.height / r.height) };
  }

  function startDraw(e) {
    e.preventDefault();
    drawing = true;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    if (ph) ph.classList.add('hidden');
    if (clr) clr.classList.add('visible');
  }

  function draw(e) {
    if (!drawing) return;
    e.preventDefault();
    const p = getPos(e);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1a202c';
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    hasStrokes = true;
  }

  function endDraw() {
    if (!drawing) return;
    drawing = false;
    if (hasStrokes && input) {
      input.value = canvas.toDataURL('image/png');
    }
  }

  canvas.addEventListener('mousedown', startDraw);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('mouseup', endDraw);
  canvas.addEventListener('mouseleave', endDraw);
  canvas.addEventListener('touchstart', startDraw, { passive: false });
  canvas.addEventListener('touchmove', draw, { passive: false });
  canvas.addEventListener('touchend', endDraw);

  if (clr) {
    clr.addEventListener('click', () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (input) input.value = '';
      if (ph) ph.classList.remove('hidden');
      clr.classList.remove('visible');
      hasStrokes = false;
    });
  }
}

function clearFirmaCanvas(canvasId, inputId, phId) {
  const canvas = document.getElementById(canvasId);
  const input  = document.getElementById(inputId);
  const ph     = document.getElementById(phId);
  const clr    = canvas && canvas.parentElement.querySelector('.firma-clear-btn');
  if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
  if (input)  input.value = '';
  if (ph)     ph.classList.remove('hidden');
  if (clr)    clr.classList.remove('visible');
}

// ── Foto preview ───────────────────────────────────────────────
function initPhotoPreview(inputId, previewId) {
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);
  if (!input || !preview) return;

  input.addEventListener('change', () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      preview.src = e.target.result;
      preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
  });
}

// ── Form validation ────────────────────────────────────────────
function validateRequired(formId) {
  const form = document.getElementById(formId);
  if (!form) return true;
  let ok = true;
  form.querySelectorAll('[required]').forEach(field => {
    const empty = !field.value.trim();
    field.classList.toggle('error', empty);
    if (empty) ok = false;
  });
  return ok;
}

// ── Submitting state ───────────────────────────────────────────
function setSubmitting(btn, loading = true) {
  if (loading) {
    btn._origText = btn.innerHTML;
    btn.innerHTML = '<i class="bi bi-arrow-clockwise spin"></i> Guardando...';
    btn.disabled = true;
  } else {
    btn.innerHTML = btn._origText || 'Guardar';
    btn.disabled = false;
  }
}

// Spinner style
const spin = document.createElement('style');
spin.textContent = '.spin { animation: spin .6s linear infinite; } @keyframes spin { to { transform: rotate(360deg); } }';
document.head.appendChild(spin);

// ── Form protection (doble submit) ───────────────────────────
function initFormProtection() {
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function() {
      const btn = this.querySelector('[type=submit]');
      if (btn && !btn.disabled) {
        setTimeout(() => {
          btn.disabled = true;
          const orig = btn.innerHTML;
          btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Procesando...';
          setTimeout(() => { btn.disabled = false; btn.innerHTML = orig; }, 8000);
        }, 10);
      }
    });
  });
}

// ── Debounce + autocompletado ─────────────────────────────────
function debounce(fn, delay) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

function initAutocompletado(inputId, url, onSelect) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const buscar = debounce((q) => {
    if (q.length < 2) return;
    fetch(`${url}?q=${encodeURIComponent(q)}`)
      .then(r => r.json())
      .then(datos => onSelect(datos))
      .catch(() => {});
  }, 280);
  input.addEventListener('input', () => buscar(input.value));
}

// ── Banner de actualizacion ───────────────────────────────────
function checkUpdateBanner() {
  const banner = document.getElementById('update-banner');
  if (!banner) return;
  if (sessionStorage.getItem('mrd_update_checked')) return;
  fetch('/api/version/check')
    .then(r => r.json())
    .then(data => {
      sessionStorage.setItem('mrd_update_checked', '1');
      if (data.actualizacion_disponible) {
        const span = banner.querySelector('span');
        if (span) span.textContent = 'Nueva version v' + data.nueva_version + ' disponible - ';
        banner.classList.remove('d-none');
      }
    })
    .catch(() => {});
}

// ── CSRF helpers (Sprint 5.2) ────────────────────────────────
function getCsrfToken() {
  const m = document.cookie.match(/(?:^|; )mrd_csrf=([^;]*)/);
  return m ? decodeURIComponent(m[1]) : '';
}

// fetchCsrf: wrapper para peticiones mutantes que añade X-CSRF-Token
// (complementa el patch global de base.html para mayor compatibilidad)
function fetchCsrf(url, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
    const headers = new Headers(options.headers || {});
    if (!headers.has('X-CSRF-Token')) {
      headers.set('X-CSRF-Token', getCsrfToken());
    }
    options = { ...options, headers };
  }
  return fetch(url, options);
}

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  Theme.init();
  Sidebar.init();
  initTabs();
  document.querySelectorAll('.smart-table').forEach(t => initSmartTable(t.id));
  document.querySelectorAll('[data-live-search]').forEach(el => {
    initLiveSearch(el.dataset.input, el.dataset.table);
  });

  // Theme toggle button
  const themeBtn = document.getElementById('btn-theme');
  if (themeBtn) themeBtn.addEventListener('click', Theme.toggle);

  // Sidebar toggle button
  const sidebarBtn = document.getElementById('btn-sidebar');
  if (sidebarBtn) sidebarBtn.addEventListener('click', Sidebar.toggle);

  // Alert close auto-dismiss
  document.querySelectorAll('.alert-dismissible').forEach(a => {
    setTimeout(() => a.remove(), 5000);
  });

  // Form double-submit protection
  initFormProtection();

  // Update banner check
  checkUpdateBanner();

  // Global search dropdown
  initGlobalSearch();
});
