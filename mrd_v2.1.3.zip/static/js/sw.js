/* MRD TOOL CONTROL — Service Worker v2.0 */
// Incrementar CACHE_NAME al desplegar nueva version invalida la cache antigua.
// El cliente puede forzar actualizacion con: postMessage({type:'SKIP_WAITING'})
const CACHE_NAME = 'mrd-static-v2';

// Assets estaticos pre-cacheados — NUNCA paginas HTML ni datos de API
const STATIC_ASSETS = [
  '/static/css/bootstrap.min.css',
  '/static/css/bootstrap-icons.min.css',
  '/static/css/mrd.css',
  '/static/js/bootstrap.bundle.min.js',
  '/static/js/mrd.js',
  '/static/js/chart.umd.min.js',
  '/static/js/zxing.min.js',
];

// ── Instalación: pre-cachear assets estáticos ─────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(err => {
        console.warn('[SW] Error pre-cacheando assets:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// ── Activación: limpiar caches antiguas ──────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: cache-first para assets estáticos, network-first para todo lo demás
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Solo interceptar GET del mismo origen
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) {
    return;
  }

  // Assets estáticos: cache first
  if (url.pathname.startsWith('/static/')) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        return cached || fetch(event.request).then(response => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        });
      })
    );
    return;
  }

  // Páginas HTML y API: siempre red — no cachear datos ni sesiones
  // Sin fallback offline por ahora (Fase 3)
});

// ── Mensaje para forzar actualización desde el cliente ───────────────────
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
