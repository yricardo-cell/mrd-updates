"""
MRD TOOL CONTROL — Test fixtures
Sprint 5.2 — Security Hardening
"""
import os
import sys

# Variables de entorno ANTES de cualquier import del proyecto
os.environ["MRD_ENV"] = "development"
os.environ["MRD_SECRET_KEY"] = "test-secret-key-sprint52-" + "x" * 32
os.environ["MRD_ADMIN_PASSWORD"] = "TestAdmin@2024!"
os.environ["MRD_PASSWORD_MIN_LENGTH"] = "10"
os.environ["MRD_MAX_UPLOAD_MB"] = "10"
# Usar /tmp para evitar problemas de I/O en el sandbox Linux
os.environ["MRD_DATABASE_URL"] = "sqlite:////tmp/test_mrd_sprint52.db"

# Directorio raiz del proyecto en el path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

# Importar DESPUES de configurar env vars
from database import Base, get_db
from main import app

# Motor en memoria para tests de integracion
TEST_DB_URL = "sqlite:///:memory:"
_test_engine = create_engine(
    TEST_DB_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestSessionLocal = sessionmaker(bind=_test_engine)


def override_get_db():
    db = TestSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.create_all(bind=_test_engine)
    yield
    Base.metadata.drop_all(bind=_test_engine)


@pytest.fixture(scope="function")
def db():
    connection = _test_engine.connect()
    transaction = connection.begin()
    session = TestSessionLocal(bind=connection)
    yield session
    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture(scope="session")
def client():
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c
    app.dependency_overrides.clear()
