@echo off
title MRD TOOL - Publicar actualizacion
chcp 65001 >nul
cd /d "%~dp0"
start "MRD - Publicar actualizacion" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "PUBLICAR_ACTUALIZACION.ps1"
