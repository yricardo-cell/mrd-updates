"""
MRD TOOL CONTROL - Aplicación principal FastAPI
v1.0.0 - MRD Estructuras
"""
import os
import re
import shutil
import subprocess
import threading
import time
import traceback
import zipfile
import urllib.parse
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import Optional, Dict, Any
import json
import io
from collections import OrderedDict

from fastapi import (
    FastAPI, Request, Response, Depends, Form, File,
    UploadFile, HTTPException, Query, Body
)
from fastapi.middleware.gzip import GZipMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware  # Sprint 5.8
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, FileResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func, or_, text

from config import (
    BASE_DIR, DATA_DIR, BACKUPS_DIR, EXPORTS_DIR, UPLOADS_DIR,
    APP_NAME, COMPANY_NAME, VERSION, TEMPLATES_DIR,
    DEFAULT_ADMIN_USER, DEFAULT_ADMIN_PASSWORD,
    CATEGORIAS_DEFAULT, ESTADOS_HERRAMIENTA,
    ACCESS_TOKEN_EXPIRE_MINUTES,
    PASSWORD_MIN_LENGTH, MAX_UPLOAD_MB, IS_PRODUCTION,
    # Sprint 5.8 — IASMRD Cloudflare deployment
    MRD_PUBLIC_URL, MRD_SCAN_URL, MRD_TRUST_PROXY_HEADERS,
    MRD_HTTPS_ONLY as _MRD_HTTPS_ONLY, MRD_ALLOWED_HOSTS,
)
from database import engine, get_db, Base, apply_migrations
import mantenimiento as mant_engine
from models import (
    Ubicacion,
    Usuario, Trabajador, Almacen, Obra, Vehiculo, Herramienta, Movimiento,
    Incidencia, Reparacion, Material, Documento, Proveedor, Categoria, AuditoriaLog,
    Maquinaria, ESTADOS_MAQUINARIA, TIPOS_MAQUINARIA,
    Automatizacion, EjecucionAutomatizacion, Aviso,
    ESTADOS_AUTOMATIZACION, PRIORIDADES_AUTOMATIZACION,
    TIPOS_DISPARADOR, TIPOS_CONDICION, TIPOS_ACCION, PRIORIDADES_AVISO,
    CanalNotificacion, NotificacionEnviada, TIPOS_CANAL, PRIORIDADES_CANAL,
    MantenimientoProgramado, TIPOS_MANTENIMIENTO, ESTADOS_MANTENIMIENTO,
    EntregaEPI, KIT_EPI_INICIAL, KIT_ROPA_SEMESTRAL, INTERVALO_ROPA_DIAS,
    StockEPI,
    EPIIndividual, RevisionEPI, HistorialEPIIndividual, TIPOS_EPI_INDIVIDUAL, INTERVALO_REVISION_EPI_DIAS,
    CatalogoEPI,
    FormacionTrabajador, TIPOS_FORMACION,
    ReconocimientoMedico, DocumentoTrabajador, TIPOS_DOCUMENTO_TRABAJADOR,
    MovimientoMaterial, UNIDADES_MATERIAL, TIPOS_MOVIMIENTO_MAT, CATEGORIAS_MATERIAL,
    MovimientoVehiculo,
    AlbaranSalida, ItemAlbaranSalida, ESTADOS_ALBARAN,
    RepostajeVehiculo, RepostajeSurtidor,
)
from auth import (
    hash_password, verificar_password, crear_token,
    requiere_login, tiene_permiso, usuario_actual,
    obtener_usuario_por_token,
)
from codigos import generar_qr_base64, generar_barcode_base64, generar_qr_bytes
from backups import crear_backup, listar_backups, restaurar_backup
from label_printer import generar_zpl_herramienta, generar_zpl_lote, generar_pdf_etiquetas
from reports import (exportar_inventario_excel, exportar_movimientos_excel,
                    exportar_trabajadores_excel,
                    generar_plantilla_importacion, importar_herramientas_excel,
                    generar_analisis_inteligente, exportar_pdf_resumen,
                    exportar_maquinaria_excel, exportar_incidencias_excel,
                    exportar_reparaciones_excel,
                    generar_plantilla_trabajadores, importar_trabajadores_excel)
# Sprint 5.7 updater compatibility shim
import updater as _updater_mod
import json as _json

def leer_version_actual() -> dict:
    try:
        vf = Path("version.json")
        if vf.exists():
            return _json.loads(vf.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {"version_actual": VERSION, "cambios": [], "historial": []}

def verificar_actualizacion_local() -> dict:
    try:
        return _updater_mod.check_update()
    except Exception:
        return {"hay_actualizacion": False, "version_disponible": None, "error": "No disponible"}

def aplicar_actualizacion(archivo=None) -> dict:
    try:
        state = _updater_mod.get_state()
        url = state.get("download_url") or (archivo if isinstance(archivo, str) and archivo.startswith("http") else None)
        if url:
            return _updater_mod.start_update(url, state.get("sha256", ""), state.get("version_disponible", ""))
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return {"ok": False, "error": "Sin URL de descarga"}

def leer_historial() -> list:
    try:
        vf = Path("version.json")
        if vf.exists():
            d = _json.loads(vf.read_text(encoding="utf-8"))
            return d.get("historial", d.get("cambios", []))
    except Exception:
        pass
    return []
import remote_access
import mrd_logging
import automatizaciones as auto_engine
import notificaciones as notif_engine
import anomalias as anom_engine
from tools import aplicar_accion, registrar_auditoria, snapshot_herramienta, ErrorTransicion, ESTADOS
from security import (
    CSRF_COOKIE_NAME, CSRF_FIELD_NAME, CSRF_HEADER_NAME,
    generar_csrf_token, validar_csrf,
    validar_contrasena, ErrorContrasena,
    validar_nombre_archivo, validar_contenido_archivo, validar_tamaño_bytes, ErrorArchivo,
    build_security_headers,
)


# ─── Inicialización ───────────────────────────────────────────────────────────
Base.metadata.create_all(bind=engine)

def _migrar_bd():
    """Migraciones de columnas añadidas tras el despliegue inicial."""
    try:
        with engine.connect() as conn:
            # talla en stock_epi
            cols_stock = [r[1] for r in conn.execute(text("PRAGMA table_info(stock_epi)"))]
            if 'talla' not in cols_stock:
                conn.execute(text("ALTER TABLE stock_epi ADD COLUMN talla VARCHAR(20)"))
                conn.commit()

            # Sprint 5.2: must_change_password en usuarios
            cols_usr = [r[1] for r in conn.execute(text("PRAGMA table_info(usuarios)"))]
            if 'must_change_password' not in cols_usr:
                conn.execute(text(
                    "ALTER TABLE usuarios ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 1"
                ))
                # Usuarios existentes: admin debe cambiar, otros no
                conn.execute(text(
                    "UPDATE usuarios SET must_change_password = 0 WHERE rol != 'admin'"
                ))
                conn.commit()
                mrd_logging.log_app("Migración: columna must_change_password añadida a usuarios")

            # firma_base64 en entregas_epi
            cols_epi = [r[1] for r in conn.execute(text("PRAGMA table_info(entregas_epi)"))]
            if 'firma_base64' not in cols_epi:
                conn.execute(text("ALTER TABLE entregas_epi ADD COLUMN firma_base64 TEXT"))
                conn.commit()
                mrd_logging.log_app("Migración: columna firma_base64 añadida a entregas_epi")

            # foto_path en herramientas
            cols_herr = [r[1] for r in conn.execute(text("PRAGMA table_info(herramientas)"))]
            if 'foto_path' not in cols_herr:
                conn.execute(text("ALTER TABLE herramientas ADD COLUMN foto_path VARCHAR(255)"))
                conn.commit()
                mrd_logging.log_app("Migración: columna foto_path añadida a herramientas")

            # foto_path en epis_individuales
            cols_epi_ind = [r[1] for r in conn.execute(text("PRAGMA table_info(epis_individuales)"))]
            if 'foto_path' not in cols_epi_ind:
                conn.execute(text("ALTER TABLE epis_individuales ADD COLUMN foto_path VARCHAR(255)"))
                conn.commit()
                mrd_logging.log_app("Migración: columna foto_path añadida a epis_individuales")

            # Catálogo dinámico EPI: sembrar si la tabla está vacía
            try:
                n_cat = conn.execute(text("SELECT COUNT(*) FROM catalogo_epi")).scalar()
                if n_cat == 0:
                    for i, item in enumerate(KIT_EPI_INICIAL):
                        conn.execute(text(
                            "INSERT INTO catalogo_epi (nombre, categoria, cantidad_kit, activo, orden) "
                            "VALUES (:n, 'epi', :c, 1, :o)"
                        ), {"n": item["nombre"], "c": item.get("cantidad", 1), "o": i})
                    for i, item in enumerate(KIT_ROPA_SEMESTRAL):
                        conn.execute(text(
                            "INSERT INTO catalogo_epi (nombre, categoria, cantidad_kit, activo, orden) "
                            "VALUES (:n, 'ropa', :c, 1, :o)"
                        ), {"n": item["nombre"], "c": item.get("cantidad", 1), "o": i})
                    conn.commit()
                    mrd_logging.log_app("Catálogo EPI sembrado con artículos iniciales")
            except Exception:
                pass  # tabla no existía aún — create_all la crea después

            # foto_path en incidencias
            try:
                cols_inc = [r[1] for r in conn.execute(text("PRAGMA table_info(incidencias)"))]
                if 'foto_path' not in cols_inc:
                    conn.execute(text("ALTER TABLE incidencias ADD COLUMN foto_path VARCHAR(255)"))
                    conn.commit()
            except Exception:
                pass

            # Seguro en maquinaria
            try:
                cols_maq = [r[1] for r in conn.execute(text("PRAGMA table_info(maquinaria)"))]
                for col_name, col_def in [
                    ('fecha_seguro',       'DATE'),
                    ('vencimiento_seguro', 'DATE'),
                    ('num_poliza',         'VARCHAR(100)'),
                ]:
                    if col_name not in cols_maq:
                        conn.execute(text(f"ALTER TABLE maquinaria ADD COLUMN {col_name} {col_def}"))
                conn.commit()
            except Exception:
                pass

            # materiales y vehiculos — las tablas las crea create_all; aqui no hace falta ALTER
            # portal_token en trabajadores
            try:
                cols_trab = [r[1] for r in conn.execute(text("PRAGMA table_info(trabajadores)"))]
                if 'portal_token' not in cols_trab:
                    conn.execute(text("ALTER TABLE trabajadores ADD COLUMN portal_token VARCHAR(64)"))
                    conn.commit()
                    import secrets as _sec
                    rows = conn.execute(text("SELECT id FROM trabajadores WHERE portal_token IS NULL")).fetchall()
                    for row in rows:
                        tok = _sec.token_urlsafe(32)
                        conn.execute(text("UPDATE trabajadores SET portal_token=:tok WHERE id=:id"),
                                     {'tok': tok, 'id': row[0]})
                    conn.commit()
            except Exception:
                pass

            # Almacenes: foto
            try:
                cols_alm = [r[1] for r in conn.execute(text("PRAGMA table_info(almacenes)"))]
                if 'foto' not in cols_alm:
                    conn.execute(text("ALTER TABLE almacenes ADD COLUMN foto VARCHAR(255)"))
                conn.commit()
            except Exception:
                pass

            # Herramientas: ubicacion_id
            try:
                cols_h = [r[1] for r in conn.execute(text("PRAGMA table_info(herramientas)"))]
                if 'ubicacion_id' not in cols_h:
                    conn.execute(text("ALTER TABLE herramientas ADD COLUMN ubicacion_id INTEGER REFERENCES ubicaciones(id)"))
                conn.commit()
            except Exception:
                pass

            # Materiales: ubicacion_id
            try:
                cols_mat = [r[1] for r in conn.execute(text("PRAGMA table_info(materiales)"))]
                if 'ubicacion_id' not in cols_mat:
                    conn.execute(text("ALTER TABLE materiales ADD COLUMN ubicacion_id INTEGER REFERENCES ubicaciones(id)"))
                conn.commit()
            except Exception:
                pass

            # Vehiculos: itv, seguro, proxima_revision, compania, poliza
            try:
                cols_veh = [r[1] for r in conn.execute(text("PRAGMA table_info(vehiculos)"))]
                for col_name, col_def in [
                    ('itv_hasta',        'DATE'),
                    ('seguro_hasta',     'DATE'),
                    ('proxima_revision', 'DATE'),
                    ('compania_seguro',  'VARCHAR(100)'),
                    ('num_poliza',       'VARCHAR(100)'),
                ]:
                    if col_name not in cols_veh:
                        conn.execute(text(f"ALTER TABLE vehiculos ADD COLUMN {col_name} {col_def}"))
                conn.commit()
            except Exception:
                pass

    except Exception as _e:
        mrd_logging.log_app(f"_migrar_bd advertencia: {_e}", level="warning")

_migrar_bd()

def _migrar_surtidor():
    """Migración aislada para repostajes_surtidor con conexión propia."""
    try:
        with engine.begin() as conn:
            cols = [r[1] for r in conn.execute(text("PRAGMA table_info(repostajes_surtidor)"))]
            if cols and 'tipo_registro' not in cols:
                conn.execute(text("DROP TABLE repostajes_surtidor"))
    except Exception:
        pass
    # create_all recreará la tabla con el esquema correcto si no existe
    Base.metadata.create_all(bind=engine)

_migrar_surtidor()

app = FastAPI(
    title=APP_NAME,
    version=VERSION,
    docs_url=None,
    redoc_url=None,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)

# ─── Sprint 5.8 — IASMRD: Proxy headers (Cloudflare) ─────────────────────────
if MRD_TRUST_PROXY_HEADERS:
    from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware as _HttpsRedir  # noqa
    # ProxyHeadersMiddleware not in starlette standalone; implement inline
    @app.middleware("http")
    async def _proxy_headers_mw(request: Request, call_next):
        """Rewrite scope based on X-Forwarded-Proto and X-Real-IP / CF-Connecting-IP."""
        scope = request.scope
        # Protocol
        proto = (
            request.headers.get("cf-visitor", "")
            .replace('{"scheme":"', "").replace('"}', "").strip()
            or request.headers.get("x-forwarded-proto", "")
            .split(",")[0].strip()
        )
        if proto in ("https", "http"):
            scope["scheme"] = proto
        # Client IP (prefer CF-Connecting-IP)
        real_ip = (
            request.headers.get("cf-connecting-ip", "")
            or request.headers.get("x-real-ip", "")
            or request.headers.get("x-forwarded-for", "").split(",")[0].strip()
        )
        if real_ip and scope.get("client"):
            scope["client"] = (real_ip, scope["client"][1])
        return await call_next(request)

# ─── Sprint 5.8 — IASMRD: TrustedHost ────────────────────────────────────────
if MRD_ALLOWED_HOSTS:
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=MRD_ALLOWED_HOSTS,
    )

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.mount("/uploads", StaticFiles(directory=str(UPLOADS_DIR)), name="uploads")


@app.middleware("http")
async def cache_static(request: Request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "public, max-age=604800"
    return response



# ─── Middleware: Cabeceras de seguridad HTTP ──────────────────────────────────
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    response = await call_next(request)
    is_https = _MRD_HTTPS_ONLY or (request.headers.get("x-forwarded-proto", "http") == "https") or (request.headers.get("cf-visitor", "").find("https") != -1)
    for header, value in build_security_headers(is_https).items():
        response.headers[header] = value
    return response


# ─── Middleware: Cambio obligatorio de contraseña ─────────────────────────────
# Rutas exentas: el usuario puede acceder aunque must_change_password=True
_RUTAS_EXENTAS_MCP = {
    "/cambiar-contrasena", "/logout", "/login",
    "/health", "/static", "/favicon.ico",
}

@app.middleware("http")
async def must_change_password_middleware(request: Request, call_next):
    """Redirige a /cambiar-contrasena si el JWT contiene mcp=1."""
    path_req = request.url.path
    # Permitir recursos estáticos y rutas exentas
    if (path_req.startswith("/static") or
            path_req.startswith("/uploads") or
            any(path_req.startswith(r) for r in _RUTAS_EXENTAS_MCP)):
        return await call_next(request)
    # Solo peticiones GET (no interrumpir POSTs en /cambiar-contrasena)
    if request.method != "GET":
        return await call_next(request)
    # Decodificar JWT sin verificar expiración (solo leer el claim mcp)
    token = request.cookies.get("mrd_token", "")
    if token:
        try:
            from auth import SECRET_KEY as _SK, ALGORITHM as _ALG
            import jose.jwt as _jwt
            payload = _jwt.decode(token, _SK, algorithms=[_ALG])
            if payload.get("mcp"):
                return RedirectResponse("/cambiar-contrasena", status_code=303)
        except Exception:
            pass  # Token inválido/expirado — el auth handler lo gestionará
    return await call_next(request)


# ─── Middleware: Protección CSRF ──────────────────────────────────────────────
# Rutas exentas del CSRF (sin estado, sin autenticación)
_CSRF_EXENTOS = {"/health", "/scan/buscar", "/scan/ip", "/login", "/instalar"}

def _csrf_403(request: Request, detalle: str = "") -> Response:
    msg = detalle or "Token de seguridad inválido. Recarga la página e inténtalo de nuevo."
    return HTMLResponse(
        content=(
            f'<html><head><meta charset="utf-8"><meta http-equiv="refresh" content="3;url=/">'
            f'<link rel="stylesheet" href="/static/css/bootstrap.min.css"></head><body>'
            f'<div style="display:flex;align-items:center;justify-content:center;min-height:100vh">'
            f'<div style="text-align:center;max-width:400px;padding:40px">'
            f'<div style="font-size:4rem;font-weight:800;color:#dc3545">403</div>'
            f'<h2>Error de seguridad</h2><p>{msg}</p>'
            f'<a href="/" class="btn btn-primary">Volver al inicio</a></div></div></body></html>'
        ),
        status_code=403,
    )

@app.middleware("http")
async def csrf_middleware(request: Request, call_next):
    """
    Protección CSRF mediante double-submit cookie.
    - Cookie mrd_csrf (SameSite=Lax, NOT httponly) contiene el token.
    - Requests mutantes deben incluir el token en X-CSRF-Token header
      (para AJAX/fetch) o en el campo _csrf_token del body (para form submit).
    """
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        if request.url.path not in _CSRF_EXENTOS:
            csrf_cookie = request.cookies.get(CSRF_COOKIE_NAME, "")

            # ── 1. Verificar desde header (fetch/AJAX) ────────────────────────
            header_token = request.headers.get(CSRF_HEADER_NAME, "")
            if header_token:
                if not csrf_cookie or not validar_csrf(csrf_cookie, header_token):
                    mrd_logging.log_security(
                        f"CSRF inválido (header): path={request.url.path} "
                        f"ip={request.client.host if request.client else '?'}"
                    )
                    return _csrf_403(request)
            else:
                # ── 2. Verificar desde body (form submit nativo) ──────────────
                if not csrf_cookie:
                    return _csrf_403(request, "Sesión de seguridad no iniciada. Recarga la página.")
                try:
                    body = await request.body()
                    body_str = body.decode("utf-8", errors="ignore")
                    form_token = ""

                    # URL-encoded form
                    params = urllib.parse.parse_qs(body_str, keep_blank_values=True)
                    form_token = (params.get(CSRF_FIELD_NAME) or [""])[0]

                    # Multipart form (búsqueda simple en raw bytes)
                    if not form_token:
                        marker = f'name="{CSRF_FIELD_NAME}"'
                        idx = body_str.find(marker)
                        if idx != -1:
                            after = body_str[idx + len(marker):]
                            dbl = after.find("\r\n\r\n")
                            if dbl != -1:
                                vs = dbl + 4
                                ve = after.find("\r\n", vs)
                                form_token = after[vs:ve] if ve != -1 else after[vs:vs+128]

                    if not form_token or not validar_csrf(csrf_cookie, form_token):
                        mrd_logging.log_security(
                            f"CSRF inválido (form): path={request.url.path} "
                            f"ip={request.client.host if request.client else '?'}"
                        )
                        return _csrf_403(request)
                except Exception as _e:
                    mrd_logging.log_security(f"CSRF error: {_e}")
                    return _csrf_403(request)

    response = await call_next(request)

    # Establecer cookie CSRF si no existe
    if not request.cookies.get(CSRF_COOKIE_NAME):
        is_https = _MRD_HTTPS_ONLY or (request.headers.get("x-forwarded-proto", "http") == "https") or (request.headers.get("cf-visitor", "").find("https") != -1)
        response.set_cookie(
            CSRF_COOKIE_NAME,
            generar_csrf_token(),
            httponly=False,   # JS debe leer el valor para añadirlo a forms/fetch
            secure=is_https,
            samesite="lax",
            path="/",
            max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    return response


# ─── Manejador global de errores ─────────────────────────────────────────────
_ERROR_MESSAGES = {
    400: ("Solicitud incorrecta", "Los datos enviados no son válidos."),
    401: ("No autenticado", "Debes iniciar sesión para acceder."),
    403: ("Sin permiso", "No tienes permiso para realizar esta acción."),
    404: ("Página no encontrada", "La página que buscas no existe o fue movida."),
    409: ("Conflicto", "Ya existe un recurso con esos datos."),
    422: ("Datos inválidos", "Revisa el formulario e inténtalo de nuevo."),
    429: ("Demasiadas solicitudes", "Has superado el límite de intentos. Espera unos minutos."),
    500: ("Error interno", "Ocurrió un error inesperado. El equipo ha sido notificado."),
    503: ("Servicio no disponible", "El servicio está temporalmente fuera de línea."),
}

def _render_error(request: Request, code: int, detail: str = "") -> HTMLResponse:
    titulo, msg = _ERROR_MESSAGES.get(code, ("Error", "Ha ocurrido un error."))
    if detail and code not in (500,):  # no mostrar detalle técnico en 500
        msg = detail
    html = f"""<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{code} — {titulo}</title>
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="stylesheet" href="/static/css/mrd.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--bg)">
  <div style="text-align:center;max-width:480px;padding:40px 24px">
    <div style="font-size:5rem;font-weight:800;color:var(--primary);line-height:1">{code}</div>
    <h1 style="font-size:1.4rem;font-weight:700;margin:16px 0 8px">{titulo}</h1>
    <p style="color:var(--text-2);margin-bottom:32px">{msg}</p>
    <a href="/" class="btn btn-primary">Volver al inicio</a>
    {"<a href='/login' class='btn btn-outline' style='margin-left:8px'>Iniciar sesión</a>" if code == 401 else ""}
  </div>
</body>
</html>"""
    return HTMLResponse(content=html, status_code=code)


@app.exception_handler(StarletteHTTPException)
async def http_error_handler(request: Request, exc: StarletteHTTPException):
    # Para redirecciones devolver la respuesta directamente (no re-lanzar)
    if exc.status_code in (301, 302, 303, 307, 308):
        location = (exc.headers or {}).get("location", "/login")
        return RedirectResponse(url=location, status_code=exc.status_code)
    if exc.status_code == 401:
        return RedirectResponse("/login", status_code=303)
    detail = str(exc.detail) if exc.detail else ""
    mrd_logging.log_error(f"HTTP {exc.status_code} en {request.url.path} — {detail}")
    return _render_error(request, exc.status_code, detail)


@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    mrd_logging.log_error(f"Error no controlado en {request.url.path}", exc)
    mrd_logging.errors.error(tb)
    print(f"[MRD-500] {request.url.path} — {type(exc).__name__}: {exc}", flush=True)
    print(tb, flush=True)
    return _render_error(request, 500)

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


# ─── Jinja2 filtros personalizados ────────────────────────────────────────────
def fmt_fecha(value):
    if not value:
        return "—"
    if isinstance(value, str):
        return value
    return value.strftime("%d/%m/%Y")


def fmt_datetime(value):
    if not value:
        return "—"
    if isinstance(value, str):
        return value
    return value.strftime("%d/%m/%Y %H:%M")


def fmt_precio(value):
    if value is None:
        return "—"
    return f"{float(value):,.2f} €"


def estado_color(estado):
    return ESTADOS_HERRAMIENTA.get(estado, {}).get("color", "secondary")


def estado_label(estado):
    return ESTADOS_HERRAMIENTA.get(estado, {}).get("label", estado)


def fromjson_filter(value):
    """Parsea un JSON string a dict (para usar en templates con datos de auditoría)."""
    if not value:
        return {}
    try:
            return json.loads(value)
    except Exception:
        return {}


templates.env.filters["fmt_fecha"] = fmt_fecha
templates.env.filters["fmt_datetime"] = fmt_datetime
templates.env.filters["fmt_precio"] = fmt_precio
templates.env.filters["estado_color"] = estado_color
templates.env.filters["estado_label"] = estado_label
templates.env.filters["fromjson"] = fromjson_filter


# ─── Startup ──────────────────────────────────────────────────────────────────
def _alertas_no_retorno():
    try:
        from database import SessionLocal as _SL2
        from datetime import datetime as _dt2, timedelta as _td2
        db = _SL2()
        limite = _dt2.now() - _td2(days=14)
        herr = db.query(Herramienta).filter(
            Herramienta.activa == True,
            Herramienta.estado.notin_(["disponible","baja","mantenimiento"]),
        ).all()
        for h in herr:
            ultimo = db.query(Movimiento).filter(
                Movimiento.herramienta_id == h.id,
                Movimiento.tipo.in_(["entrega","traslado"]),
            ).order_by(Movimiento.fecha.desc()).first()
            if ultimo and ultimo.fecha < limite:
                ya = db.query(Aviso).filter(
                    Aviso.titulo.like(f"No retorno herramienta {h.id}%"),
                    Aviso.estado == "pendiente",
                ).first()
                if not ya:
                    db.add(Aviso(titulo=f"No retorno herramienta {h.id}: {h.nombre}",
                                 mensaje=f"'{h.nombre}' lleva mas de 14 dias sin retorno.",
                                 tipo="alerta", prioridad="alta"))
        vehs = db.query(MovimientoVehiculo).filter(
            MovimientoVehiculo.fecha_retorno == None,
            MovimientoVehiculo.fecha_salida < limite,
        ).all()
        for mv in vehs:
            mat = mv.vehiculo.matricula if mv.vehiculo else str(mv.vehiculo_id)
            ya = db.query(Aviso).filter(
                Aviso.titulo.like(f"No retorno vehiculo {mat}%"),
                Aviso.estado == "pendiente",
            ).first()
            if not ya:
                db.add(Aviso(titulo=f"No retorno vehiculo {mat} (mov #{mv.id})",
                             mensaje=f"Vehiculo {mat} salio el {mv.fecha_salida.strftime('%d/%m/%Y')} sin retorno.",
                             tipo="alerta", prioridad="alta"))
        db.commit(); db.close()
    except Exception: pass


def _alertas_stock_bajo():
    try:
        from database import SessionLocal as _SL3
        db = _SL3()
        for m in [x for x in db.query(Material).filter(Material.activo == True).all() if x.bajo_minimo]:
            ya = db.query(Aviso).filter(
                Aviso.titulo.like(f"Stock bajo {m.id}%"), Aviso.estado == "pendiente",
            ).first()
            if not ya:
                db.add(Aviso(titulo=f"Stock bajo {m.id}: {m.nombre}",
                             mensaje=f"Stock: {m.stock_actual} {m.unidad} (min: {m.stock_minimo})",
                             tipo="aviso", prioridad="media"))
        db.commit(); db.close()
    except Exception: pass


@app.on_event("startup")
def startup_event():
    mrd_logging.log_app(f"Arrancando MRD TOOL CONTROL v{VERSION}")

    # Inicializar módulo de acceso remoto y pre-calentar caché en background
    remote_access.init(BASE_DIR)
    threading.Thread(target=remote_access.get_status_cached, daemon=True).start()

    # Migración incremental V2 — añade columnas nuevas sin borrar datos
    apply_migrations()
    mrd_logging.log_app("Migraciones aplicadas")

    # Sprint 4.1 — Arrancar scheduler de automatizaciones
    from database import SessionLocal as _SL
    auto_engine.start_scheduler(lambda: _SL())
    mrd_logging.log_app("Scheduler de automatizaciones arrancado")
    # Alertas periódicas de no-retorno y stock bajo
    try:
        import threading as _thr, time as _tm
        def _run_alerts():
            _tm.sleep(30)  # esperar arranque completo
            while True:
                _alertas_no_retorno()
                _alertas_stock_bajo()
                _tm.sleep(6*3600)  # cada 6 horas
        _thr.Thread(target=_run_alerts, daemon=True, name="alertas_bg").start()
    except Exception: pass

    db = next(get_db())
    try:
        # Admin por defecto — solo crear si no existe ningún admin
        any_admin = db.query(Usuario).filter(Usuario.rol == "admin").first()
        if not any_admin:
            # Sprint 5.2: generar contraseña segura si no está configurada
            import sys as _sys
            _admin_pwd = DEFAULT_ADMIN_PASSWORD or __import__('secrets').token_urlsafe(16)
            if not DEFAULT_ADMIN_PASSWORD:
                print(
                    f'\n🔑  CONTRASEÑA DE ADMINISTRADOR GENERADA AUTOMÁTICAMENTE\n'
                    f'    Usuario:    admin\n'
                    f'    Contraseña: {_admin_pwd}\n'
                    f'    Guárdala en un lugar seguro. DEBERÁS cambiarla al iniciar sesión.\n',
                    file=_sys.stderr, flush=True,
                )
            admin = Usuario(
                username=DEFAULT_ADMIN_USER,
                password_hash=hash_password(_admin_pwd),
                nombre='Administrador',
                rol='admin',
                activo=True,
                must_change_password=True,  # Sprint 5.2
            )
            db.add(admin)
            db.commit()
            mrd_logging.log_security('Admin inicial creado. must_change_password=True', level='info')

        # Almacén por defecto
        almacen = db.query(Almacen).first()
        if not almacen:
            almacen = Almacen(nombre="Almacén Principal", descripcion="Almacén por defecto", activo=True)
            db.add(almacen)
            db.commit()
    finally:
        db.close()


# ─── Helpers ──────────────────────────────────────────────────────────────────
def generar_codigo_herramienta(db: Session) -> str:
    hoy = datetime.now().strftime("%Y%m%d")
    prefijo = f"MRD-{hoy}-"
    ultimo = (
        db.query(Herramienta)
        .filter(Herramienta.codigo.like(f"{prefijo}%"))
        .order_by(Herramienta.id.desc())
        .first()
    )
    if ultimo:
        try:
            num = int(ultimo.codigo.split("-")[-1]) + 1
        except Exception:
            num = 1
    else:
        num = 1
    return f"{prefijo}{num:04d}"


def ctx_base(request: Request, user: Usuario, db: Session = None, **kwargs) -> dict:
    avisos_sin_leer = 0
    dash_mat_bajo_minimo = 0
    if db is not None:
        try:
            avisos_sin_leer = db.query(Aviso).filter(
                Aviso.leido == False, Aviso.archivado == False
            ).count()
        except Exception:
            pass
        try:
            dash_mat_bajo_minimo = db.query(Material).filter(
                Material.activo == True,
                Material.stock_minimo > 0,
                Material.stock_actual <= Material.stock_minimo,
            ).count()
        except Exception:
            pass
    return {
        "request": request,
        "user": user,
        "app_name": APP_NAME,
        "company_name": COMPANY_NAME,
        "version": VERSION,
        "avisos_sin_leer": avisos_sin_leer,
        "dash_mat_bajo_minimo": dash_mat_bajo_minimo,
        # Sprint 5.2: CSRF token disponible en todos los templates
        "csrf_token": request.cookies.get(CSRF_COOKIE_NAME, ""),
        **kwargs,
    }


def registrar_movimiento(
    db: Session,
    herramienta: Herramienta,
    tipo: str,
    estado_nuevo: str,
    usuario: Usuario,
    trabajador_id: Optional[int] = None,
    obra_id: Optional[int] = None,
    destino: str = "",
    observaciones: str = "",
):
    mov = Movimiento(
        tipo=tipo,
        estado_anterior=herramienta.estado,
        estado_nuevo=estado_nuevo,
        destino=destino,
        observaciones=observaciones,
        herramienta_id=herramienta.id,
        usuario_id=usuario.id,
        trabajador_id=trabajador_id,
        obra_id=obra_id,
    )
    db.add(mov)


# ─── Rate limiting para login ────────────────────────────────────────────────
_login_attempts: dict = {}   # {ip_o_user: {"count": int, "locked_until": float}}
_login_lock = threading.Lock()
_MAX_INTENTOS = 5
_BLOQUEO_SEGUNDOS = 300      # 5 minutos

def _puede_intentar_login(clave: str) -> bool:
    with _login_lock:
        data = _login_attempts.get(clave, {"count": 0, "locked_until": 0.0})
        return time.time() >= data["locked_until"]

def _registrar_fallo_login(clave: str):
    with _login_lock:
        data = _login_attempts.get(clave, {"count": 0, "locked_until": 0.0})
        data["count"] += 1
        if data["count"] >= _MAX_INTENTOS:
            data["locked_until"] = time.time() + _BLOQUEO_SEGUNDOS
            data["count"] = 0
        _login_attempts[clave] = data

def _limpiar_intentos_login(clave: str):
    with _login_lock:
        _login_attempts.pop(clave, None)

def _segundos_bloqueo(clave: str) -> int:
    with _login_lock:
        data = _login_attempts.get(clave, {"locked_until": 0.0})
        resto = data["locked_until"] - time.time()
        return max(0, int(resto))


# ─── Auth ─────────────────────────────────────────────────────────────────────
@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("mrd_token")
    if token:
        # Verificar que el token es válido Y el usuario existe antes de redirigir
        # sub contiene el username (string), no el id numérico
        user = obtener_usuario_por_token(token, db)
        if user and user.activo:
            return RedirectResponse("/", status_code=303)
        # Token inválido o usuario no existe — limpiar cookie y mostrar login
        resp = templates.TemplateResponse(request, "login.html", {"request": request, "app_name": APP_NAME})
        resp.delete_cookie("mrd_token")
        return resp
    return templates.TemplateResponse(request, "login.html", {"request": request, "app_name": APP_NAME})


@app.post("/login")
def login_post(
    request: Request,
    response: Response,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    # Rate limiting: clave por IP + username
    ip = request.client.host if request.client else "unknown"
    clave_rl = f"{ip}:{username}"

    if not _puede_intentar_login(clave_rl):
        segundos = _segundos_bloqueo(clave_rl)
        return templates.TemplateResponse(request,
            "login.html",
            {"request": request, "app_name": APP_NAME,
             "error": f"Demasiados intentos fallidos. Espera {segundos // 60}m {segundos % 60}s."},
            status_code=429,
        )

    user = db.query(Usuario).filter(
        Usuario.username == username, Usuario.activo == True
    ).first()
    if not user or not verificar_password(password, user.password_hash):
        _registrar_fallo_login(clave_rl)
        mrd_logging.log_security(f"Login fallido: usuario='{username}' ip={ip}")
        return templates.TemplateResponse(request,
            "login.html",
            {"request": request, "app_name": APP_NAME, "error": "Usuario o contraseña incorrectos"},
            status_code=401,
        )

    _limpiar_intentos_login(clave_rl)
    mrd_logging.log_security(f"Login exitoso: usuario='{username}' ip={ip}", level="info")
    user.last_login = datetime.utcnow()
    db.commit()

    # Sprint 5.2: incluir mcp=1 en JWT si el usuario debe cambiar contraseña
    mcp = bool(getattr(user, "must_change_password", False))
    token_payload: dict = {"sub": user.username}
    if mcp:
        token_payload["mcp"] = 1

    token = crear_token(token_payload)
    is_https = _MRD_HTTPS_ONLY or (request.headers.get("x-forwarded-proto", "http") == "https") or (request.headers.get("cf-visitor", "").find("https") != -1)

    # Destino tras login: /cambiar-contrasena si mcp, sino /
    destino = "/cambiar-contrasena" if mcp else "/"
    resp = RedirectResponse(destino, status_code=303)

    # Cookie de sesión
    resp.set_cookie(
        "mrd_token", token,
        httponly=True,
        secure=is_https,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax",
        path="/",
    )
    # Rotar CSRF token en cada login
    resp.set_cookie(
        CSRF_COOKIE_NAME,
        generar_csrf_token(),
        httponly=False,
        secure=is_https,
        samesite="lax",
        path="/",
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    return resp


@app.get("/logout")
def logout():
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie("mrd_token", path="/")
    resp.delete_cookie(CSRF_COOKIE_NAME, path="/")
    return resp


# ─── Perfil / Cambiar contraseña ──────────────────────────────────────────────
@app.get("/perfil", response_class=HTMLResponse)
def perfil_get(request: Request, user: Usuario = Depends(requiere_login)):
    return templates.TemplateResponse(request, "perfil.html", ctx_base(request, user))


@app.post("/perfil")
def perfil_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    password_actual: str = Form(...),
    password_nuevo: str = Form(...),
    password_confirm: str = Form(...),
):
    if not verificar_password(password_actual, user.password_hash):
        return templates.TemplateResponse(request, "perfil.html", ctx_base(
            request, user, error="Contraseña actual incorrecta."))
    if password_nuevo != password_confirm:
        return templates.TemplateResponse(request, "perfil.html", ctx_base(
            request, user, error="Las contraseñas no coinciden."))
    # Sprint 5.2: validar política de contraseñas
    try:
        validar_contrasena(password_nuevo, username=user.username, min_length=PASSWORD_MIN_LENGTH)
    except ErrorContrasena as _ec:
        return templates.TemplateResponse(request, "perfil.html", ctx_base(
            request, user, error=str(_ec)))
    ip_cambio = request.client.host if request.client else "?"
    u = db.query(Usuario).get(user.id)
    u.password_hash = hash_password(password_nuevo)
    u.must_change_password = False
    db.commit()
    mrd_logging.log_security(
        f"Contraseña cambiada en /perfil: usuario='{user.username}' ip={ip_cambio}",
        level="info",
    )
    return RedirectResponse("/perfil?ok=1", status_code=303)



# ─── Cambio obligatorio de contraseña (Sprint 5.2) ───────────────────────────
@app.get("/cambiar-contrasena", response_class=HTMLResponse)
def cambiar_contrasena_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
):
    return templates.TemplateResponse(
        request, "cambiar_contrasena.html",
        {**ctx_base(request, user), "modo_obligatorio": bool(getattr(user, "must_change_password", False))},
    )


@app.post("/cambiar-contrasena")
def cambiar_contrasena_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    password_nuevo: str = Form(...),
    password_confirm: str = Form(...),
):
    ctx = {**ctx_base(request, user), "modo_obligatorio": bool(getattr(user, "must_change_password", False))}

    if password_nuevo != password_confirm:
        ctx["error"] = "Las contraseñas no coinciden."
        return templates.TemplateResponse(request, "cambiar_contrasena.html", ctx, status_code=400)

    try:
        validar_contrasena(password_nuevo, username=user.username, min_length=PASSWORD_MIN_LENGTH)
    except ErrorContrasena as _ec:
        ctx["error"] = str(_ec)
        return templates.TemplateResponse(request, "cambiar_contrasena.html", ctx, status_code=400)

    ip_cambio = request.client.host if request.client else "?"
    u = db.query(Usuario).get(user.id)
    u.password_hash = hash_password(password_nuevo)
    u.must_change_password = False
    db.commit()

    mrd_logging.log_security(
        f"Cambio obligatorio de contraseña completado: usuario='{user.username}' ip={ip_cambio}",
        level="info",
    )

    # Emitir nuevo JWT sin el claim mcp=1
    token = crear_token({"sub": user.username})
    is_https = _MRD_HTTPS_ONLY or (request.headers.get("x-forwarded-proto", "http") == "https") or (request.headers.get("cf-visitor", "").find("https") != -1)

    resp = RedirectResponse("/", status_code=303)
    resp.set_cookie(
        "mrd_token", token,
        httponly=True, secure=is_https,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax", path="/",
    )
    resp.set_cookie(
        CSRF_COOKIE_NAME, generar_csrf_token(),
        httponly=False, secure=is_https,
        samesite="lax", path="/",
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    return resp


# ─── Dashboard ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    # Conteos de herramientas: 1 query GROUP BY en lugar de 7 COUNT separados
    _estado_counts = dict(
        db.query(Herramienta.estado, func.count(Herramienta.id))
        .filter(Herramienta.activa == True)
        .group_by(Herramienta.estado)
        .all()
    )
    total = sum(_estado_counts.values())
    disponibles   = _estado_counts.get("disponible", 0)
    entregadas    = _estado_counts.get("entregada", 0)
    en_obra       = _estado_counts.get("en_obra", 0)
    en_furgoneta  = _estado_counts.get("en_furgoneta", 0)
    en_reparacion = _estado_counts.get("en_reparacion", 0)
    perdidas      = _estado_counts.get("perdida", 0)

    obras_activas     = db.query(Obra).filter(Obra.activa == True).count()
    total_trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).count()

    # joinedload evita N+1 al acceder a mov.herramienta y mov.usuario en el template
    ultimos_movimientos = (
        db.query(Movimiento)
        .options(
            joinedload(Movimiento.herramienta),
            joinedload(Movimiento.usuario),
        )
        .order_by(Movimiento.fecha.desc())
        .limit(10)
        .all()
    )

    # Por categoría para gráfico
    categorias = (
        db.query(Herramienta.categoria, func.count(Herramienta.id))
        .filter(Herramienta.activa == True)
        .group_by(Herramienta.categoria)
        .all()
    )

    # Obras activas para panel lateral
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.id.desc()).limit(5).all()

    # Alertas automáticas
    alertas = []
    if perdidas > 0:
        alertas.append({"icono": "bi-exclamation-triangle-fill", "color": "danger",
                        "titulo": f"{perdidas} herramienta(s) extraviada(s)",
                        "texto": "Revisar estado del inventario"})
    if en_reparacion > 0:
        alertas.append({"icono": "bi-hammer", "color": "warning",
                        "titulo": f"{en_reparacion} herramienta(s) en reparación",
                        "texto": "Verificar plazos de retorno"})
    # Alertas de garantías próximas a vencer (30 días)
    hoy = date.today()
    prox = hoy + timedelta(days=30)
    garantias_vencer = db.query(Herramienta).filter(
        Herramienta.activa == True,
        Herramienta.garantia_hasta != None,
        Herramienta.garantia_hasta <= prox,
        Herramienta.garantia_hasta >= hoy,
    ).count()
    if garantias_vencer > 0:
        alertas.append({"icono": "bi-shield-exclamation", "color": "warning",
                        "titulo": f"{garantias_vencer} garantía(s) vencen en 30 días",
                        "texto": "Revisar módulo de herramientas"})

    # Movimientos por día — últimos 7 días (para gráfico semanal)
    from collections import defaultdict as _dd
    _semana = []
    _semana_labels = []
    for _i in range(6, -1, -1):
        _dia = hoy - timedelta(days=_i)
        _cnt = db.query(func.count(Movimiento.id)).filter(
            func.date(Movimiento.fecha) == _dia
        ).scalar() or 0
        _semana.append(_cnt)
        _semana_labels.append(_dia.strftime("%a %d"))

    # Top obras con más herramientas en este momento
    top_obras = (
        db.query(Movimiento.destino, func.count(Movimiento.id).label("cnt"))
        .join(Herramienta, Movimiento.herramienta_id == Herramienta.id)
        .filter(Herramienta.estado == "en_obra", Herramienta.activa == True)
        .filter(Movimiento.destino != None)
        .group_by(Movimiento.destino)
        .order_by(func.count(Movimiento.id).desc())
        .limit(5)
        .all()
    )

    # Alerta: herramientas en reparación > 30 días
    limite_rep = hoy - timedelta(days=30)
    rep_largas = db.query(Reparacion).filter(
        Reparacion.fecha_entrada <= limite_rep,
        Reparacion.fecha_salida == None,
    ).count()
    if rep_largas > 0:
        alertas.append({"icono": "bi-clock-history", "color": "danger",
                        "titulo": f"{rep_largas} reparación(es) abiertas >30 días",
                        "texto": "Contactar con el taller y actualizar estado"})

    # Alerta: EPIs individuales con revisión vencida
    epis_vencidos = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.proxima_revision != None,
        EPIIndividual.proxima_revision < hoy,
    ).count()
    if epis_vencidos > 0:
        alertas.append({"icono": "bi-shield-x", "color": "danger",
                        "titulo": f"{epis_vencidos} EPI(s) con revisión vencida",
                        "texto": "Ir a EPIs → Arneses y Absorbedores"})

    # Alerta: EPIs con revisión próxima (≤15 días)
    prox_epi = hoy + timedelta(days=15)
    epis_proximos = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.proxima_revision != None,
        EPIIndividual.proxima_revision >= hoy,
        EPIIndividual.proxima_revision <= prox_epi,
    ).count()
    if epis_proximos > 0:
        alertas.append({"icono": "bi-shield-exclamation", "color": "warning",
                        "titulo": f"{epis_proximos} EPI(s) con revisión en ≤15 días",
                        "texto": "Programar revisión antes del vencimiento"})

    # Alertas de vehículos (ITV / seguro próximos 30 días)
    prox_vehs = hoy + timedelta(days=30)
    vehs_itv = db.query(Vehiculo).filter(
        Vehiculo.activo == True,
        Vehiculo.itv_hasta != None,
        Vehiculo.itv_hasta >= hoy,
        Vehiculo.itv_hasta <= prox_vehs,
    ).all()
    vehs_seg = db.query(Vehiculo).filter(
        Vehiculo.activo == True,
        Vehiculo.seguro_hasta != None,
        Vehiculo.seguro_hasta >= hoy,
        Vehiculo.seguro_hasta <= prox_vehs,
    ).all()
    vehs_itv_vencida = db.query(Vehiculo).filter(
        Vehiculo.activo == True,
        Vehiculo.itv_hasta != None,
        Vehiculo.itv_hasta < hoy,
    ).count()
    if vehs_itv_vencida > 0:
        alertas.append({"icono": "bi-car-front-fill", "color": "danger",
                        "titulo": f"{vehs_itv_vencida} vehículo(s) con ITV vencida",
                        "texto": "Revisar módulo de vehículos urgente"})
    if vehs_itv:
        alertas.append({"icono": "bi-car-front", "color": "warning",
                        "titulo": f"{len(vehs_itv)} vehículo(s) con ITV en ≤30 días",
                        "texto": ", ".join(v.matricula or v.nombre for v in vehs_itv[:3])})
    if vehs_seg:
        alertas.append({"icono": "bi-shield-check", "color": "warning",
                        "titulo": f"{len(vehs_seg)} vehículo(s) con seguro en ≤30 días",
                        "texto": ", ".join(v.matricula or v.nombre for v in vehs_seg[:3])})
    # Materiales bajo mínimo → alerta
    _mat_bajo = db.query(Material).filter(
        Material.activo == True, Material.stock_minimo > 0,
        Material.stock_actual <= Material.stock_minimo,
    ).count()
    if _mat_bajo > 0:
        alertas.append({"icono": "bi-exclamation-triangle-fill", "color": "danger",
                        "titulo": f"{_mat_bajo} material(es) bajo mínimo de stock",
                        "texto": "Ir a Materiales → Alertas para ver la lista"})

    return templates.TemplateResponse(request, "dashboard.html", ctx_base(
        request, user,
        total=total,
        disponibles=disponibles,
        entregadas=entregadas,
        en_obra=en_obra,
        en_furgoneta=en_furgoneta,
        en_reparacion=en_reparacion,
        perdidas=perdidas,
        obras_activas=obras_activas,
        total_trabajadores=total_trabajadores,
        ultimos_movimientos=ultimos_movimientos,
        categorias=categorias,
        obras=obras,
        alertas=alertas,
        alertas_count=len(alertas),
        movimientos_semana=_semana,
        movimientos_semana_labels=_semana_labels,
        top_obras=top_obras,
        # KPIs EPIs para el dashboard
        dash_epis_vencidos=db.query(EPIIndividual).filter(
            EPIIndividual.estado == "activo",
            EPIIndividual.proxima_revision != None,
            EPIIndividual.proxima_revision < hoy,
        ).count(),
        dash_epis_proximos=db.query(EPIIndividual).filter(
            EPIIndividual.estado == "activo",
            EPIIndividual.proxima_revision != None,
            EPIIndividual.proxima_revision >= hoy,
            EPIIndividual.proxima_revision <= hoy + timedelta(days=30),
        ).count(),
        dash_epis_disponibles={
            t: db.query(EPIIndividual).filter(
                EPIIndividual.tipo == t,
                EPIIndividual.estado != "baja",
                EPIIndividual.trabajador_id == None
            ).count()
            for t in TIPOS_EPI_INDIVIDUAL
        },
        dash_entregas_mes=db.query(EntregaEPI).filter(
            EntregaEPI.fecha >= hoy.replace(day=1)
        ).count(),
        # Fuera ahora — widget
        dash_vehs_en_ruta=db.query(MovimientoVehiculo).filter(
            MovimientoVehiculo.fecha_retorno == None,
        ).count(),
        dash_alb_abiertos=db.query(AlbaranSalida).filter(
            AlbaranSalida.estado.in_(["abierto", "parcial"]),
        ).count(),
        dash_mat_bajo_minimo=db.query(Material).filter(
            Material.activo == True,
            Material.stock_minimo > 0,
            Material.stock_actual <= Material.stock_minimo,
        ).count(),
        dash_herr_fuera=entregadas + en_obra + en_furgoneta,
    ))


# ─── Herramientas ─────────────────────────────────────────────────────────────
@app.get("/herramientas", response_class=HTMLResponse)
def herramientas_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    q: str = "",
    estado: str = "",
    categoria: str = "",
    page: int = 1,
):
    PER_PAGE = 25
    query = db.query(Herramienta).filter(Herramienta.activa == True)
    if q:
        query = query.filter(or_(
            Herramienta.codigo.ilike(f"%{q}%"),
            Herramienta.nombre.ilike(f"%{q}%"),
            Herramienta.num_serie.ilike(f"%{q}%"),
            Herramienta.marca.ilike(f"%{q}%"),
        ))
    if estado:
        query = query.filter(Herramienta.estado == estado)
    if categoria:
        query = query.filter(Herramienta.categoria == categoria)

    total = query.count()
    herramientas = (
        query.options(
            joinedload(Herramienta.responsable),
            joinedload(Herramienta.almacen),
            joinedload(Herramienta.obra),
        )
        .order_by(Herramienta.id.desc())
        .offset((page - 1) * PER_PAGE)
        .limit(PER_PAGE)
        .all()
    )
    total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)

    categorias = db.query(Herramienta.categoria).filter(Herramienta.activa == True).distinct().all()
    categorias = [c[0] for c in categorias if c[0]]

    # KPIs por estado — GROUP BY para una sola query
    kpi_raw = (
        db.query(Herramienta.estado, func.count(Herramienta.id))
        .filter(Herramienta.activa == True)
        .group_by(Herramienta.estado)
        .all()
    )
    kpis = {estado_k: cnt for estado_k, cnt in kpi_raw}

    # Total incluyendo inactivas para baja/archivada
    kpis_inactivos = (
        db.query(Herramienta.estado, func.count(Herramienta.id))
        .filter(Herramienta.activa == False)
        .group_by(Herramienta.estado)
        .all()
    )
    for estado_k, cnt in kpis_inactivos:
        kpis[estado_k] = kpis.get(estado_k, 0) + cnt

    total_global = db.query(func.count(Herramienta.id)).scalar()

    return templates.TemplateResponse(request, "herramientas.html", ctx_base(
        request, user,
        herramientas=herramientas,
        total=total,
        total_global=total_global,
        page=page,
        total_pages=total_pages,
        q=q,
        estado_filtro=estado,
        categoria_filtro=categoria,
        categorias=sorted(categorias),
        estados=ESTADOS_HERRAMIENTA,
        kpis=kpis,
    ))


@app.get("/herramientas/nueva", response_class=HTMLResponse)
def herramienta_nueva_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    num_serie: str = Query(""),
    codigo: str = Query(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    almacenes = db.query(Almacen).filter(Almacen.activo == True).all()
    proveedores = db.query(Proveedor).filter(Proveedor.activo == True).order_by(Proveedor.nombre).all()
    codigo_sugerido = codigo.strip() if codigo.strip() else generar_codigo_herramienta(db)
    return templates.TemplateResponse(request, "nueva_herramienta.html", ctx_base(
        request, user,
        almacenes=almacenes,
        proveedores=proveedores,
        categorias=CATEGORIAS_DEFAULT,
        estados=ESTADOS_HERRAMIENTA,
        codigo_sugerido=codigo_sugerido,
        prefill_num_serie=num_serie.strip(),
        scan_origen=bool(num_serie.strip() or codigo.strip()),
    ))


@app.post("/herramientas/nueva")
async def herramienta_nueva_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    codigo: str = Form(...),
    nombre: str = Form(...),
    descripcion: str = Form(""),
    categoria: str = Form("Otro"),
    subcategoria: str = Form(""),
    familia: str = Form(""),
    marca: str = Form(""),
    modelo: str = Form(""),
    fabricante: str = Form(""),
    num_serie: str = Form(""),
    potencia: str = Form(""),
    voltaje: str = Form(""),
    peso: str = Form(""),
    color: str = Form(""),
    dimensiones: str = Form(""),
    activo_fijo: str = Form(""),
    vida_util_anos: str = Form(""),
    estado: str = Form("disponible"),
    fecha_compra: str = Form(""),
    precio_compra: str = Form(""),
    proveedor_texto: str = Form(""),
    garantia_hasta: str = Form(""),
    numero_factura: str = Form(""),
    observaciones: str = Form(""),
    almacen_id: str = Form(""),
    ubicacion_texto: str = Form(""),
    foto: UploadFile = File(None),
    redirect: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")

    existe = db.query(Herramienta).filter(Herramienta.codigo == codigo).first()
    if existe:
        almacenes = db.query(Almacen).filter(Almacen.activo == True).all()
        proveedores = db.query(Proveedor).filter(Proveedor.activo == True).order_by(Proveedor.nombre).all()
        return templates.TemplateResponse(request, "nueva_herramienta.html", ctx_base(
            request, user,
            almacenes=almacenes,
            proveedores=proveedores,
            categorias=CATEGORIAS_DEFAULT,
            estados=ESTADOS_HERRAMIENTA,
            error="Ya existe una herramienta con ese código",
            codigo_sugerido=codigo,
        ), status_code=400)

    foto_path = None
    if foto and foto.filename:
        # Sprint 5.2: validar nombre, MIME y tamaño
        try:
            _, _ext = validar_nombre_archivo(foto.filename, {'jpg', 'jpeg', 'png', 'webp'})
            _head = await foto.read(16); await foto.seek(0)
            validar_contenido_archivo(_head, _ext)
            _content_foto = await foto.read(); await foto.seek(0)
            validar_tamaño_bytes(len(_content_foto), MAX_UPLOAD_MB)
        except ErrorArchivo as _ea:
            raise HTTPException(400, str(_ea))
        foto_nombre = f"{codigo}.{_ext}"
        foto_dest = UPLOADS_DIR / "herramientas" / foto_nombre
        foto_dest.parent.mkdir(parents=True, exist_ok=True)
        with open(foto_dest, "wb") as _fd:
            _fd.write(_content_foto)
        foto_path = foto_nombre

    a_id = int(almacen_id) if almacen_id else None
    almacen_obj = db.query(Almacen).get(a_id) if a_id else None

    h = Herramienta(
        codigo=codigo,
        nombre=nombre,
        descripcion=descripcion or None,
        categoria=categoria,
        subcategoria=subcategoria or None,
        familia=familia or None,
        marca=marca or None,
        modelo=modelo or None,
        fabricante=fabricante or None,
        num_serie=num_serie or None,
        potencia=potencia or None,
        voltaje=voltaje or None,
        peso=float(peso) if peso else None,
        color=color or None,
        dimensiones=dimensiones or None,
        activo_fijo=activo_fijo or None,
        vida_util_anos=int(vida_util_anos) if vida_util_anos else None,
        estado=estado,
        fecha_compra=datetime.strptime(fecha_compra, "%Y-%m-%d") if fecha_compra else None,
        precio_compra=float(precio_compra) if precio_compra else None,
        proveedor_texto=proveedor_texto or None,
        garantia_hasta=datetime.strptime(garantia_hasta, "%Y-%m-%d") if garantia_hasta else None,
        numero_factura=numero_factura or None,
        observaciones=observaciones or None,
        almacen_id=a_id,
        ubicacion_texto=ubicacion_texto or (almacen_obj.nombre if almacen_obj else "Almacén"),
        foto=foto_path,
        activa=True,
    )
    db.add(h)
    db.flush()

    registrar_movimiento(db, h, "alta", estado, user, observaciones="Herramienta dada de alta")

    # Auditoría de alta
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    registrar_auditoria(
        db,
        tabla="herramientas",
        registro_id=h.id,
        accion="crear",
        usuario_id=user.id,
        datos_anteriores=None,
        datos_nuevos=snapshot_herramienta(h),
        resumen=f"Alta de herramienta {h.nombre} ({h.codigo})",
        ip=ip,
    )
    db.commit()

    if redirect == "nueva":
        return RedirectResponse("/herramientas/nueva", status_code=303)
    return RedirectResponse(f"/herramientas/{h.id}", status_code=303)


@app.get("/herramientas/importar/plantilla")
def herramientas_plantilla_descarga(user: Usuario = Depends(requiere_login)):
    """Descarga la plantilla Excel de importación."""
    excel = generar_plantilla_importacion()
    nombre = "plantilla_importacion_herramientas.xlsx"
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )


@app.get("/herramientas/importar", response_class=HTMLResponse)
def herramientas_importar_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
):
    if not tiene_permiso(user, "crear"):
        return RedirectResponse("/herramientas", status_code=303)
    return templates.TemplateResponse(request, "importar_herramientas.html", ctx_base(request, user))


@app.post("/herramientas/importar", response_class=HTMLResponse)
async def herramientas_importar_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    archivo: UploadFile = File(...),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    # Sprint 5.2: validar MIME y tamaño del Excel
    try:
        _, _ext_xl = validar_nombre_archivo(archivo.filename, {'xlsx'})
        _head_xl = await archivo.read(16); await archivo.seek(0)
        validar_contenido_archivo(_head_xl, _ext_xl)
        _xlsx_bytes = await archivo.read(); await archivo.seek(0)
        validar_tamaño_bytes(len(_xlsx_bytes), MAX_UPLOAD_MB)
    except ErrorArchivo as _ea:
        return templates.TemplateResponse(request, "importar_herramientas.html",
            ctx_base(request, user, error=str(_ea)), status_code=400)
    if not archivo.filename.lower().endswith(".xlsx"):
        return templates.TemplateResponse(request, "importar_herramientas.html", ctx_base(
            request, user, error="Solo se aceptan archivos .xlsx"
        ), status_code=400)
    contenido = await archivo.read()
    try:
        resultado = importar_herramientas_excel(db, contenido, user)
        db.commit()
    except Exception as exc:
        db.rollback()
        return templates.TemplateResponse(request, "importar_herramientas.html", ctx_base(
            request, user, error=f"Error al procesar el archivo: {exc}"
        ), status_code=422)
    return templates.TemplateResponse(request, "importar_herramientas.html", ctx_base(
        request, user, resultado=resultado
    ))


# ─── Informes ─────────────────────────────────────────────────────────────────
@app.get("/herramientas/{herramienta_id}", response_class=HTMLResponse)
def herramienta_detalle(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404, "Herramienta no encontrada")

    qr_code = generar_qr_base64(h.codigo)
    barcode_b64 = generar_barcode_base64(h.codigo)

    movimientos = (
        db.query(Movimiento)
        .filter(Movimiento.herramienta_id == h.id)
        .order_by(Movimiento.fecha.desc())
        .limit(50)
        .all()
    )

    incidencias = (
        db.query(Incidencia)
        .filter(Incidencia.herramienta_id == h.id)
        .order_by(Incidencia.fecha_apertura.desc())
        .all()
    )

    reparaciones = (
        db.query(Reparacion)
        .filter(Reparacion.herramienta_id == h.id)
        .order_by(Reparacion.fecha_entrada.desc())
        .all()
    )

    documentos = (
        db.query(Documento)
        .filter(Documento.herramienta_id == h.id)
        .order_by(Documento.created_at.desc())
        .all()
    )

    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    almacenes = db.query(Almacen).filter(Almacen.activo == True).all()
    vehiculos = db.query(Vehiculo).filter(Vehiculo.activo == True).all()

    # Auditoría real (últimos 100 registros)
    auditoria_logs = (
        db.query(AuditoriaLog)
        .filter(
            AuditoriaLog.tabla == "herramientas",
            AuditoriaLog.registro_id == h.id,
        )
        .order_by(AuditoriaLog.fecha.desc())
        .limit(100)
        .all()
    )

    return templates.TemplateResponse(request, "herramienta_detalle.html", ctx_base(
        request, user,
        herramienta=h,
        qr_code=qr_code,
        barcode_b64=barcode_b64,
        movimientos=movimientos,
        incidencias=incidencias,
        reparaciones=reparaciones,
        documentos=documentos,
        trabajadores=trabajadores,
        obras=obras,
        almacenes=almacenes,
        vehiculos=vehiculos,
        estados=ESTADOS_HERRAMIENTA,
        estados_info=ESTADOS,
        auditoria_logs=auditoria_logs,
    ))


@app.get("/herramientas/{herramienta_id}/editar", response_class=HTMLResponse)
def herramienta_editar_get(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404)
    almacenes = db.query(Almacen).filter(Almacen.activo == True).all()
    proveedores = db.query(Proveedor).filter(Proveedor.activo == True).order_by(Proveedor.nombre).all()
    return templates.TemplateResponse(request, "editar_herramienta.html", ctx_base(
        request, user,
        herramienta=h,
        almacenes=almacenes,
        proveedores=proveedores,
        categorias=CATEGORIAS_DEFAULT,
        estados=ESTADOS_HERRAMIENTA,
    ))


@app.post("/herramientas/{herramienta_id}/editar")
async def herramienta_editar_post(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    descripcion: str = Form(""),
    categoria: str = Form("Otro"),
    subcategoria: str = Form(""),
    familia: str = Form(""),
    marca: str = Form(""),
    modelo: str = Form(""),
    fabricante: str = Form(""),
    num_serie: str = Form(""),
    potencia: str = Form(""),
    voltaje: str = Form(""),
    peso: str = Form(""),
    color: str = Form(""),
    dimensiones: str = Form(""),
    activo_fijo: str = Form(""),
    vida_util_anos: str = Form(""),
    fecha_compra: str = Form(""),
    precio_compra: str = Form(""),
    proveedor_texto: str = Form(""),
    garantia_hasta: str = Form(""),
    numero_factura: str = Form(""),
    observaciones: str = Form(""),
    almacen_id: str = Form(""),
    ubicacion_texto: str = Form(""),
    foto: UploadFile = File(None),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404)

    # Snapshot antes de editar (para auditoría)
    snap_ant = snapshot_herramienta(h)

    h.nombre = nombre
    h.descripcion = descripcion or None
    h.categoria = categoria
    h.subcategoria = subcategoria or None
    h.familia = familia or None
    h.marca = marca or None
    h.modelo = modelo or None
    h.fabricante = fabricante or None
    h.num_serie = num_serie or None
    h.potencia = potencia or None
    h.voltaje = voltaje or None
    h.peso = float(peso) if peso else None
    h.color = color or None
    h.dimensiones = dimensiones or None
    h.activo_fijo = activo_fijo or None
    h.vida_util_anos = int(vida_util_anos) if vida_util_anos else None
    h.fecha_compra = datetime.strptime(fecha_compra, "%Y-%m-%d").date() if fecha_compra else None
    h.precio_compra = float(precio_compra) if precio_compra else None
    h.proveedor_texto = proveedor_texto or None
    h.garantia_hasta = datetime.strptime(garantia_hasta, "%Y-%m-%d").date() if garantia_hasta else None
    h.numero_factura = numero_factura or None
    h.observaciones = observaciones or None
    h.almacen_id = int(almacen_id) if almacen_id else None
    h.ubicacion_texto = ubicacion_texto or None

    if foto and foto.filename:
        # Sprint 5.2: validar nombre, MIME y tamaño
        try:
            _, _ext_h = validar_nombre_archivo(foto.filename, {'jpg', 'jpeg', 'png', 'webp'})
            _head_h = await foto.read(16); await foto.seek(0)
            validar_contenido_archivo(_head_h, _ext_h)
            _content_h = await foto.read(); await foto.seek(0)
            validar_tamaño_bytes(len(_content_h), MAX_UPLOAD_MB)
        except ErrorArchivo as _ea:
            raise HTTPException(400, str(_ea))
        foto_nombre = f"{h.codigo}.{_ext_h}"
        foto_dest = UPLOADS_DIR / "herramientas" / foto_nombre
        foto_dest.parent.mkdir(parents=True, exist_ok=True)
        with open(foto_dest, "wb") as _fd:
            _fd.write(_content_h)
        h.foto = foto_nombre

    # Auditoría de edición
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    registrar_auditoria(
        db,
        tabla="herramientas",
        registro_id=h.id,
        accion="editar",
        usuario_id=user.id,
        datos_anteriores=snap_ant,
        datos_nuevos=snapshot_herramienta(h),
        resumen=f"Edición de {h.nombre} ({h.codigo})",
        ip=ip,
    )

    db.commit()
    return RedirectResponse(f"/herramientas/{herramienta_id}", status_code=303)


@app.post("/herramientas/{herramienta_id}/accion")
def herramienta_accion(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    accion: str = Form(...),
    trabajador_id: str = Form(""),
    obra_id: str = Form(""),
    almacen_id: str = Form(""),
    vehiculo_id: str = Form(""),
    observaciones: str = Form(""),
):
    if not tiene_permiso(user, "entregar"):
        raise HTTPException(403, "Sin permiso")

    # Acciones de admin requieren permiso 'borrar'
    ACCIONES_ADMIN = {"baja", "restaurar", "archivar", "recuperar", "robada"}
    if accion in ACCIONES_ADMIN and not tiene_permiso(user, "borrar"):
        raise HTTPException(403, "Sin permiso de administrador")

    # Herramienta: admitir activa=False para restaurar/recuperar
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404, "Herramienta no encontrada")

    t_id = int(trabajador_id) if trabajador_id and trabajador_id.isdigit() else None
    o_id = int(obra_id)        if obra_id        and obra_id.isdigit()        else None
    a_id = int(almacen_id)     if almacen_id     and almacen_id.isdigit()     else None
    v_id = int(vehiculo_id)    if vehiculo_id    and vehiculo_id.isdigit()    else None

    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    es_admin = tiene_permiso(user, "borrar")

    try:
        aplicar_accion(
            db, h, accion, user,
            es_admin      = es_admin,
            trabajador_id = t_id,
            obra_id       = o_id,
            almacen_id    = a_id,
            vehiculo_id   = v_id,
            observaciones = observaciones,
            ip            = ip,
        )
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))

    # Soporte JSON para llamadas AJAX (desde la ficha)
    accept = request.headers.get("Accept", "")
    if "application/json" in accept:
        return JSONResponse({"ok": True, "estado": h.estado})

    return RedirectResponse(f"/herramientas/{herramienta_id}", status_code=303)


@app.get("/herramientas/{herramienta_id}/pdf", response_class=HTMLResponse)
def herramienta_pdf(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Ficha PDF de herramienta — genera HTML optimizado para impresión."""
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404, "Herramienta no encontrada")

    # QR code de la herramienta
    qr_b64 = None
    try:
        qr_b64 = generar_qr_base64(h.codigo)
    except Exception:
        pass

    estado_info = ESTADOS.get(h.estado, {"label": h.estado, "color": "secondary"})
    movimientos = db.query(Movimiento).filter(
        Movimiento.herramienta_id == h.id
    ).order_by(Movimiento.fecha.desc()).limit(20).all()

    return templates.TemplateResponse(request, "herramienta_pdf.html", {
        **ctx_base(request, user),
        "h": h,
        "qr_b64": qr_b64,
        "estado_info": estado_info,
        "movimientos": movimientos,
        "fecha_impresion": datetime.now().strftime("%d/%m/%Y %H:%M"),
    })


@app.get("/api/herramientas/{herramienta_id}/auditoria")
def herramienta_auditoria_api(
    herramienta_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    limit: int = Query(50, le=200),
):
    """Devuelve los últimos N registros de AuditoriaLog para una herramienta."""
    logs = db.query(AuditoriaLog).filter(
        AuditoriaLog.tabla == "herramientas",
        AuditoriaLog.registro_id == herramienta_id,
    ).order_by(AuditoriaLog.fecha.desc()).limit(limit).all()

    return [{
        "id":       log.id,
        "fecha":    log.fecha.isoformat() if log.fecha else None,
        "accion":   log.accion,
        "resumen":  log.resumen,
        "usuario":  log.usuario.nombre if log.usuario else "Sistema",
        "ip":       log.ip,
        "datos_ant": log.datos_anteriores,
        "datos_nvo": log.datos_nuevos,
    } for log in logs]


@app.get("/api/herramientas/{herramienta_id}/check_serie")
def check_num_serie(
    herramienta_id: int,
    serie: str = Query(...),
    db: Session = Depends(get_db),
    user: Usuario = Depends(requiere_login),
):
    """Verifica si un número de serie ya existe (para validación en formulario)."""
    existe = db.query(Herramienta).filter(
        Herramienta.num_serie == serie,
        Herramienta.id != herramienta_id,  # excluir la propia herramienta al editar
    ).first()
    return {"duplicado": existe is not None, "id_existente": existe.id if existe else None}


# ─── Movimientos ──────────────────────────────────────────────────────────────
@app.get("/movimientos", response_class=HTMLResponse)
def movimientos_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    q: str = "",
    tipo: str = "",
    page: int = 1,
):
    PER_PAGE = 30
    query = db.query(Movimiento).join(Herramienta)
    if q:
        query = query.filter(or_(
            Herramienta.codigo.ilike(f"%{q}%"),
            Herramienta.nombre.ilike(f"%{q}%"),
        ))
    if tipo:
        query = query.filter(Movimiento.tipo == tipo)

    total = query.count()
    movimientos = query.order_by(Movimiento.fecha.desc()).offset((page - 1) * PER_PAGE).limit(PER_PAGE).all()
    total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)

    return templates.TemplateResponse(request, "movimientos.html", ctx_base(
        request, user,
        movimientos=movimientos,
        total=total,
        page=page,
        total_pages=total_pages,
        q=q,
        tipo_filtro=tipo,
    ))


# ─── Trabajadores ─────────────────────────────────────────────────────────────
@app.get("/trabajadores", response_class=HTMLResponse)
def trabajadores_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    trabajadores = db.query(Trabajador).order_by(Trabajador.nombre).all()
    return templates.TemplateResponse(request, "trabajadores.html", ctx_base(request, user, trabajadores=trabajadores))


@app.post("/trabajadores/nuevo")
def trabajador_nuevo(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    apellidos: str = Form(""),
    dni: str = Form(""),
    telefono: str = Form(""),
    email: str = Form(""),
    cargo: str = Form(""),
    empresa: str = Form("MRD Estructuras"),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    t = Trabajador(
        nombre=nombre, apellidos=apellidos or None, dni=dni or None,
        telefono=telefono or None, email=email or None, cargo=cargo or None,
        empresa=empresa, activo=True,
    )
    db.add(t)
    db.commit()
    return RedirectResponse("/trabajadores", status_code=303)



@app.get("/trabajadores/importar/plantilla")
def trabajadores_plantilla(user: Usuario = Depends(requiere_login)):
    excel = generar_plantilla_trabajadores()
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=plantilla_trabajadores.xlsx"},
    )


@app.get("/trabajadores/importar", response_class=HTMLResponse)
def trabajadores_importar_get(request: Request, user: Usuario = Depends(requiere_login)):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    return templates.TemplateResponse(request, "importar_trabajadores.html", ctx_base(request, user))


@app.post("/trabajadores/importar", response_class=HTMLResponse)
async def trabajadores_importar_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    archivo: UploadFile = File(...),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    # Sprint 5.2: validar MIME, magic bytes y tamaño
    try:
        _, _ext_trab = validar_nombre_archivo(archivo.filename, {'xlsx'})
        _head_trab = await archivo.read(16); await archivo.seek(0)
        validar_contenido_archivo(_head_trab, _ext_trab)
        contenido = await archivo.read(); await archivo.seek(0)
        validar_tamaño_bytes(len(contenido), MAX_UPLOAD_MB)
    except ErrorArchivo as _ea:
        return templates.TemplateResponse(request, "importar_trabajadores.html",
            ctx_base(request, user, error=str(_ea)), status_code=400)
    try:
        resultado = importar_trabajadores_excel(contenido, db)
    except Exception as e:
        resultado = {"creados": 0, "actualizados": 0, "errores": [str(e)], "filas_procesadas": 0}
    return templates.TemplateResponse(request, "importar_trabajadores.html", ctx_base(
        request, user,
        resultado=resultado,
    ))


@app.post("/trabajadores/{tid}/toggle")
def trabajador_toggle(tid: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    t = db.query(Trabajador).get(tid)
    if t:
        t.activo = not t.activo
        db.commit()
    return RedirectResponse("/trabajadores", status_code=303)


@app.post("/trabajadores/{tid}/editar", response_class=RedirectResponse)
async def trabajador_editar(
    tid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    t = db.query(Trabajador).get(tid)
    if not t:
        raise HTTPException(404)
    form = await request.form()
    t.nombre = form.get("nombre") or t.nombre
    t.apellidos = form.get("apellidos") or ""
    t.dni = form.get("dni") or None
    t.telefono = form.get("telefono") or None
    t.email = form.get("email") or None
    t.cargo = form.get("cargo") or None
    t.empresa = form.get("empresa") or t.empresa
    t.departamento = form.get("departamento") or None
    t.observaciones = form.get("observaciones") or None
    db.commit()
    return RedirectResponse("/trabajadores?ok=editado", status_code=303)


# ─── EPIs y Ropa de trabajo ───────────────────────────────────────────────────

@app.get("/epis", response_class=HTMLResponse)
def epis_panel(request: Request, user: Usuario = Depends(requiere_login),
               db: Session = Depends(get_db)):
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()

    hoy = datetime.utcnow()
    limite_ropa = hoy - timedelta(days=INTERVALO_ROPA_DIAS)

    resumen = []
    for t in trabajadores:
        entregas = db.query(EntregaEPI).filter(EntregaEPI.trabajador_id == t.id).all()
        tiene_epi = any(e.tipo == "epi" for e in entregas)
        ultima_ropa = next(
            (e for e in sorted([e for e in entregas if e.tipo == "ropa"],
                               key=lambda x: x.fecha, reverse=True)),
            None
        )
        ropa_vencida = ultima_ropa is None or ultima_ropa.fecha < limite_ropa
        dias_ropa = (hoy - ultima_ropa.fecha).days if ultima_ropa else None
        resumen.append({
            "trabajador": t,
            "tiene_epi": tiene_epi,
            "ultima_ropa": ultima_ropa,
            "ropa_vencida": ropa_vencida,
            "dias_ropa": dias_ropa,
            "total_entregas": len(entregas),
        })

    pendientes_epi   = sum(1 for r in resumen if not r["tiene_epi"])
    pendientes_ropa  = sum(1 for r in resumen if r["ropa_vencida"])

    cat_epi  = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "epi",  CatalogoEPI.activo == True).order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    cat_ropa = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "ropa", CatalogoEPI.activo == True).order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    kit_epi  = [{"nombre": c.nombre, "cantidad": c.cantidad_kit} for c in cat_epi]  or KIT_EPI_INICIAL
    kit_ropa = [{"nombre": c.nombre, "cantidad": c.cantidad_kit} for c in cat_ropa] or KIT_ROPA_SEMESTRAL
    return templates.TemplateResponse(request, "epis.html", ctx_base(
        request, user, db,
        resumen=resumen,
        pendientes_epi=pendientes_epi,
        pendientes_ropa=pendientes_ropa,
        kit_epi=kit_epi,
        kit_ropa=kit_ropa,
    ))


@app.get("/trabajadores/{tid}/epis", response_class=HTMLResponse)
def trabajador_epis(tid: int, request: Request,
                    user: Usuario = Depends(requiere_login),
                    db: Session = Depends(get_db)):
    t = db.query(Trabajador).get(tid)
    if not t:
        raise HTTPException(404, "Trabajador no encontrado")
    entregas = db.query(EntregaEPI).filter(
        EntregaEPI.trabajador_id == tid
    ).order_by(EntregaEPI.fecha.desc()).all()

    for e in entregas:
        e._items = json.loads(e.items_json or "[]")

    cat_epi_t  = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "epi",  CatalogoEPI.activo == True).order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    cat_ropa_t = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "ropa", CatalogoEPI.activo == True).order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    kit_epi_t  = [{"nombre": c.nombre, "cantidad": c.cantidad_kit} for c in cat_epi_t]  or KIT_EPI_INICIAL
    kit_ropa_t = [{"nombre": c.nombre, "cantidad": c.cantidad_kit} for c in cat_ropa_t] or KIT_ROPA_SEMESTRAL
    # EPIs individuales (arneses/absorbedores) asignados al trabajador
    epis_individuales_t = db.query(EPIIndividual).filter(
        EPIIndividual.trabajador_id == tid,
        EPIIndividual.estado != "baja"
    ).order_by(EPIIndividual.tipo, EPIIndividual.codigo_fabricacion).all()

    return templates.TemplateResponse(request, "trabajador_epis.html", ctx_base(
        request, user, db,
        trabajador=t,
        entregas=entregas,
        kit_epi=kit_epi_t,
        kit_ropa=kit_ropa_t,
        epis_individuales=epis_individuales_t,
    ))


@app.post("/trabajadores/{tid}/epis/entregar")
async def trabajador_epi_entregar(
    tid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    form = await request.form()
    tipo = form.get("tipo", "epi")
    firmado_por = form.get("firmado_por", "")
    observaciones = form.get("observaciones", "")
    firma_base64 = form.get("firma_base64", "") or None
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    t = db.query(Trabajador).get(tid)
    if not t:
        raise HTTPException(404, "Trabajador no encontrado")

    # ── Procesado flexible: el usuario elige qué artículos incluye ──────────────
    items = []

    # Artículos del catálogo: cada uno tiene item_N_nombre (hidden) +
    # item_N_checked (checkbox) + item_N_cantidad + item_N_talla (ropa)
    n_items = int(form.get("n_items", 0) or 0)
    for i in range(n_items):
        if not form.get(f"item_{i}_checked"):
            continue  # no marcado → no se entrega
        nombre   = (form.get(f"item_{i}_nombre",   "") or "").strip()
        cantidad = max(1, int(form.get(f"item_{i}_cantidad", 1) or 1))
        talla    = (form.get(f"item_{i}_talla",    "") or "").strip() or None
        if nombre:
            items.append({"nombre": nombre, "cantidad": cantidad, "talla": talla})

    # Artículos extra libres (nombre escrito a mano)
    n_extra = int(form.get("n_extra", 0) or 0)
    for i in range(n_extra):
        nombre_e = (form.get(f"extra_{i}_nombre",   "") or "").strip().upper()
        if not nombre_e:
            continue
        cantidad_e = max(1, int(form.get(f"extra_{i}_cantidad", 1) or 1))
        talla_e    = (form.get(f"extra_{i}_talla",  "") or "").strip() or None
        items.append({"nombre": nombre_e, "cantidad": cantidad_e, "talla": talla_e})

    if not items:
        return RedirectResponse(f"/trabajadores/{tid}/epis?err=sin_items", status_code=303)

    # Descontar stock para cada artículo entregado
    for item in items:
        talla_v = item.get("talla")
        stock = db.query(StockEPI).filter(
            StockEPI.nombre == item["nombre"],
            StockEPI.talla == talla_v
        ).first()
        if not stock and talla_v is None:
            # Buscar sin tener en cuenta la talla como fallback
            stock = db.query(StockEPI).filter(StockEPI.nombre == item["nombre"]).first()
        if stock and stock.cantidad > 0:
            stock.cantidad = max(0, stock.cantidad - item["cantidad"])

    entrega = EntregaEPI(
        trabajador_id=tid,
        tipo=tipo,
        items_json=json.dumps(items, ensure_ascii=False),
        fecha=datetime.utcnow(),
        entregado_por=user.nombre,
        firmado_por=firmado_por or None,
        observaciones=observaciones or None,
        usuario_id=user.id,
        firma_base64=firma_base64,
    )
    db.add(entrega)
    db.commit()
    mrd_logging.log_security(
        f"Entrega EPI tipo={tipo} trabajador={t.nombre_completo} por {user.username}",
        level="info"
    )
    redirect_to = (form.get("redirect_to", "") or "").strip()
    redirect_url = redirect_to if redirect_to and redirect_to.startswith("/") else f"/trabajadores/{tid}/epis"
    return RedirectResponse(redirect_url, status_code=303)


# ─── Stock de EPIs ────────────────────────────────────────────────────────────

def _inicializar_stock_epi(db):
    """Crea registros de stock para EPIs si no existen (ropa se añade por talla manualmente)."""
    for item in KIT_EPI_INICIAL:
        if not db.query(StockEPI).filter(
            StockEPI.nombre == item["nombre"], StockEPI.talla == None
        ).first():
            db.add(StockEPI(nombre=item["nombre"], categoria="epi", talla=None, cantidad=0, stock_minimo=3))
    db.commit()


@app.get("/epis/stock", response_class=HTMLResponse)
def epis_stock_panel(request: Request, user: Usuario = Depends(requiere_login),
                     db: Session = Depends(get_db)):
    _inicializar_stock_epi(db)
    todos_epis = db.query(StockEPI).filter(StockEPI.categoria == "epi").order_by(StockEPI.nombre).all()
    # Separar EPIs individualizados (arnes, absorbedor) del resto
    epis = [e for e in todos_epis if e.nombre not in TIPOS_EPI_INDIVIDUAL]
    ropa_rows = db.query(StockEPI).filter(StockEPI.categoria == "ropa").order_by(StockEPI.nombre, StockEPI.talla).all()
    # Calcular stock de arneses/absorbedores desde EPIIndividual
    individuales_stock = {}
    for tipo in TIPOS_EPI_INDIVIDUAL:
        total      = db.query(EPIIndividual).filter(EPIIndividual.tipo == tipo, EPIIndividual.estado != "baja").count()
        sin_asignar = db.query(EPIIndividual).filter(EPIIndividual.tipo == tipo, EPIIndividual.estado != "baja", EPIIndividual.trabajador_id == None).count()
        individuales_stock[tipo] = {"total": total, "sin_asignar": sin_asignar}
    # Agrupar ropa por nombre manteniendo orden del kit
    ropa_grupos = OrderedDict()
    for n in [i["nombre"] for i in KIT_ROPA_SEMESTRAL]:
        ropa_grupos[n] = []
    for row in ropa_rows:
        if row.nombre not in ropa_grupos:
            ropa_grupos[row.nombre] = []
        ropa_grupos[row.nombre].append(row)
    alertas = [i for i in (epis + ropa_rows) if i.bajo_minimo]
    nombres_ropa = [i["nombre"] for i in KIT_ROPA_SEMESTRAL]
    return templates.TemplateResponse(request, "epis_stock.html", ctx_base(
        request, user, db,
        epis=epis,
        individuales_stock=individuales_stock,
        ropa_grupos=list(ropa_grupos.items()),
        nombres_ropa=nombres_ropa,
        alertas=alertas,
    ))


@app.post("/epis/stock/entrada")
def epis_stock_entrada(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    cantidad: int = Form(...),
    talla: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    talla_val = talla.strip() or None
    stock = db.query(StockEPI).filter(
        StockEPI.nombre == nombre, StockEPI.talla == talla_val
    ).first()
    if not stock:
        # Auto-crear para nueva talla
        cat = "ropa" if talla_val else "epi"
        stock = StockEPI(nombre=nombre, categoria=cat, talla=talla_val, cantidad=0, stock_minimo=3)
        db.add(stock)
    stock.cantidad = max(0, stock.cantidad + cantidad)
    db.commit()
    return RedirectResponse("/epis/stock", status_code=303)


@app.post("/epis/stock/minimo")
def epis_stock_minimo(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    stock_minimo: int = Form(...),
    talla: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    talla_val = talla.strip() or None
    stock = db.query(StockEPI).filter(
        StockEPI.nombre == nombre, StockEPI.talla == talla_val
    ).first()
    if stock:
        stock.stock_minimo = max(0, stock_minimo)
        db.commit()
    return RedirectResponse("/epis/stock", status_code=303)


@app.get("/trabajadores/{tid}/epis/{eid}/pdf")
def trabajador_epi_pdf(tid: int, eid: int,
                       user: Usuario = Depends(requiere_login),
                       db: Session = Depends(get_db)):
    t = db.query(Trabajador).get(tid)
    e = db.query(EntregaEPI).filter(
        EntregaEPI.id == eid,
        EntregaEPI.trabajador_id == tid
    ).first()
    if not t or not e:
        raise HTTPException(404)

    items = json.loads(e.items_json or "[]")
    pdf_bytes = _generar_pdf_entrega_epi(t, e, items, COMPANY_NAME)
    tipo_label = "EPI" if e.tipo == "epi" else "Ropa"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"inline; filename=entrega_{tipo_label}_{t.id}_{eid}.pdf"},
    )


def _generar_pdf_entrega_epi(trabajador, entrega, items: list, empresa: str) -> bytes:
    """Genera albarán PDF de entrega de EPI/Ropa."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.pdfgen import canvas
    from reportlab.lib import colors
    from reportlab.lib.utils import ImageReader
    from reportlab.platypus import Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)

    styles = getSampleStyleSheet()
    azul   = colors.HexColor("#1B4F8A")
    naranj = colors.HexColor("#E8600A")
    gris   = colors.HexColor("#555555")

    h1 = ParagraphStyle("h1", parent=styles["Normal"],
                        fontSize=16, fontName="Helvetica-Bold",
                        textColor=azul, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=styles["Normal"],
                        fontSize=11, fontName="Helvetica-Bold",
                        textColor=azul, spaceAfter=4)
    normal = ParagraphStyle("normal", parent=styles["Normal"],
                            fontSize=10, spaceAfter=2)
    small  = ParagraphStyle("small", parent=styles["Normal"],
                            fontSize=8, textColor=gris)
    center = ParagraphStyle("center", parent=styles["Normal"],
                            fontSize=9, alignment=TA_CENTER, textColor=gris)

    tipo_label = "KIT EPI INICIAL" if entrega.tipo == "epi" else "DOTACIÓN DE ROPA SEMESTRAL"
    fecha_str  = entrega.fecha.strftime("%d/%m/%Y") if entrega.fecha else ""

    story = []

    # Cabecera
    story.append(Paragraph(empresa.upper(), h1))
    story.append(Paragraph(f"ALBARÁN DE ENTREGA — {tipo_label}", h2))
    story.append(HRFlowable(width="100%", thickness=1.5, color=azul))
    story.append(Spacer(1, 10))

    # Datos del trabajador
    datos = [
        ["Trabajador:", trabajador.nombre_completo],
        ["DNI:",        trabajador.dni or "—"],
        ["Cargo:",      trabajador.cargo or "—"],
        ["Fecha:",      fecha_str],
        ["Entregado por:", entrega.entregado_por or "—"],
    ]
    t_datos = Table(datos, colWidths=[4*cm, 12*cm])
    t_datos.setStyle(TableStyle([
        ("FONTNAME",  (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTSIZE",  (0,0), (-1,-1), 10),
        ("TEXTCOLOR", (0,0), (0,-1), azul),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(t_datos)
    story.append(Spacer(1, 14))

    # Tabla de items
    story.append(Paragraph("Artículos entregados:", h2))
    story.append(Spacer(1, 4))

    table_data = [["Cant.", "Artículo"]]
    for item in items:
        table_data.append([str(item.get("cantidad", 1)), item.get("nombre", "")])

    t_items = Table(table_data, colWidths=[2.5*cm, 13.5*cm])
    t_items.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), azul),
        ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 10),
        ("ALIGN",        (0,0), (0,-1), "CENTER"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f0f4f8")]),
        ("GRID",         (0,0), (-1,-1), 0.5, colors.HexColor("#cccccc")),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING",   (0,0), (-1,-1), 5),
    ]))
    story.append(t_items)
    story.append(Spacer(1, 20))

    # Observaciones
    if entrega.observaciones:
        story.append(Paragraph(f"Observaciones: {entrega.observaciones}", normal))
        story.append(Spacer(1, 10))

    # Firmas — con imagen digital si existe
    story.append(Spacer(1, 20))

    firma_b64 = getattr(entrega, "firma_base64", None)
    if firma_b64:
        # Insertar imagen de firma sobre la línea
        try:
            import base64 as _b64
            raw = firma_b64
            if "," in raw:
                raw = raw.split(",", 1)[1]
            img_data = _b64.b64decode(raw)
            from io import BytesIO as _BytesIO
            from reportlab.platypus import Image as _Img
            img_buf = _BytesIO(img_data)
            firma_img = _Img(img_buf, width=7*cm, height=2.5*cm)
            firma_img.hAlign = "LEFT"
            firmas = [
                [firma_img, ""],
                ["____________________________", "____________________________"],
                [f"Entregado por: {entrega.entregado_por or ''}", f"Recibido conforme: {entrega.firmado_por or ''}"],
            ]
        except Exception:
            firma_img = None
            firmas = [
                ["", ""],
                ["____________________________", "____________________________"],
                [f"Entregado por: {entrega.entregado_por or ''}", f"Recibido conforme: {entrega.firmado_por or ''}"],
            ]
    else:
        firmas = [
            ["", ""],
            ["____________________________", "____________________________"],
            [f"Entregado por: {entrega.entregado_por or ''}", f"Recibido conforme: {entrega.firmado_por or ''}"],
        ]

    t_firmas = Table(firmas, colWidths=[8*cm, 8*cm])
    t_firmas.setStyle(TableStyle([
        ("FONTNAME",  (0,2), (-1,2), "Helvetica-Bold"),
        ("FONTSIZE",  (0,0), (-1,-1), 9),
        ("ALIGN",     (0,0), (-1,-1), "CENTER"),
        ("TEXTCOLOR", (0,2), (-1,2), gris),
        ("VALIGN",    (0,0), (-1,-1), "BOTTOM"),
    ]))
    story.append(t_firmas)
    story.append(Spacer(1, 14))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc")))

    # QR apuntando a la ficha del trabajador
    try:
        import qrcode as _qr
        from io import BytesIO as _BytesIO2
        qr_url = f"/trabajadores/{trabajador.id}/epis"
        qr_img = _qr.make(qr_url)
        qr_buf = _BytesIO2()
        qr_img.save(qr_buf, format="PNG")
        qr_buf.seek(0)
        from reportlab.platypus import Image as _ImgQR
        qr_elem = _ImgQR(qr_buf, width=1.8*cm, height=1.8*cm)
        pie_data = [
            [qr_elem, f"Documento generado automáticamente — MRD TOOL CONTROL · {fecha_str}\nEscanea el QR para ver el historial completo del trabajador"],
        ]
        t_pie = Table(pie_data, colWidths=[2.2*cm, 13.8*cm])
        t_pie.setStyle(TableStyle([
            ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
            ("FONTSIZE", (1,0), (1,0), 7),
            ("TEXTCOLOR", (1,0), (1,0), gris),
        ]))
        story.append(Spacer(1, 4))
        story.append(t_pie)
    except Exception:
        story.append(Paragraph(
            f"Documento generado automáticamente — MRD TOOL CONTROL · {fecha_str}",
            center))

    doc.build(story)
    return buf.getvalue()



@app.post("/epis/stock/nueva-talla")
def epis_stock_nueva_talla(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    talla: str = Form(...),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    talla_val = talla.strip()
    if not talla_val:
        return RedirectResponse("/epis/stock", status_code=303)
    existing = db.query(StockEPI).filter(
        StockEPI.nombre == nombre, StockEPI.talla == talla_val
    ).first()
    if not existing:
        db.add(StockEPI(nombre=nombre, categoria="ropa", talla=talla_val, cantidad=0, stock_minimo=3))
        db.commit()
    return RedirectResponse("/epis/stock", status_code=303)


# ─── EPIs individuales (arneses y absorbedores con nº de serie y revisiones) ──

# ─── Albarán PDF — EPIs individuales (arneses / absorbedores) ────────────────

def _generar_pdf_epi_individual(trabajador, items: list, usuario_entrega: str, empresa: str) -> bytes:
    """Genera albarán PDF de entrega de EPIs individualizados."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                    Table, TableStyle, HRFlowable)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from datetime import datetime as _dt

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    azul   = colors.HexColor("#1B4F8A")
    naranj = colors.HexColor("#E8600A")
    gris   = colors.HexColor("#555555")

    h1     = ParagraphStyle("h1",  parent=styles["Normal"], fontSize=16,
                            fontName="Helvetica-Bold", textColor=azul, spaceAfter=4)
    h2     = ParagraphStyle("h2",  parent=styles["Normal"], fontSize=11,
                            fontName="Helvetica-Bold", textColor=azul, spaceAfter=4)
    normal = ParagraphStyle("norm",parent=styles["Normal"], fontSize=10, spaceAfter=2)
    small  = ParagraphStyle("sm",  parent=styles["Normal"], fontSize=8, textColor=gris)
    center = ParagraphStyle("ctr", parent=styles["Normal"], fontSize=9,
                            alignment=TA_CENTER, textColor=gris)

    story = []
    story.append(Paragraph(empresa.upper(), h1))
    story.append(Paragraph("ALBARÁN DE ENTREGA — EQUIPOS DE PROTECCIÓN INDIVIDUAL", h2))
    story.append(HRFlowable(width="100%", thickness=1.5, color=azul))
    story.append(Spacer(1, 10))

    datos = [
        ["Trabajador:",   trabajador.nombre_completo],
        ["DNI:",          trabajador.dni or "—"],
        ["Cargo:",        trabajador.cargo or "—"],
        ["Fecha entrega:", _dt.now().strftime("%d/%m/%Y %H:%M")],
        ["Entregado por:", usuario_entrega],
    ]
    t_datos = Table(datos, colWidths=[4*cm, 13*cm])
    t_datos.setStyle(TableStyle([
        ("FONTNAME",      (0,0),(0,-1), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0),(-1,-1), 10),
        ("TEXTCOLOR",     (0,0),(0,-1), azul),
        ("BOTTOMPADDING", (0,0),(-1,-1), 4),
    ]))
    story.append(t_datos)
    story.append(Spacer(1, 14))

    story.append(Paragraph("Equipos entregados:", h2))
    story.append(Spacer(1, 4))

    table_data = [["Tipo", "Nº Serie / Código", "Marca / Modelo",
                   "Fecha fab.", "Próx. revisión"]]
    for it in items:
        prox = it.proxima_revision.strftime("%d/%m/%Y") if it.proxima_revision else "—"
        fab  = it.fecha_fabricacion.strftime("%d/%m/%Y") if it.fecha_fabricacion else "—"
        table_data.append([
            it.tipo,
            it.codigo_fabricacion or "—",
            f"{it.marca or ''} {it.modelo or ''}".strip() or "—",
            fab,
            prox,
        ])
    t_items = Table(table_data, colWidths=[3*cm, 4*cm, 4.5*cm, 2.5*cm, 3*cm])
    t_items.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,0), azul),
        ("TEXTCOLOR",     (0,0),(-1,0), colors.white),
        ("FONTNAME",      (0,0),(-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0),(-1,-1), 9),
        ("ALIGN",         (0,0),(-1,-1), "CENTER"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.white, colors.HexColor("#f0f4f8")]),
        ("GRID",          (0,0),(-1,-1), 0.5, colors.HexColor("#cccccc")),
        ("BOTTOMPADDING", (0,0),(-1,-1), 5),
        ("TOPPADDING",    (0,0),(-1,-1), 5),
    ]))
    story.append(t_items)
    story.append(Spacer(1, 28))

    # Firmas
    firma_data = [
        [Paragraph("Entregado por:", small), "", Paragraph("Recibido por (firma y DNI):", small)],
        ["", "", ""],
        ["", "", ""],
        [Paragraph(f"<b>{usuario_entrega}</b>", small), "",
         Paragraph(f"<b>{trabajador.nombre_completo}</b>", small)],
    ]
    t_firma = Table(firma_data, colWidths=[7*cm, 3*cm, 7*cm])
    t_firma.setStyle(TableStyle([
        ("LINEABOVE",     (0,2),(0,2), 0.8, colors.black),
        ("LINEABOVE",     (2,2),(2,2), 0.8, colors.black),
        ("FONTSIZE",      (0,0),(-1,-1), 9),
        ("ALIGN",         (0,0),(-1,-1), "CENTER"),
        ("ROWBACKGROUNDS",(0,0),(-1,-1), [colors.white]),
        ("MINROWHEIGHT",  (0,1),(-1,1), 35),
    ]))
    story.append(t_firma)
    story.append(Spacer(1, 10))
    story.append(Paragraph(
        "El trabajador declara haber recibido los equipos en perfecto estado y se compromete "
        "a usarlos según las instrucciones del fabricante y la normativa vigente (R.D. 773/1997).",
        small))

    # QR al pie del albarán de arneses/absorbedores
    try:
        import qrcode as _qr3
        from io import BytesIO as _BytesIO4
        qr_img3 = _qr3.make(f"{MRD_PUBLIC_URL}/trabajadores/{trabajador.id}/epis")
        qr_buf3 = _BytesIO4()
        qr_img3.save(qr_buf3, format="PNG")
        qr_buf3.seek(0)
        from reportlab.platypus import Image as _ImgQR3
        story.append(Spacer(1, 8))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cccccc")))
        story.append(Spacer(1, 4))
        pie3 = Table(
            [[_ImgQR3(qr_buf3, width=1.6*cm, height=1.6*cm),
              "Escanea el QR para ver el historial completo del trabajador en MRD TOOL CONTROL."]],
            colWidths=[2*cm, 14*cm]
        )
        pie3.setStyle(TableStyle([
            ("VALIGN", (0,0),(-1,-1),"MIDDLE"),
            ("FONTSIZE",(1,0),(1,0),7),
            ("TEXTCOLOR",(1,0),(1,0),colors.HexColor("#555555")),
        ]))
        story.append(pie3)
    except Exception:
        pass

    doc.build(story)
    return buf.getvalue()


@app.post("/epis/individuales/asignar-lote")
def epi_individual_asignar_lote(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Asigna varios EPIIndividual a un trabajador y devuelve albarán PDF."""
    import urllib.parse as _up
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")

    # Lee form sincrónicamente (datos simples)
    body = None
    # FastAPI no expone form() aquí sincrónicamente — usamos un workaround:
    # los datos llegan como application/x-www-form-urlencoded en request.body
    # Pero como la función es síncrona, usamos el scope ASGI
    form_data = {}
    # Se leen a través de la DB de request state (ver abajo)
    raise HTTPException(500, "Use la versión async")


@app.post("/epis/individuales/asignar-lote-v2")
async def epi_individual_asignar_lote_v2(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Asigna varios EPIIndividual a un trabajador y devuelve albarán PDF."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")

    form = await request.form()
    trabajador_id = form.get("trabajador_id", "")
    epi_ids_raw   = form.getlist("epi_ids")

    if not trabajador_id:
        return RedirectResponse("/epis/individuales?err=sin_trabajador", status_code=303)
    if not epi_ids_raw:
        return RedirectResponse("/epis/individuales?err=sin_items", status_code=303)

    t = db.query(Trabajador).get(int(trabajador_id))
    if not t:
        raise HTTPException(404, "Trabajador no encontrado")

    items = []
    ya_asignados = []
    for eid_str in epi_ids_raw:
        epi = db.query(EPIIndividual).get(int(eid_str))
        if not epi or epi.estado == "baja":
            continue
        if epi.trabajador_id and epi.trabajador_id != int(trabajador_id):
            # Ya asignado a otro trabajador — no se puede reasignar sin devolución
            ya_asignados.append(f"{epi.tipo} {epi.codigo_fabricacion}")
            continue
        if epi.trabajador_id != int(trabajador_id):
            db.add(HistorialEPIIndividual(
                epi_id=epi.id,
                trabajador_id=int(trabajador_id),
                fecha_asignacion=datetime.utcnow(),
                usuario_id=user.id,
            ))
        epi.trabajador_id = int(trabajador_id)
        items.append(epi)
    db.commit()

    if not items and ya_asignados:
        from urllib.parse import quote
        msg = quote("Los equipos seleccionados ya están asignados a otro trabajador. Devuélvelos primero.")
        return RedirectResponse(f"/epis/individuales?err=ya_asignados&msg={msg}", status_code=303)
    if not items:
        return RedirectResponse("/epis/individuales?err=sin_items", status_code=303)

    mrd_logging.log_app(
        f"Asignación lote EPIs individuales: {len(items)} equipos a {t.nombre_completo} por {user.nombre}",
        level="info"
    )

    pdf_bytes = _generar_pdf_epi_individual(t, items, user.nombre, COMPANY_NAME)
    nombre = f"albaran_epi_{t.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"inline; filename={nombre}"},
    )


@app.post("/epis/individuales/baja-masiva")
async def epi_individual_baja_masiva(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Da de baja varios EPIs individuales seleccionados."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    form = await request.form()
    epi_ids_raw = form.getlist("epi_ids")
    if not epi_ids_raw:
        return RedirectResponse("/epis/individuales?err=sin_seleccion", status_code=303)
    count = 0
    for eid_str in epi_ids_raw:
        try:
            epi = db.query(EPIIndividual).get(int(eid_str))
            if epi and epi.estado != "baja":
                # Cerrar historial abierto si está asignado
                if epi.trabajador_id:
                    reg = db.query(HistorialEPIIndividual).filter(
                        HistorialEPIIndividual.epi_id == epi.id,
                        HistorialEPIIndividual.trabajador_id == epi.trabajador_id,
                        HistorialEPIIndividual.fecha_devolucion == None,
                    ).first()
                    if reg:
                        reg.fecha_devolucion = datetime.utcnow()
                epi.estado = "baja"
                epi.trabajador_id = None
                count += 1
        except (ValueError, TypeError):
            continue
    db.commit()
    mrd_logging.log_app(f"Baja masiva: {count} EPIs dados de baja por {user.nombre}", level="info")
    return RedirectResponse(f"/epis/individuales?ok=baja_masiva&n={count}", status_code=303)


@app.get("/epis/individuales/pdf-inventario")
def epi_individual_pdf_inventario(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """PDF con inventario completo de EPIs individuales."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                    Table, TableStyle, HRFlowable)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from datetime import datetime as _dt

    items = db.query(EPIIndividual).filter(
        EPIIndividual.estado != "baja"
    ).order_by(EPIIndividual.tipo, EPIIndividual.codigo_fabricacion).all()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=1.5*cm, rightMargin=1.5*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    azul  = colors.HexColor("#1B4F8A")
    gris  = colors.HexColor("#555555")
    rojo  = colors.HexColor("#dc3545")
    verde = colors.HexColor("#198754")
    naranj = colors.HexColor("#fd7e14")

    h1    = ParagraphStyle("h1",  parent=styles["Normal"], fontSize=14,
                           fontName="Helvetica-Bold", textColor=azul, spaceAfter=2)
    small = ParagraphStyle("sm",  parent=styles["Normal"], fontSize=7, textColor=gris)
    center = ParagraphStyle("ctr",parent=styles["Normal"], fontSize=7,
                            alignment=TA_CENTER, textColor=gris)

    story = []
    story.append(Paragraph(COMPANY_NAME.upper(), h1))
    story.append(Paragraph(
        f"INVENTARIO EPIs INDIVIDUALES — Generado: {_dt.now().strftime('%d/%m/%Y %H:%M')}",
        ParagraphStyle("sub", parent=styles["Normal"], fontSize=9, textColor=azul, spaceAfter=4)
    ))
    story.append(HRFlowable(width="100%", thickness=1.5, color=azul))
    story.append(Spacer(1, 10))

    # Resumen KPI
    total = len(items)
    libres = sum(1 for e in items if not e.trabajador_id)
    asignados = total - libres
    vencidos = sum(1 for e in items if e.revision_vencida)
    kpi_data = [
        ["Total activos", "Disponibles", "Asignados", "Rev. vencida"],
        [str(total), str(libres), str(asignados), str(vencidos)],
    ]
    t_kpi = Table(kpi_data, colWidths=[4.5*cm]*4)
    t_kpi.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,0), azul),
        ("TEXTCOLOR",     (0,0),(-1,0), colors.white),
        ("FONTNAME",      (0,0),(-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0),(-1,-1), 10),
        ("ALIGN",         (0,0),(-1,-1), "CENTER"),
        ("GRID",          (0,0),(-1,-1), 0.5, colors.HexColor("#cccccc")),
        ("BOTTOMPADDING", (0,0),(-1,-1), 6),
        ("TOPPADDING",    (0,0),(-1,-1), 6),
        ("TEXTCOLOR",     (0,1),(0,1), azul),
        ("TEXTCOLOR",     (3,1),(3,1), rojo if vencidos else verde),
        ("FONTNAME",      (0,1),(-1,1), "Helvetica-Bold"),
    ]))
    story.append(t_kpi)
    story.append(Spacer(1, 14))

    table_data = [["Tipo", "Código/Serie", "Marca/Modelo", "Asignado a", "Estado", "Próx. revisión"]]
    for e in items:
        prox_str = ""
        prox_color = colors.black
        if e.proxima_revision:
            prox_str = e.proxima_revision.strftime("%d/%m/%Y")
            if e.revision_vencida:
                prox_color = rojo
            elif e.dias_para_revision is not None and e.dias_para_revision <= 30:
                prox_color = naranj
        asig = e.trabajador.nombre_completo if e.trabajador else "—"
        estado_str = {"activo": "Activo", "en_revision": "En revisión", "baja": "Baja"}.get(e.estado, e.estado)
        table_data.append([
            e.tipo,
            e.codigo_fabricacion or "—",
            f"{e.marca or ''} {e.modelo or ''}".strip() or "—",
            asig,
            estado_str,
            Paragraph(f'<font color="{prox_color.hexval() if hasattr(prox_color,"hexval") else "#000000"}">{prox_str or "—"}</font>', small) if prox_str else "—",
        ])

    t_items = Table(table_data, colWidths=[2.5*cm, 3.5*cm, 3.5*cm, 4.5*cm, 2*cm, 2.5*cm])
    t_items.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,0), azul),
        ("TEXTCOLOR",     (0,0),(-1,0), colors.white),
        ("FONTNAME",      (0,0),(-1,0), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0),(-1,-1), 8),
        ("ALIGN",         (0,0),(-1,-1), "CENTER"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.white, colors.HexColor("#f0f4f8")]),
        ("GRID",          (0,0),(-1,-1), 0.5, colors.HexColor("#cccccc")),
        ("BOTTOMPADDING", (0,0),(-1,-1), 4),
        ("TOPPADDING",    (0,0),(-1,-1), 4),
    ]))
    story.append(t_items)
    doc.build(story)
    pdf_bytes = buf.getvalue()
    nombre = f"inventario_epis_{_dt.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": f"inline; filename={nombre}"})


@app.post("/epis/individuales/alerta-revision")
def epi_alerta_revision_manual(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Envía aviso interno con EPIs vencidos/próximos."""
    if not tiene_permiso(user, "admin"):
        raise HTTPException(403, "Sin permiso")
    hoy = date.today()
    prox_30 = hoy + timedelta(days=30)
    vencidos = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.proxima_revision != None,
        EPIIndividual.proxima_revision < hoy,
    ).all()
    proximos = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.proxima_revision != None,
        EPIIndividual.proxima_revision >= hoy,
        EPIIndividual.proxima_revision <= prox_30,
    ).all()
    lineas = []
    if vencidos:
        lineas.append(f"EPIs con revision VENCIDA ({len(vencidos)}):")
        for e in vencidos:
            ts = e.trabajador.nombre_completo if e.trabajador else "Sin asignar"
            lineas.append(f"  - {e.tipo} {e.codigo_fabricacion} - {ts} - vencida: {e.proxima_revision}")
    if proximos:
        lineas.append(f"EPIs con revision proxima en 30 dias ({len(proximos)}):")
        for e in proximos:
            ts = e.trabajador.nombre_completo if e.trabajador else "Sin asignar"
            lineas.append(f"  - {e.tipo} {e.codigo_fabricacion} - {ts} - revision: {e.proxima_revision} ({e.dias_para_revision} dias)")
    if not lineas:
        return RedirectResponse("/epis/individuales?ok=sin_alertas", status_code=303)
    mensaje = "\n".join(lineas)
    try:
        aviso = Aviso(
            titulo=f"Alerta revision EPIs - {hoy.strftime('%d/%m/%Y')}",
            mensaje=mensaje,
            prioridad="alta" if vencidos else "media",
            usuario_id=user.id,
        )
        db.add(aviso)
        db.commit()
        notif_engine.notificar_aviso(db, aviso)
    except Exception as _err:
        mrd_logging.log_app(f"Error enviando alerta EPIs: {_err}", level="warning")
    mrd_logging.log_app(
        f"Alerta EPIs enviada por {user.nombre}: {len(vencidos)} vencidos, {len(proximos)} proximos",
        level="info"
    )
    total = len(vencidos) + len(proximos)
    return RedirectResponse(f"/epis/individuales?ok=alertas&n={total}", status_code=303)


@app.get("/epis/individuales/plantilla-excel")
def epi_individual_plantilla_excel(user: Usuario = Depends(requiere_login)):
    """Descarga plantilla Excel para importación masiva de EPIs individuales."""
    from openpyxl import Workbook as _WB
    from openpyxl.styles import Font as _Font, PatternFill as _Fill, Alignment as _Align
    from openpyxl.utils import get_column_letter as _gcl
    import io as _io

    wb = _WB(); ws = wb.active; ws.title = "EPIs Individuales"
    fill_h = _Fill("solid", fgColor="1B4F8A")
    fill_e = _Fill("solid", fgColor="FFF3CD")

    cols = [
        ("tipo*", 18, "ARNES o ABSORBEDOR"),
        ("codigo_fabricacion*", 24, "Nº serie del fabricante"),
        ("marca", 18, "Marca (opcional)"),
        ("modelo", 18, "Modelo (opcional)"),
        ("fecha_fabricacion", 18, "YYYY-MM-DD (opcional)"),
        ("fecha_puesta_servicio", 20, "YYYY-MM-DD (opcional)"),
        ("proxima_revision", 18, "YYYY-MM-DD (opcional)"),
        ("notas", 30, "Observaciones (opcional)"),
    ]
    for c, (header, width, nota) in enumerate(cols, 1):
        cell = ws.cell(row=1, column=c, value=header)
        cell.font = _Font(bold=True, color="FFFFFF", size=11)
        cell.fill = fill_h
        cell.alignment = _Align(horizontal="center")
        ws.column_dimensions[_gcl(c)].width = width

        nota_cell = ws.cell(row=2, column=c, value=nota)
        nota_cell.font = _Font(italic=True, size=9, color="555555")
        nota_cell.fill = fill_e
        nota_cell.alignment = _Align(horizontal="center")

    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 18

    # Filas de ejemplo
    ejemplos = [
        ["ARNES", "AH-2024-001", "Petzl", "Avao Bod Croll", "2022-01-15", "2022-03-01", "2025-03-01", ""],
        ["ABSORBEDOR", "AB-2024-002", "MSA", "Latchways", "2021-06-10", "2021-09-01", "2024-09-01", "Revisar costuras"],
    ]
    for r, fila in enumerate(ejemplos, 3):
        for c, val in enumerate(fila, 1):
            ws.cell(row=r, column=c, value=val)

    buf = _io.BytesIO()
    wb.save(buf); buf.seek(0)
    return Response(
        content=buf.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=plantilla_epis_individuales.xlsx"},
    )


@app.post("/epis/individuales/importar")
async def epi_individual_importar(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    archivo: UploadFile = File(...),
):
    """Importa EPIs individuales desde Excel."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    from openpyxl import load_workbook as _lw
    import io as _io

    contenido = await archivo.read()
    try:
        wb = _lw(_io.BytesIO(contenido), read_only=True, data_only=True)
        ws = wb.active
    except Exception as ex:
        return RedirectResponse(f"/epis/individuales?err=excel_invalido", status_code=303)

    creados = 0; errores = []
    tipos_validos = {t.upper() for t in TIPOS_EPI_INDIVIDUAL}

    for row_idx, row in enumerate(ws.iter_rows(min_row=3, values_only=True), start=3):
        tipo_raw = str(row[0] or "").strip().upper() if row[0] else ""
        codigo   = str(row[1] or "").strip() if row[1] else ""
        if not tipo_raw or not codigo:
            continue
        if tipo_raw not in tipos_validos:
            errores.append(f"Fila {row_idx}: tipo '{tipo_raw}' no válido")
            continue
        # Evitar duplicados por código de fabricación
        existe = db.query(EPIIndividual).filter(EPIIndividual.codigo_fabricacion == codigo).first()
        if existe:
            errores.append(f"Fila {row_idx}: código '{codigo}' ya existe")
            continue

        def _parse_date(v):
            if not v: return None
            import re
            s = str(v).strip()
            try:
                from datetime import datetime as _dt
                for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                    try: return _dt.strptime(s, fmt).date()
                    except: pass
            except: pass
            return None

        epi = EPIIndividual(
            tipo=tipo_raw,
            codigo_fabricacion=codigo,
            marca=str(row[2] or "").strip() or None,
            modelo=str(row[3] or "").strip() or None,
            fecha_fabricacion=_parse_date(row[4]),
            fecha_puesta_servicio=_parse_date(row[5]),
            proxima_revision=_parse_date(row[6]),
            notas=str(row[7] or "").strip() or None,
            estado="activo",
        )
        db.add(epi)
        creados += 1

    db.commit()
    mrd_logging.log_app(f"Importación EPIs individuales: {creados} creados por {user.nombre}", level="info")
    from urllib.parse import quote as _q
    msg = f"{creados} equipos importados"
    if errores:
        msg += f" | {len(errores)} errores: " + "; ".join(errores[:3])
    return RedirectResponse(f"/epis/individuales?ok={_q(msg)}", status_code=303)


@app.get("/epis/individuales", response_class=HTMLResponse)
def epis_individuales_panel(request: Request, user: Usuario = Depends(requiere_login),
                            db: Session = Depends(get_db)):
    items = db.query(EPIIndividual).filter(EPIIndividual.estado != "baja").order_by(
        EPIIndividual.tipo, EPIIndividual.codigo_fabricacion
    ).all()
    por_revisar = [i for i in items if i.revision_vencida]
    proximos    = [i for i in items if not i.revision_vencida and i.proxima_revision and
                   i.dias_para_revision is not None and i.dias_para_revision <= 30]
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    # Stock disponible (sin asignar) por tipo
    stock_disponible = {}
    for tipo in TIPOS_EPI_INDIVIDUAL:
        stock_disponible[tipo] = db.query(EPIIndividual).filter(
            EPIIndividual.tipo == tipo,
            EPIIndividual.estado != "baja",
            EPIIndividual.trabajador_id == None
        ).count()
    return templates.TemplateResponse(request, "epis_individuales.html", ctx_base(
        request, user, db,
        items=items,
        por_revisar=por_revisar,
        proximos=proximos,
        trabajadores=trabajadores,
        tipos=TIPOS_EPI_INDIVIDUAL,
        stock_disponible=stock_disponible,
    ))


@app.post("/epis/individuales")
def epis_individuales_crear(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    tipo: str = Form(...),
    codigo_fabricacion: str = Form(...),
    marca: str = Form(""),
    modelo: str = Form(""),
    fecha_fabricacion: str = Form(""),
    fecha_puesta_servicio: str = Form(""),
    trabajador_id: str = Form(""),
    proxima_revision: str = Form(""),
    notas: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")

    def _pd(s):
        try: return date.fromisoformat(s) if s else None
        except Exception: return None

    epi = EPIIndividual(
        tipo=tipo.upper(),
        codigo_fabricacion=codigo_fabricacion.strip(),
        marca=marca.strip() or None,
        modelo=modelo.strip() or None,
        fecha_fabricacion=_pd(fecha_fabricacion),
        fecha_puesta_servicio=_pd(fecha_puesta_servicio),
        trabajador_id=int(trabajador_id) if trabajador_id.strip() else None,
        proxima_revision=_pd(proxima_revision),
        notas=notas.strip() or None,
        estado="activo",
    )
    db.add(epi)
    db.commit()
    mrd_logging.log_security(
        f"Nuevo EPI individual tipo={tipo} cod={codigo_fabricacion} por {user.username}",
        level="info"
    )
    return RedirectResponse("/epis/individuales", status_code=303)


@app.get("/epis/individuales/{eid}", response_class=HTMLResponse)
def epi_individual_detalle(eid: int, request: Request,
                           user: Usuario = Depends(requiere_login),
                           db: Session = Depends(get_db)):
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    return templates.TemplateResponse(request, "epi_individual_detalle.html", ctx_base(
        request, user, db,
        epi=epi,
        trabajadores=trabajadores,
        intervalo_dias=INTERVALO_REVISION_EPI_DIAS,
        historial_epi=epi.historial,
    ))


@app.post("/epis/individuales/{eid}/revision")
def epi_individual_revision(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    resultado: str = Form(...),
    tecnico: str = Form(""),
    proxima_revision: str = Form(""),
    observaciones: str = Form(""),
    back: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")

    def _pd(s):
        try: return date.fromisoformat(s) if s else None
        except Exception: return None

    prox = _pd(proxima_revision)
    rev = RevisionEPI(
        epi_id=eid,
        fecha=datetime.utcnow(),
        resultado=resultado,
        tecnico=tecnico.strip() or None,
        proxima_revision=prox,
        observaciones=observaciones.strip() or None,
        usuario_id=user.id,
    )
    db.add(rev)
    epi.estado = "baja" if resultado == "retirar" else ("en_revision" if resultado == "en_revision" else "activo")
    if prox:
        epi.proxima_revision = prox
    db.commit()
    mrd_logging.log_security(
        f"Revisión EPI id={eid} resultado={resultado} por {user.username}", level="info"
    )
    _back = back.strip() if back and back.strip().startswith("/") else f"/epis/individuales/{eid}"
    return RedirectResponse(_back, status_code=303)


@app.post("/epis/individuales/{eid}/asignar")
def epi_individual_asignar(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    trabajador_id: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    nuevo_tid = int(trabajador_id) if trabajador_id.strip() else None
    if nuevo_tid and nuevo_tid != epi.trabajador_id:
        if epi.trabajador_id:
            reg_ant = db.query(HistorialEPIIndividual).filter(
                HistorialEPIIndividual.epi_id == eid,
                HistorialEPIIndividual.trabajador_id == epi.trabajador_id,
                HistorialEPIIndividual.fecha_devolucion == None,
            ).first()
            if reg_ant:
                reg_ant.fecha_devolucion = datetime.utcnow()
        db.add(HistorialEPIIndividual(
            epi_id=epi.id,
            trabajador_id=nuevo_tid,
            fecha_asignacion=datetime.utcnow(),
            usuario_id=user.id,
        ))
    epi.trabajador_id = nuevo_tid
    db.commit()
    return RedirectResponse(f"/epis/individuales/{eid}", status_code=303)


@app.post("/epis/individuales/{eid}/devolver")
def epi_individual_devolver(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Desasigna el EPI individual del trabajador actual, deja disponible."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    anterior = epi.trabajador.nombre_completo if epi.trabajador else "nadie"
    anterior_id = epi.trabajador_id
    if anterior_id:
        registro_abierto = db.query(HistorialEPIIndividual).filter(
            HistorialEPIIndividual.epi_id == eid,
            HistorialEPIIndividual.trabajador_id == anterior_id,
            HistorialEPIIndividual.fecha_devolucion == None,
        ).first()
        if registro_abierto:
            registro_abierto.fecha_devolucion = datetime.utcnow()
    epi.trabajador_id = None
    db.commit()
    mrd_logging.log_app(
        f"EPI {epi.tipo} {epi.codigo_fabricacion} devuelto (era de {anterior}) por {user.nombre}",
        level="info"
    )
    return RedirectResponse(f"/epis/individuales/{eid}?ok=devuelto", status_code=303)


@app.post("/epis/individuales/{eid}/baja")
def epi_individual_baja(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    epi.estado = "baja"
    db.commit()
    return RedirectResponse("/epis/individuales", status_code=303)


@app.post("/epis/individuales/{eid}/renovar-revision")
def epi_individual_renovar_revision(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    tecnico: str = Form(""),
    observaciones: str = Form(""),
):
    """Marca revisión como realizada hoy y calcula próxima automáticamente."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    hoy = date.today()
    prox = hoy + timedelta(days=INTERVALO_REVISION_EPI_DIAS)
    rev = RevisionEPI(
        epi_id=eid,
        fecha=datetime.utcnow(),
        resultado="apto",
        tecnico=tecnico.strip() or user.nombre,
        proxima_revision=prox,
        observaciones=observaciones.strip() or "Revisión periódica realizada",
        usuario_id=user.id,
    )
    db.add(rev)
    epi.proxima_revision = prox
    epi.estado = "activo"
    db.commit()
    mrd_logging.log_app(
        f"Revisión renovada EPI id={eid} por {user.nombre} — próxima: {prox}",
        level="info"
    )
    return RedirectResponse(f"/epis/individuales/{eid}?ok=revision", status_code=303)


@app.post("/epis/individuales/{eid}/foto")
async def epi_individual_subir_foto(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    foto: UploadFile = File(...),
):
    """Sube foto del EPI individual."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    ext = Path(foto.filename).suffix.lower() if foto.filename else ".jpg"
    if ext not in {".jpg", ".jpeg", ".png", ".webp"}:
        ext = ".jpg"
    carpeta = BASE_DIR / "static" / "uploads" / "epis"
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre = f"epi_{eid}_{int(datetime.utcnow().timestamp())}{ext}"
    if epi.foto_path:
        old_p = carpeta / epi.foto_path
        if old_p.exists():
            old_p.unlink(missing_ok=True)
    content = await foto.read()
    (carpeta / nombre).write_bytes(content)
    epi.foto_path = nombre
    db.commit()
    return RedirectResponse(f"/epis/individuales/{eid}?ok=foto", status_code=303)


@app.post("/epis/individuales/{eid}/foto/eliminar")
def epi_individual_eliminar_foto(
    eid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    epi = db.query(EPIIndividual).get(eid)
    if not epi:
        raise HTTPException(404, "EPI no encontrado")
    if epi.foto_path:
        p = BASE_DIR / "static" / "uploads" / "epis" / epi.foto_path
        if p.exists():
            p.unlink(missing_ok=True)
        epi.foto_path = None
        db.commit()
    return RedirectResponse(f"/epis/individuales/{eid}?ok=foto_eliminada", status_code=303)


# ─── Catálogo EPIs — gestión dinámica ────────────────────────────────────────

@app.get("/epis/catalogo", response_class=HTMLResponse)
def epis_catalogo(request: Request, user: Usuario = Depends(requiere_login),
                  db: Session = Depends(get_db)):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    items_epi  = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "epi" ).order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    items_ropa = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == "ropa").order_by(CatalogoEPI.orden, CatalogoEPI.nombre).all()
    return templates.TemplateResponse(request, "epis_catalogo.html", ctx_base(
        request, user, db,
        items_epi=items_epi,
        items_ropa=items_ropa,
    ))


@app.post("/epis/catalogo/nuevo")
async def epis_catalogo_nuevo(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    form = await request.form()
    nombre    = (form.get("nombre", "") or "").strip().upper()
    categoria = form.get("categoria", "epi")
    cantidad  = max(1, int(form.get("cantidad_kit", 1) or 1))
    notas     = (form.get("notas", "") or "").strip()[:200]
    if not nombre:
        return RedirectResponse("/epis/catalogo?err=nombre_vacio", status_code=303)
    if categoria not in ("epi", "ropa"):
        categoria = "epi"
    existe = db.query(CatalogoEPI).filter(CatalogoEPI.nombre == nombre).first()
    if existe:
        if not existe.activo:
            existe.activo = True
            db.commit()
        return RedirectResponse("/epis/catalogo?ok=reactivado", status_code=303)
    orden_max = db.query(CatalogoEPI).filter(CatalogoEPI.categoria == categoria).count()
    item = CatalogoEPI(nombre=nombre, categoria=categoria, cantidad_kit=cantidad,
                       activo=True, orden=orden_max, notas=notas or None)
    db.add(item)
    db.commit()
    # Crear entrada de stock si no existe
    stock = db.query(StockEPI).filter(StockEPI.nombre == nombre, StockEPI.talla == None).first()
    if not stock:
        db.add(StockEPI(nombre=nombre, categoria=categoria, talla=None, cantidad=0, stock_minimo=3))
        db.commit()
    return RedirectResponse("/epis/catalogo?ok=creado", status_code=303)


@app.post("/epis/catalogo/{cid}/editar")
async def epis_catalogo_editar(
    cid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    item = db.query(CatalogoEPI).get(cid)
    if not item:
        raise HTTPException(404)
    form = await request.form()
    nombre_nuevo = (form.get("nombre", "") or "").strip().upper()
    if nombre_nuevo and nombre_nuevo != item.nombre:
        # Renombrar también en stock
        stock_old = db.query(StockEPI).filter(StockEPI.nombre == item.nombre).all()
        for s in stock_old:
            s.nombre = nombre_nuevo
        item.nombre = nombre_nuevo
    cantidad = form.get("cantidad_kit")
    if cantidad:
        item.cantidad_kit = max(1, int(cantidad))
    notas = form.get("notas")
    if notas is not None:
        item.notas = notas.strip()[:200] or None
    activo = form.get("activo")
    if activo is not None:
        item.activo = activo == "1"
    db.commit()
    return RedirectResponse("/epis/catalogo?ok=editado", status_code=303)


@app.post("/epis/catalogo/{cid}/eliminar")
def epis_catalogo_eliminar(
    cid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "admin"):
        raise HTTPException(403, "Solo admins")
    item = db.query(CatalogoEPI).get(cid)
    if not item:
        raise HTTPException(404)
    # Desactivar en lugar de borrar para preservar historial de entregas
    item.activo = False
    db.commit()
    return RedirectResponse("/epis/catalogo?ok=desactivado", status_code=303)


# ─── Almacenes — detalle, ubicaciones, foto, QR, eliminar ────────────────────

@app.get("/almacenes/{aid}", response_class=HTMLResponse)
def almacen_detalle(
    aid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    almacenes_todos = db.query(Almacen).order_by(Almacen.nombre).all()
    return templates.TemplateResponse(request, "almacen_detalle.html", ctx_base(
        request, user,
        almacen=a,
        trabajadores=trabajadores,
        herramientas=a.herramientas,
        materiales=db.query(Material).filter(Material.almacen_id == aid).all(),
        ubicaciones=a.ubicaciones,
        almacenes_todos=almacenes_todos,
    ))


@app.get("/almacenes/{aid}/qr", response_class=HTMLResponse)
def almacen_qr(
    aid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    qr_b64 = generar_qr_base64(f"/almacenes/{a.id}")
    mats_count = db.query(Material).filter(Material.almacen_id == aid).count()
    return templates.TemplateResponse(request, "almacen_qr.html", ctx_base(
        request, user,
        almacen=a,
        qr_b64=qr_b64,
        empresa=COMPANY_NAME,
        ubicaciones=a.ubicaciones,
        herramientas_count=len(a.herramientas),
        materiales_count=mats_count,
        ubicaciones_count=len(a.ubicaciones),
    ))


@app.post("/almacenes/{aid}/foto", response_class=RedirectResponse)
async def almacen_foto(
    aid: int,
    foto: UploadFile = File(...),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    carpeta = BASE_DIR / "static" / "uploads" / "almacenes"
    carpeta.mkdir(parents=True, exist_ok=True)
    if a.foto:
        old_p = carpeta / a.foto
        if old_p.exists():
            old_p.unlink()
    ext = (foto.filename or "").rsplit(".", 1)[-1].lower() or "jpg"
    import time as _t
    nombre = f"alm_{aid}_{int(_t.time())}.{ext}"
    data = await foto.read()
    (carpeta / nombre).write_bytes(data)
    a.foto = nombre
    db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=foto", status_code=303)


@app.post("/almacenes/{aid}/foto/eliminar", response_class=RedirectResponse)
def almacen_foto_eliminar(
    aid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    a = db.query(Almacen).get(aid)
    if a and a.foto:
        p = BASE_DIR / "static" / "uploads" / "almacenes" / a.foto
        if p.exists():
            p.unlink()
        a.foto = None
        db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=foto_eliminada", status_code=303)


@app.post("/almacenes/{aid}/eliminar", response_class=RedirectResponse)
def almacen_eliminar(
    aid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "borrar"):
        raise HTTPException(403)
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    if a.foto:
        try:
            p = BASE_DIR / "static" / "uploads" / "almacenes" / a.foto
            if p.exists():
                p.unlink()
        except Exception:
            pass
    db.delete(a)
    db.commit()
    return RedirectResponse("/almacenes?ok=eliminado", status_code=303)


@app.post("/almacenes/{aid}/ubicaciones/nuevo", response_class=RedirectResponse)
def ubicacion_nueva(
    aid: int, request_: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    codigo: str = Form(""),
    descripcion: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    ub = Ubicacion(
        almacen_id=aid,
        nombre=nombre.strip(),
        codigo=codigo.strip().upper() or None,
        descripcion=descripcion or None,
    )
    db.add(ub)
    db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=ubicacion", status_code=303)


@app.post("/almacenes/{aid}/ubicaciones/{uid}/editar", response_class=RedirectResponse)
async def ubicacion_editar(
    aid: int, uid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    ub = db.query(Ubicacion).filter(Ubicacion.id == uid, Ubicacion.almacen_id == aid).first()
    if not ub:
        raise HTTPException(404)
    form = await request.form()
    ub.nombre      = form.get("nombre", ub.nombre).strip()
    ub.codigo      = (form.get("codigo") or "").strip().upper() or None
    ub.descripcion = form.get("descripcion") or None
    db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=ubicacion", status_code=303)


@app.post("/almacenes/{aid}/ubicaciones/{uid}/eliminar", response_class=RedirectResponse)
def ubicacion_eliminar(
    aid: int, uid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    ub = db.query(Ubicacion).filter(Ubicacion.id == uid, Ubicacion.almacen_id == aid).first()
    if ub:
        # Desvincular herramientas y materiales
        db.query(Herramienta).filter(Herramienta.ubicacion_id == uid).update({"ubicacion_id": None})
        db.query(Material).filter(Material.ubicacion_id == uid).update({"ubicacion_id": None})
        db.delete(ub)
        db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=ubicacion_eliminada", status_code=303)


@app.post("/almacenes/{aid}/transferir", response_class=RedirectResponse)
async def almacen_transferir(
    aid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Transfiere herramientas o materiales seleccionados a otro almacén."""
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    form = await request.form()
    destino_id = int(form.get("destino_id") or 0)
    if not destino_id:
        return RedirectResponse(f"/almacenes/{aid}?err=sin_destino", status_code=303)
    herr_ids  = form.getlist("herramienta_id")
    mat_ids   = form.getlist("material_id")
    if herr_ids:
        db.query(Herramienta).filter(Herramienta.id.in_([int(x) for x in herr_ids])).update(
            {"almacen_id": destino_id, "ubicacion_id": None}, synchronize_session=False)
    if mat_ids:
        db.query(Material).filter(Material.id.in_([int(x) for x in mat_ids])).update(
            {"almacen_id": destino_id, "ubicacion_id": None}, synchronize_session=False)
    db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=transferido", status_code=303)



# ─── Almacenes — inventario express ────────────────────────────────────────────
@app.post("/almacenes/{aid}/inventario", response_class=RedirectResponse)
async def almacen_inventario(
    aid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403)
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    form = await request.form()
    mats = db.query(Material).filter(Material.almacen_id == aid).all()
    for m in mats:
        key = f"stock_{m.id}"
        val = form.get(key)
        if val is not None and val.strip() != "":
            try:
                nuevo = float(val)
                if nuevo != m.stock_actual:
                    diff = nuevo - m.stock_actual
                    tipo_mov = "ajuste"
                    db.add(MovimientoMaterial(
                        material_id=m.id,
                        tipo=tipo_mov,
                        cantidad=abs(diff),
                        notas=f"Inventario express: {m.stock_actual} → {nuevo}",
                        usuario_id=user.id,
                    ))
                    m.stock_actual = nuevo
            except (ValueError, TypeError):
                pass
    db.commit()
    return RedirectResponse(f"/almacenes/{aid}?ok=inventario&tab=mat", status_code=303)


# ─── Almacenes — QR por ubicación ───────────────────────────────────────────────
@app.get("/almacenes/{aid}/ubicaciones/{uid}/qr", response_class=HTMLResponse)
def ubicacion_qr(
    aid: int, uid: int, request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    a = db.query(Almacen).get(aid)
    ub = db.query(Ubicacion).get(uid)
    if not a or not ub or ub.almacen_id != aid:
        raise HTTPException(404)
    qr_code = ub.codigo or f"ALM{aid}-UBI{uid}"
    qr_b64 = generar_qr_base64(qr_code)
    return templates.TemplateResponse(request, "ubicacion_qr.html", ctx_base(
        request, user,
        almacen=a,
        ubicacion=ub,
        qr_b64=qr_b64,
        herramientas_count=len(ub.herramientas),
        materiales_count=len(ub.materiales),
    ))


# ─── Almacenes — exportar inventario a Excel ─────────────────────────────────
@app.get("/almacenes/{aid}/exportar")
def almacen_exportar(
    aid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        raise HTTPException(500, "openpyxl no instalado")

    wb = openpyxl.Workbook()

    # ── Hoja Herramientas ──
    ws_h = wb.active
    ws_h.title = "Herramientas"
    header_fill = PatternFill("solid", fgColor="F5A623")
    header_font = Font(bold=True, color="000000")
    cols_h = ["Código", "Nombre", "Categoría", "Estado", "Ubicación", "Marca", "Modelo", "Nº Serie"]
    for c, col in enumerate(cols_h, 1):
        cell = ws_h.cell(row=1, column=c, value=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
    herrs = a.herramientas
    for r, h in enumerate(herrs, 2):
        row = [
            h.codigo, h.nombre, h.categoria or "",
            h.estado.replace("_", " ").title(),
            h.ubicacion.nombre if h.ubicacion else (h.almacen_nombre or ""),
            h.marca or "", h.modelo or "", h.num_serie or "",
        ]
        for c, val in enumerate(row, 1):
            ws_h.cell(row=r, column=c, value=val)
    for c in range(1, len(cols_h) + 1):
        ws_h.column_dimensions[get_column_letter(c)].width = 18

    # ── Hoja Materiales ──
    ws_m = wb.create_sheet("Materiales")
    cols_m = ["Código", "Nombre", "Categoría", "Stock actual", "Stock mínimo", "Unidad", "Ubicación", "Bajo mínimo"]
    for c, col in enumerate(cols_m, 1):
        cell = ws_m.cell(row=1, column=c, value=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
    mats = db.query(Material).filter(Material.almacen_id == aid, Material.activo == True).all()
    red_fill = PatternFill("solid", fgColor="FFD7D7")
    for r, m in enumerate(mats, 2):
        row = [
            m.codigo, m.nombre, m.categoria or "",
            m.stock_actual, m.stock_minimo, m.unidad or "ud",
            m.ubicacion.nombre if m.ubicacion else (m.ubicacion_texto or ""),
            "⚠ Sí" if m.bajo_minimo else "Ok",
        ]
        for c, val in enumerate(row, 1):
            cell = ws_m.cell(row=r, column=c, value=val)
            if m.bajo_minimo:
                cell.fill = red_fill
    for c in range(1, len(cols_m) + 1):
        ws_m.column_dimensions[get_column_letter(c)].width = 18

    # ── Hoja Ubicaciones ──
    ws_u = wb.create_sheet("Ubicaciones")
    cols_u = ["Código", "Nombre", "Descripción", "Herramientas", "Materiales"]
    for c, col in enumerate(cols_u, 1):
        cell = ws_u.cell(row=1, column=c, value=col)
        cell.fill = header_fill
        cell.font = header_font
    for r, u in enumerate(a.ubicaciones, 2):
        row = [u.codigo or "", u.nombre, u.descripcion or "",
               len(u.herramientas), len(u.materiales)]
        for c, val in enumerate(row, 1):
            ws_u.cell(row=r, column=c, value=val)
    for c in range(1, len(cols_u) + 1):
        ws_u.column_dimensions[get_column_letter(c)].width = 18

    import io
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    nombre_archivo = f"inventario_{a.nombre.replace(' ','_')}.xlsx"
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{nombre_archivo}"'},
    )


# ─── Obras ────────────────────────────────────────────────────────────────────
@app.get("/obras", response_class=HTMLResponse)
def obras_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    obras = db.query(Obra).order_by(Obra.id.desc()).all()
    return templates.TemplateResponse(request, "obras.html", ctx_base(request, user, obras=obras))


@app.get("/obras/nueva", response_class=HTMLResponse)
def obra_nueva_get(request: Request, user: Usuario = Depends(requiere_login)):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    return templates.TemplateResponse(request, "nueva_obra.html", ctx_base(request, user))


@app.post("/obras/nueva")
def obra_nueva_post(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    cliente: str = Form(""),
    responsable: str = Form(""),
    direccion: str = Form(""),
    fecha_inicio: str = Form(""),
    fecha_fin: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    # Auto-número
    año = datetime.now().year
    count = db.query(Obra).filter(Obra.numero.like(f"{año}-%")).count()
    numero = f"{año}-{(count + 1):04d}"
    o = Obra(
        numero=numero, nombre=nombre, cliente=cliente or None,
        responsable=responsable or None, direccion=direccion or None,
        fecha_inicio=datetime.strptime(fecha_inicio, "%Y-%m-%d") if fecha_inicio else None,
        fecha_fin=datetime.strptime(fecha_fin, "%Y-%m-%d") if fecha_fin else None,
        activa=True,
    )
    db.add(o)
    db.commit()
    return RedirectResponse("/obras", status_code=303)


@app.post("/obras/{oid}/editar", response_class=RedirectResponse)
async def obra_editar(
    oid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    o = db.query(Obra).get(oid)
    if not o:
        raise HTTPException(404)
    form = await request.form()
    o.nombre = form.get("nombre") or o.nombre
    o.cliente = form.get("cliente") or None
    o.responsable = form.get("responsable") or None
    o.direccion = form.get("direccion") or None
    fi = form.get("fecha_inicio", "")
    ff = form.get("fecha_fin", "")
    if fi:
        o.fecha_inicio = datetime.strptime(fi, "%Y-%m-%d")
    if ff:
        o.fecha_fin = datetime.strptime(ff, "%Y-%m-%d")
    activa = form.get("activa", "")
    o.activa = activa in ("1", "true", "on")
    o.observaciones = form.get("observaciones") or None
    db.commit()
    return RedirectResponse("/obras?ok=editado", status_code=303)


# ─── Almacenes ────────────────────────────────────────────────────────────────
@app.get("/almacenes", response_class=HTMLResponse)
def almacenes_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    almacenes = db.query(Almacen).all()
    return templates.TemplateResponse(request, "almacenes.html", ctx_base(request, user, almacenes=almacenes))


@app.post("/almacenes/nuevo")
def almacen_nuevo(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    descripcion: str = Form(""),
    direccion: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    db.add(Almacen(nombre=nombre, descripcion=descripcion or None, direccion=direccion or None))
    db.commit()
    return RedirectResponse("/almacenes", status_code=303)


@app.post("/almacenes/{aid}/editar", response_class=RedirectResponse)
async def almacen_editar(
    aid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    a = db.query(Almacen).get(aid)
    if not a:
        raise HTTPException(404)
    form = await request.form()
    a.nombre = form.get("nombre") or a.nombre
    a.descripcion = form.get("descripcion") or None
    a.direccion = form.get("direccion") or None
    a.responsable = form.get("responsable") or None
    db.commit()
    return RedirectResponse("/almacenes?ok=editado", status_code=303)


# ─── Vehículos ────────────────────────────────────────────────────────────────
@app.get("/vehiculos", response_class=HTMLResponse)
def vehiculos_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    vehiculos = db.query(Vehiculo).all()
    return templates.TemplateResponse(request, "vehiculos.html", ctx_base(request, user, vehiculos=vehiculos))


@app.post("/vehiculos/nuevo")
def vehiculo_nuevo(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    matricula: str = Form(...),
    marca: str = Form(""),
    modelo: str = Form(""),
    tipo: str = Form("furgoneta"),
    kilometros: str = Form(""),
    descripcion: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    mat_up = matricula.strip().upper()
    existe = db.query(Vehiculo).filter(Vehiculo.matricula == mat_up).first()
    if not existe:
        db.add(Vehiculo(
            matricula=mat_up,
            marca=marca or None,
            modelo=modelo or None,
            tipo=tipo or "furgoneta",
            kilometros=int(kilometros) if kilometros else None,
            descripcion=descripcion or None,
        ))
        db.commit()
    return RedirectResponse("/vehiculos", status_code=303)


@app.post("/vehiculos/{vid}/editar", response_class=RedirectResponse)
async def vehiculo_editar(
    vid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    v = db.query(Vehiculo).get(vid)
    if not v:
        raise HTTPException(404)
    form = await request.form()
    mat_raw = (form.get("matricula") or "").strip().upper()
    v.matricula = mat_raw or v.matricula
    v.marca = form.get("marca") or None
    v.modelo = form.get("modelo") or None
    v.tipo = form.get("tipo") or v.tipo
    anio_raw = form.get("anio", "")
    if anio_raw:
        try: v.anio = int(anio_raw)
        except ValueError: pass
    km = form.get("kilometros", "")
    if km:
        v.kilometros = int(km)
    v.descripcion = form.get("descripcion") or None
    v.estado = form.get("estado") or v.estado
    v.observaciones = form.get("observaciones") or None
    itv = form.get("itv_hasta", "")
    if itv:
        v.itv_hasta = datetime.strptime(itv, "%Y-%m-%d").date()
    else:
        v.itv_hasta = None
    seg = form.get("seguro_hasta", "")
    if seg:
        v.seguro_hasta = datetime.strptime(seg, "%Y-%m-%d").date()
    else:
        v.seguro_hasta = None
    prox = form.get("proxima_revision", "")
    if prox:
        v.proxima_revision = datetime.strptime(prox, "%Y-%m-%d").date()
    else:
        v.proxima_revision = None
    v.compania_seguro = form.get("compania_seguro") or None
    v.num_poliza = form.get("num_poliza") or None
    db.commit()
    return RedirectResponse("/vehiculos?ok=editado", status_code=303)


@app.get("/vehiculos/{vid}/qr", response_class=HTMLResponse)
def vehiculo_qr(
    vid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    v = db.query(Vehiculo).get(vid)
    if not v:
        raise HTTPException(404)
    hoy = date.today()

    def _fecha_info(d):
        if not d:
            return {"txt": "No registrada", "css": "none", "aviso": ""}
        dias = (d - hoy).days
        txt = d.strftime("%d/%m/%Y")
        if dias < 0:
            return {"txt": txt, "css": "venc", "aviso": "⚠ VENCIDA/O"}
        elif dias < 30:
            return {"txt": txt, "css": "warn", "aviso": f"({dias} días)"}
        return {"txt": txt, "css": "ok", "aviso": ""}

    url_ficha = f"/vehiculos/{v.id}/qr"
    qr_b64 = generar_qr_base64(url_ficha)
    return templates.TemplateResponse(request, "vehiculo_qr.html", ctx_base(
        request, user,
        vehiculo=v,
        qr_b64=qr_b64,
        empresa=COMPANY_NAME,
        itv=_fecha_info(v.itv_hasta),
        seguro=_fecha_info(v.seguro_hasta),
        revision=_fecha_info(v.proxima_revision),
        compania_seguro=v.compania_seguro or "",
        num_poliza=v.num_poliza or "",
    ))


# ─── Etiquetas ────────────────────────────────────────────────────────────────
@app.get("/etiquetas", response_class=HTMLResponse)
def etiquetas_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True).order_by(Herramienta.nombre).all()
    return templates.TemplateResponse(request, "etiquetas.html", ctx_base(request, user, herramientas=herramientas))


@app.get("/etiquetas/{herramienta_id}/qr")
def etiqueta_qr_download(herramienta_id: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    h = db.query(Herramienta).get(herramienta_id)
    if not h:
        raise HTTPException(404)
    qr_bytes = generar_qr_bytes(h.codigo)
    return Response(content=qr_bytes, media_type="image/png",
                    headers={"Content-Disposition": f"attachment; filename=QR_{h.codigo}.png"})


@app.get("/etiquetas/{herramienta_id}/zpl")
def etiqueta_zpl_download(herramienta_id: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    h = db.query(Herramienta).get(herramienta_id)
    if not h:
        raise HTTPException(404)
    zpl = generar_zpl_herramienta(h.codigo, h.nombre, h.num_serie or "", h.marca or "", COMPANY_NAME)
    return Response(content=zpl.encode("utf-8"), media_type="text/plain",
                    headers={"Content-Disposition": f"attachment; filename=ETIQ_{h.codigo}.prn"})


@app.post("/etiquetas/pdf")
def etiquetas_pdf(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    ids: str = Form(...),
):
    id_list = [int(x) for x in ids.split(",") if x.strip().isdigit()]
    if not id_list:
        raise HTTPException(400, "Sin herramientas seleccionadas")
    herramientas = db.query(Herramienta).filter(Herramienta.id.in_(id_list)).all()
    pdf_bytes = generar_pdf_etiquetas(herramientas, COMPANY_NAME)
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": "attachment; filename=etiquetas_mrd.pdf"})


@app.get("/etiquetas/imprimir/{herramienta_id}", response_class=HTMLResponse)
def etiqueta_imprimir(
    herramienta_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Vista de impresión de etiqueta individual con código de barras Code128 + QR."""
    h = db.query(Herramienta).get(herramienta_id)
    if not h:
        raise HTTPException(404)
    qr_b64 = generar_qr_base64(h.codigo)
    return templates.TemplateResponse(request, "etiqueta_imprimir.html",
        ctx_base(request, user, herramienta=h, qr_b64=qr_b64, empresa=COMPANY_NAME))


# ─── Escaneo ──────────────────────────────────────────────────────────────────
@app.get("/scan", response_class=HTMLResponse)
def scan_page(request: Request, db: Session = Depends(get_db)):
    """Página de escaneo — pública para acceso desde móvil sin login."""
    user = usuario_actual(request, db)
    return templates.TemplateResponse(request, "scan.html", ctx_base(request, user))


@app.get("/scan/ip")
def scan_ip(request: Request, db: Session = Depends(get_db)):
    """
    Endpoint de compatibilidad — mantiene el formato original.
    Ahora consume el nuevo sistema multi-proveedor.
    """
    status = remote_access.get_status_cached(max_age=30)
    ip = status.get("ip", "127.0.0.1")
    port = status.get("port", 8000)
    local_url = f"http://{ip}:{port}/scan"
    public_url = status.get("public_url")
    url_https = (public_url.rstrip("/") + "/scan") if public_url else None
    url_qr = url_https or local_url
    qr_b64 = generar_qr_base64(url_qr)
    return JSONResponse({
        "ip": ip,
        "url_local": local_url,
        "url_https": url_https,
        "url_qr": url_qr,
        "qr": qr_b64,
        # Campos extendidos para compatibilidad futura
        "provider": status.get("primary_provider", "local"),
        "status": status.get("status", "local_only"),
    })


# ─── API Acceso Remoto ────────────────────────────────────────────────────────

@app.get("/api/remote-access/status")
def api_remote_access_status(user: Usuario = Depends(requiere_login)):
    """
    Estado completo del acceso remoto con todos los proveedores detectados.
    Incluye URL pública, scan_url, QR en base64, proveedores activos.
    """
    status = remote_access.get_status_cached(max_age=30)
    # Añadir QR al resultado
    scan_url = status.get("scan_url", "")
    if scan_url:
        try:
            status["qr"] = generar_qr_base64(scan_url)
        except Exception:
            status["qr"] = None
    else:
        status["qr"] = None
    return JSONResponse(status)


@app.post("/api/remote-access/status/refresh")
def api_remote_access_refresh(user: Usuario = Depends(requiere_login)):
    """Fuerza refresco inmediato de la detección (síncrono)."""
    remote_access.invalidate_cache()
    status = remote_access.detect_all()
    remote_access._cached_status = status
    remote_access._cache_time = datetime.now()
    if status.get("scan_url"):
        try:
            status["qr"] = generar_qr_base64(status["scan_url"])
        except Exception:
            status["qr"] = None
    return JSONResponse(status)


@app.get("/api/remote-access/config")
def api_remote_access_config_get(user: Usuario = Depends(requiere_login)):
    """Devuelve la configuración actual de acceso remoto (solo admins)."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    cfg = remote_access.load_config()
    return JSONResponse(cfg)


@app.post("/api/remote-access/config")
async def api_remote_access_config_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
):
    """Guarda la configuración de acceso remoto (solo admins)."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    try:
        updates = await request.json()
        if not isinstance(updates, dict):
            raise HTTPException(400, "Formato inválido")
        ok = remote_access.save_config(updates)
        if ok:
            remote_access.invalidate_cache()
            return JSONResponse({"ok": True, "message": "Configuración guardada"})
        return JSONResponse({"ok": False, "message": "Error al guardar"}, status_code=500)
    except Exception as e:
        raise HTTPException(400, str(e))


@app.get("/acceso-remoto", response_class=HTMLResponse)
def acceso_remoto_page(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    """Página dedicada de acceso remoto — vista sencilla + configuración avanzada (admin)."""
    version_info = leer_version_actual()
    backups = listar_backups()
    ultimo_backup = backups[0]["fecha"] if backups else "—"
    return templates.TemplateResponse(request, "acceso_remoto.html", {
        "request": request,
        "user": user,
        "app_name": APP_NAME,
        "company_name": COMPANY_NAME,
        "version": VERSION,
        "version_info": version_info,
        "ultimo_backup": ultimo_backup,
        "es_admin": tiene_permiso(user, "config"),
    })


@app.post("/api/remote-access/test")
def api_remote_access_test(user: Usuario = Depends(requiere_login)):
    """
    Ejecuta diagnósticos completos de conectividad.
    Prueba servidor local, puerto, cloudflare, URL pública, HTTPS, /scan, QR.
    """
    cfg = remote_access.load_config()
    port = int(cfg.get("port", 8000))
    diag = remote_access.run_diagnostics(port)
    status = remote_access.get_status_cached(max_age=60)
    return JSONResponse({
        "ok": True,
        "diagnostics": diag,
        "status": status.get("status"),
        "latency_ms": diag.get("response_ms"),
        "public_response_ms": diag.get("public_response_ms"),
        "checked_at": datetime.now().isoformat(),
    })


@app.get("/api/remote-access/qr")
def api_remote_access_qr(user: Usuario = Depends(requiere_login)):
    """Devuelve el QR en PNG para descarga directa."""
    status = remote_access.get_status_cached(max_age=60)
    scan_url = status.get("scan_url", "")
    if not scan_url:
        raise HTTPException(404, "No hay URL disponible para generar QR")
    try:
        qr_bytes = generar_qr_bytes(scan_url)
        return Response(content=qr_bytes, media_type="image/png",
                        headers={"Content-Disposition": "attachment; filename=qr_mrd.png"})
    except Exception as e:
        raise HTTPException(500, f"Error generando QR: {e}")


@app.post("/api/remote-access/restart")
def api_remote_access_restart(user: Usuario = Depends(requiere_login)):
    """Reinicia el servicio cloudflared (solo admins, si allow_restart está activado)."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    cfg = remote_access.load_config()
    if not cfg.get("allow_restart", False):
        raise HTTPException(403, "Reinicio de servicio no habilitado en la configuración")
    svc = cfg.get("cloudflared_service", "cloudflared")
    svc = re.sub(r"[^a-zA-Z0-9_\-]", "", svc)[:50]
    if not svc:
        raise HTTPException(400, "Nombre de servicio inválido")
    try:
        result = subprocess.run(
            ["sc", "stop", svc], capture_output=True, text=True, timeout=5,
            creationflags=0x08000000,
        )
        time.sleep(1)
        result2 = subprocess.run(
            ["sc", "start", svc], capture_output=True, text=True, timeout=5,
            creationflags=0x08000000,
        )
        remote_access.invalidate_cache()
        return JSONResponse({"ok": True, "message": f"Servicio '{svc}' reiniciado"})
    except Exception as e:
        raise HTTPException(500, f"Error al reiniciar: {str(e)[:100]}")


@app.get("/api/system/stats")
def api_system_stats(user: Usuario = Depends(requiere_login)):
    """Estadísticas del servidor: CPU, RAM, uptime, versión, último backup."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    version_info = leer_version_actual()
    backups = listar_backups()
    ultimo_backup = backups[0]["fecha"] if backups else "—"
    stats = remote_access.get_server_stats()
    return JSONResponse({
        **stats,
        "version": version_info.get("version_actual", "—"),
        "ultimo_backup": ultimo_backup,
    })


@app.get("/scan/buscar")
def scan_buscar(
    codigo: str,
    db: Session = Depends(get_db),
):
    """API JSON: busca herramienta o maquinaria por código/num_serie/codigo_barras."""
    codigo = codigo.strip()

    # 1 — Buscar en herramientas
    h = db.query(Herramienta).filter(
        or_(
            Herramienta.codigo == codigo,
            Herramienta.num_serie == codigo,
        )
    ).first()
    if h:
        estados = {
            "disponible": "Disponible", "entregada": "Entregada",
            "en_obra": "En obra", "en_almacen": "En almacén",
            "en_furgoneta": "En furgoneta", "en_reparacion": "En reparación",
            "perdida": "Perdida", "baja": "Baja",
        }
        return JSONResponse({
            "found": True,
            "tipo": "herramienta",
            "id": h.id,
            "codigo": h.codigo,
            "nombre": h.nombre,
            "marca": h.marca or "",
            "estado": h.estado,
            "estado_label": estados.get(h.estado, h.estado),
            "url": f"/herramientas/{h.id}",
        })

    # 2 — Buscar en maquinaria
    m = db.query(Maquinaria).filter(
        or_(
            Maquinaria.codigo_barras == codigo,
            Maquinaria.codigo_interno == codigo,
            Maquinaria.matricula == codigo,
            Maquinaria.num_serie == codigo,
        )
    ).first()
    if m:
        return JSONResponse({
            "found": True,
            "tipo": "maquinaria",
            "id": m.id,
            "codigo": m.codigo_barras or m.codigo_interno or "",
            "nombre": m.nombre,
            "marca": m.marca or "",
            "estado": m.estado,
            "estado_label": ESTADOS_MAQUINARIA.get(m.estado, m.estado),
            "url": f"/maquinaria/{m.id}",
        })

    # 3 — Buscar en materiales por código
    mat = db.query(Material).filter(
        or_(Material.codigo == codigo)
    ).first()
    if mat:
        alm_nombre = mat.almacen.nombre if mat.almacen else None
        ubi_nombre = mat.ubicacion.nombre if mat.ubicacion else mat.ubicacion_texto or None
        return JSONResponse({
            "found": True,
            "tipo": "material",
            "id": mat.id,
            "codigo": mat.codigo,
            "nombre": mat.nombre,
            "descripcion": mat.descripcion or "",
            "stock": mat.stock_actual,
            "unidad": mat.unidad or "ud",
            "almacen": alm_nombre,
            "ubicacion": ubi_nombre,
            "bajo_minimo": mat.bajo_minimo,
            "url": f"/materiales/{mat.id}",
        })

    return JSONResponse({"found": False})


# ─── Importación Excel ────────────────────────────────────────────────────────
@app.get("/informes", response_class=HTMLResponse)
def informes(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    analisis = generar_analisis_inteligente(db)
    # Datos para Chart.js (JSON seguro)
    chart_estados = {
        "labels": list(analisis["herramientas"]["estados"].keys()),
        "data": list(analisis["herramientas"]["estados"].values()),
    }
    chart_mov = {
        "labels": [r["mes"] for r in analisis["movimientos"]["por_mes"]],
        "data": [r["total"] for r in analisis["movimientos"]["por_mes"]],
    }
    chart_maq = {
        "labels": list(analisis["maquinaria"]["estados"].keys()),
        "data": list(analisis["maquinaria"]["estados"].values()),
    }
    return templates.TemplateResponse(request, "informes.html", ctx_base(
        request, user, db,
        analisis=analisis,
        chart_estados_json=json.dumps(chart_estados),
        chart_mov_json=json.dumps(chart_mov),
        chart_maq_json=json.dumps(chart_maq),
    ))


@app.get("/informes/inventario/excel")
def informe_inventario_excel(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True).order_by(Herramienta.nombre).all()
    excel = exportar_inventario_excel(herramientas)
    nombre = f"inventario_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )


@app.get("/informes/movimientos/excel")
def informe_movimientos_excel(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    movimientos = db.query(Movimiento).order_by(Movimiento.fecha.desc()).limit(5000).all()
    excel = exportar_movimientos_excel(movimientos)
    nombre = f"movimientos_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )


# ─── Configuración ────────────────────────────────────────────────────────────
@app.get("/configuracion", response_class=HTMLResponse)
def configuracion(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    if not tiene_permiso(user, "config"):
        return RedirectResponse("/", status_code=303)
    backups = listar_backups()
    usuarios = db.query(Usuario).order_by(Usuario.username).all()
    version_info = leer_version_actual()
    return templates.TemplateResponse(request, "configuracion.html", ctx_base(
        request, user,
        backups=backups,
        usuarios=usuarios,
        version_info=version_info,
    ))


@app.post("/configuracion/backup")
def hacer_backup(user: Usuario = Depends(requiere_login)):
    if not tiene_permiso(user, "backup"):
        raise HTTPException(403, "Sin permiso")
    resultado = crear_backup()
    if resultado["ok"]:
        return RedirectResponse("/configuracion?backup=ok", status_code=303)
    return RedirectResponse("/configuracion?backup=error", status_code=303)


@app.get("/configuracion/backup/descargar/{nombre}")
def descargar_backup(nombre: str, user: Usuario = Depends(requiere_login)):
    if not tiene_permiso(user, "backup"):
        raise HTTPException(403, "Sin permiso")
    # Seguridad: solo nombres de backup válidos — evita path traversal
    if not re.match(r'^(backup|pre_update|antes_restaurar)_[\w\-]+\.db$', nombre):
        raise HTTPException(400, "Nombre de archivo no válido")
    ruta = (BACKUPS_DIR / nombre).resolve()
    # Verificar que la ruta resuelta está dentro de BACKUPS_DIR
    if not str(ruta).startswith(str(BACKUPS_DIR.resolve())):
        raise HTTPException(403, "Acceso denegado")
    if not ruta.exists() or not ruta.is_file():
        raise HTTPException(404)
    return FileResponse(str(ruta), filename=nombre, media_type="application/octet-stream")


@app.post("/configuracion/usuarios/nuevo")
def usuario_nuevo(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    username: str = Form(...),
    nombre: str = Form(...),
    password: str = Form(...),
    rol: str = Form("consulta"),
    email: str = Form(""),
):
    if not tiene_permiso(user, "usuarios"):
        raise HTTPException(403, "Sin permiso")
    existe = db.query(Usuario).filter(Usuario.username == username).first()
    if not existe:
        # Sprint 5.2: validar política de contraseñas
        try:
            validar_contrasena(password, username=username, min_length=PASSWORD_MIN_LENGTH)
        except ErrorContrasena as _ec:
            raise HTTPException(400, str(_ec))
        db.add(Usuario(
            username=username, nombre=nombre,
            password_hash=hash_password(password),
            rol=rol, email=email or None, activo=True,
            must_change_password=True,  # Sprint 5.2: forzar cambio en primer login
        ))
        db.commit()
        mrd_logging.log_security(
            f"Usuario nuevo creado: username='{username}' rol={rol} por admin='{user.username}'",
            level="info",
        )
    return RedirectResponse("/configuracion?usuario=ok", status_code=303)


@app.post("/configuracion/usuarios/{uid}/toggle")
def usuario_toggle(uid: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    if not tiene_permiso(user, "usuarios"):
        raise HTTPException(403, "Sin permiso")
    u = db.query(Usuario).get(uid)
    if u and u.username != DEFAULT_ADMIN_USER:
        u.activo = not u.activo
        db.commit()
    return RedirectResponse("/configuracion", status_code=303)


@app.post("/configuracion/usuarios/{uid}/editar")
def usuario_editar(
    uid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    rol: str = Form("consulta"),
    email: str = Form(""),
    password: str = Form(""),
):
    if not tiene_permiso(user, "usuarios"):
        raise HTTPException(403, "Sin permiso")
    u = db.query(Usuario).get(uid)
    if u:
        u.nombre = nombre
        u.rol = rol
        u.email = email or None
        if password.strip():
            # Sprint 5.2: validar política de contraseñas al resetear
            try:
                validar_contrasena(password.strip(), username=u.username, min_length=PASSWORD_MIN_LENGTH)
            except ErrorContrasena as _ec:
                raise HTTPException(400, str(_ec))
            u.password_hash = hash_password(password.strip())
            u.must_change_password = True  # forzar cambio al siguiente login
            mrd_logging.log_security(
                f"Contraseña reseteada por admin: usuario='{u.username}' admin='{user.username}'",
                level="info",
            )
        db.commit()
    return RedirectResponse("/configuracion?usuario=editado", status_code=303)


@app.post("/configuracion/usuarios/{uid}/eliminar")
def usuario_eliminar(uid: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    if not tiene_permiso(user, "usuarios"):
        raise HTTPException(403, "Sin permiso")
    u = db.query(Usuario).get(uid)
    if u and u.username != DEFAULT_ADMIN_USER and u.id != user.id:
        db.delete(u)
        db.commit()
    return RedirectResponse("/configuracion?usuario=eliminado", status_code=303)


# ─── Actualizaciones ──────────────────────────────────────────────────────────
@app.get("/actualizaciones", response_class=HTMLResponse)
def actualizaciones(request: Request, user: Usuario = Depends(requiere_login)):
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    version_info = leer_version_actual()
    update_check = verificar_actualizacion_local()
    historial = leer_historial()
    return templates.TemplateResponse(request, "actualizaciones.html", ctx_base(
        request, user,
        version_info=version_info,
        update_check=update_check,
        historial=historial,
    ))


@app.post("/actualizaciones/aplicar")
def actualizar_app(
    user: Usuario = Depends(requiere_login),
    archivo: str = Form(...),
):
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    resultado = aplicar_actualizacion(archivo)
    if resultado["ok"]:
        return RedirectResponse("/actualizaciones?update=ok", status_code=303)
    return RedirectResponse(f"/actualizaciones?update=error&msg={resultado.get('error', '')}", status_code=303)


@app.post("/actualizaciones/empaquetar")
def empaquetar_release(user: Usuario = Depends(requiere_login)):
    """Crea el ZIP de release con la versión actual del código."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(403, "Sin permiso")
    version_info = leer_version_actual()
    version = version_info.get("version_actual", "1.0.0")
    EXCLUIR = {
        "data", "backups", "uploads", "logs", "venv",
        "__pycache__", ".git", "releases", "exports",
        "get_access_info.bat", "get_access_info.py",
        "create_release.bat", "access_info.txt", "qr_movil.png",
    }
    out = BASE_DIR / "releases" / f"mrd_tool_control_v{version}.zip"
    out.parent.mkdir(exist_ok=True)
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in BASE_DIR.rglob("*"):
                parts = f.relative_to(BASE_DIR).parts
                if not parts or parts[0] in EXCLUIR:
                    continue
                if any(p == "__pycache__" for p in parts):
                    continue
                if any(p.startswith("_update_tmp") for p in parts):
                    continue
                if f.is_file():
                    arcname = f"mrd_tool_control/{f.relative_to(BASE_DIR)}"
                    zf.write(f, arcname)
        size_kb = out.stat().st_size // 1024
        return RedirectResponse(f"/actualizaciones?empaquetado=ok&version={version}&size={size_kb}", status_code=303)
    except Exception as e:
        return RedirectResponse(f"/actualizaciones?empaquetado=error&msg={str(e)}", status_code=303)


# ─── Health ───────────────────────────────────────────────────────────────────
@app.get("/health")
def health_simple():
    """Health check rápido — público — para proxies y monitores."""
    return {"status": "ok", "version": VERSION}


@app.get("/api/system/health")
def health_completo(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    """Health check completo — solo administradores."""
    resultado: dict = {
        "status": "healthy",
        "version": VERSION,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }

    # Base de datos
    try:
        db.execute(text("SELECT 1"))
        resultado["database"] = "ok"
    except Exception as e:
        resultado["database"] = f"error: {e}"
        resultado["status"] = "degraded"

    # Sistema de archivos
    try:
        test = DATA_DIR / ".health_check"
        test.write_text("ok")
        test.unlink()
        resultado["storage"] = "ok"
    except Exception:
        resultado["storage"] = "error"
        resultado["status"] = "degraded"

    # Backups
    backups = list(BACKUPS_DIR.glob("backup_*.db"))
    resultado["backup_count"] = len(backups)
    resultado["backup"] = "ok" if backups else "sin_backups"

    # Disco
    try:
        total, used, free = shutil.disk_usage(str(BASE_DIR))
        resultado["disk_free_gb"] = round(free / 1024 ** 3, 1)
        resultado["disk_total_gb"] = round(total / 1024 ** 3, 1)
        if free < 500 * 1024 * 1024:  # < 500 MB
            resultado["status"] = "degraded"
    except Exception:
        resultado["disk_free_gb"] = None

    # RAM y uptime via psutil
    try:
        import psutil
        mem = psutil.virtual_memory()
        resultado["ram_used_pct"] = round(mem.percent, 1)
        proc = psutil.Process()
        resultado["uptime_seconds"] = int(time.time() - proc.create_time())
    except ImportError:
        resultado["ram_used_pct"] = None
        resultado["uptime_seconds"] = None

    # Acceso remoto
    try:
        ra = remote_access.get_status_cached(max_age=120)
        resultado["remote_access"] = "ok" if ra.get("public_url") else "sin_url_publica"
    except Exception:
        resultado["remote_access"] = "error"

    # Logs
    log_dir = BASE_DIR / "logs"
    resultado["logs"] = "ok" if log_dir.exists() else "sin_directorio"

    return resultado


# ─── API ──────────────────────────────────────────────────────────────────────
@app.get("/api/herramientas/buscar")
def api_buscar(
    q: str = Query(""),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    herramientas = (
        db.query(Herramienta)
        .filter(Herramienta.activa == True)
        .filter(or_(
            Herramienta.codigo.ilike(f"%{q}%"),
            Herramienta.nombre.ilike(f"%{q}%"),
        ))
        .limit(10)
        .all()
    )
    return [{"id": h.id, "codigo": h.codigo, "nombre": h.nombre, "estado": h.estado} for h in herramientas]


@app.get("/api/herramientas/codigo/{codigo}")
def api_herramienta_por_codigo(
    codigo: str,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.codigo == codigo, Herramienta.activa == True).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    return {
        "id": h.id,
        "codigo": h.codigo,
        "nombre": h.nombre,
        "estado": h.estado,
        "ubicacion": h.ubicacion_texto,
        "url": f"/herramientas/{h.id}",
    }


@app.get("/api/stats")
def api_stats(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    # 1 query GROUP BY en lugar de 4 COUNT separados
    counts = dict(
        db.query(Herramienta.estado, func.count(Herramienta.id))
        .filter(Herramienta.activa == True)
        .group_by(Herramienta.estado)
        .all()
    )
    return {
        "total":      sum(counts.values()),
        "disponibles": counts.get("disponible", 0),
        "entregadas":  counts.get("entregada", 0),
        "en_obra":     counts.get("en_obra", 0),
        "en_furgoneta": counts.get("en_furgoneta", 0),
        "en_reparacion": counts.get("en_reparacion", 0),
        "perdidas":    counts.get("perdida", 0),
    }


@app.get("/api/version/check")
def api_version_check(user: Usuario = Depends(requiere_login)):
    result = verificar_actualizacion_local()
    version_actual = leer_version_actual().get("version_actual", VERSION)
    return {
        "version_actual": version_actual,
        "actualizacion_disponible": result.get("disponible", False),
        "nueva_version": result.get("version", ""),
    }


# ─── Proveedores ──────────────────────────────────────────────────────────────
@app.get("/proveedores", response_class=HTMLResponse)
def proveedores_list(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    proveedores = db.query(Proveedor).order_by(Proveedor.nombre).all()
    return templates.TemplateResponse(request, "proveedores.html", ctx_base(
        request, user, proveedores=proveedores, total=len(proveedores)
    ))


@app.post("/proveedores/nuevo")
def proveedor_nuevo(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    cif: str = Form(""),
    telefono: str = Form(""),
    email: str = Form(""),
    direccion: str = Form(""),
    web: str = Form(""),
    contacto: str = Form(""),
    observaciones: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    db.add(Proveedor(
        nombre=nombre, cif=cif or None, telefono=telefono or None,
        email=email or None, direccion=direccion or None,
        web=web or None, contacto=contacto or None,
        observaciones=observaciones or None, activo=True,
    ))
    db.commit()
    return RedirectResponse("/proveedores", status_code=303)


@app.post("/proveedores/{pid}/toggle")
def proveedor_toggle(pid: int, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    p = db.query(Proveedor).get(pid)
    if p:
        p.activo = not p.activo
        db.commit()
    return RedirectResponse("/proveedores", status_code=303)


@app.post("/proveedores/{pid}/editar", response_class=RedirectResponse)
async def proveedor_editar(
    pid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    p = db.query(Proveedor).get(pid)
    if not p:
        raise HTTPException(404)
    form = await request.form()
    p.nombre = form.get("nombre") or p.nombre
    p.cif = form.get("cif") or None
    p.telefono = form.get("telefono") or None
    p.email = form.get("email") or None
    p.direccion = form.get("direccion") or None
    p.web = form.get("web") or None
    p.contacto = form.get("contacto") or None
    p.observaciones = form.get("observaciones") or None
    db.commit()
    return RedirectResponse("/proveedores?ok=editado", status_code=303)


# ─── Incidencias ──────────────────────────────────────────────────────────────
@app.get("/incidencias", response_class=HTMLResponse)
def incidencias_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = "",
    prioridad: str = "",
):
    query = db.query(Incidencia)
    if estado:
        query = query.filter(Incidencia.estado == estado)
    if prioridad:
        query = query.filter(Incidencia.prioridad == prioridad)
    incidencias = query.order_by(Incidencia.fecha_apertura.desc()).all()
    total = len(incidencias)
    abiertas = sum(1 for i in incidencias if i.estado == "abierta")
    en_proceso = sum(1 for i in incidencias if i.estado == "en_curso")
    criticas = sum(1 for i in incidencias if i.prioridad == "critica" and i.estado != "cerrada")
    return templates.TemplateResponse(request, "incidencias.html", ctx_base(
        request, user,
        incidencias=incidencias, total=total, abiertas=abiertas,
        en_proceso=en_proceso, criticas=criticas,
        estado_filtro=estado, prioridad_filtro=prioridad,
    ))


@app.get("/incidencias/nueva", response_class=HTMLResponse)
def incidencia_nueva_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta: int = Query(None),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True).order_by(Herramienta.nombre).all()
    h_sel = db.query(Herramienta).get(herramienta) if herramienta else None
    return templates.TemplateResponse(request, "nueva_incidencia.html", ctx_base(
        request, user, herramientas=herramientas, herramienta_sel=h_sel
    ))


@app.post("/incidencias/nueva")
def incidencia_nueva_post(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    titulo: str = Form(...),
    tipo: str = Form("averia"),
    prioridad: str = Form("media"),
    descripcion: str = Form(""),
    herramienta_id: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    año = datetime.now().year
    count = db.query(Incidencia).filter(Incidencia.numero.like(f"INC-{año}-%")).count()
    numero = f"INC-{año}-{(count+1):04d}"
    inc = Incidencia(
        numero=numero, titulo=titulo, tipo=tipo, prioridad=prioridad,
        descripcion=descripcion or None, estado="abierta",
        fecha_apertura=datetime.utcnow(),
        herramienta_id=int(herramienta_id) if herramienta_id else None,
        creado_por_id=user.id,
    )
    db.add(inc)
    db.commit()
    return RedirectResponse("/incidencias", status_code=303)


@app.post("/incidencias/{iid}/cerrar")
def incidencia_cerrar(
    iid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    solucion: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    inc = db.query(Incidencia).get(iid)
    if inc:
        inc.estado = "cerrada"
        inc.solucion = solucion or None
        inc.fecha_resolucion = datetime.utcnow()
        db.commit()
    return RedirectResponse("/incidencias", status_code=303)


@app.post("/incidencias/{iid}/editar", response_class=RedirectResponse)
async def incidencia_editar(
    iid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    inc = db.query(Incidencia).get(iid)
    if not inc:
        raise HTTPException(404)
    form = await request.form()
    inc.titulo = form.get("titulo") or inc.titulo
    inc.tipo = form.get("tipo") or inc.tipo
    inc.prioridad = form.get("prioridad") or inc.prioridad
    inc.estado = form.get("estado") or inc.estado
    inc.descripcion = form.get("descripcion") or None
    inc.observaciones = form.get("observaciones") or None
    db.commit()
    return RedirectResponse("/incidencias?ok=editado", status_code=303)


# ─── Reparaciones ─────────────────────────────────────────────────────────────
@app.get("/reparaciones", response_class=HTMLResponse)
def reparaciones_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = "",
):
    query = db.query(Reparacion)
    if estado:
        query = query.filter(Reparacion.estado == estado)
    reparaciones = query.order_by(Reparacion.fecha_entrada.desc()).all()
    total = len(reparaciones)
    en_curso = sum(1 for r in reparaciones if r.estado in ("diagnostico", "en_reparacion", "pendiente_piezas"))
    finalizadas = sum(1 for r in reparaciones if r.estado == "finalizada")
    return templates.TemplateResponse(request, "reparaciones.html", ctx_base(
        request, user,
        reparaciones=reparaciones, total=total, en_curso=en_curso, finalizadas=finalizadas,
        estado_filtro=estado,
    ))


@app.get("/reparaciones/nueva", response_class=HTMLResponse)
def reparacion_nueva_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta: int = Query(None),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True).order_by(Herramienta.nombre).all()
    proveedores = db.query(Proveedor).filter(Proveedor.activo == True).order_by(Proveedor.nombre).all()
    h_sel = db.query(Herramienta).get(herramienta) if herramienta else None
    return templates.TemplateResponse(request, "nueva_reparacion.html", ctx_base(
        request, user, herramientas=herramientas, proveedores=proveedores, herramienta_sel=h_sel
    ))


@app.post("/reparaciones/nueva")
def reparacion_nueva_post(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta_id: str = Form(...),
    diagnostico: str = Form(""),
    proveedor_id: str = Form(""),
    coste_estimado: str = Form(""),
    fecha_prevista: str = Form(""),
    observaciones: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    h_id = int(herramienta_id)
    h = db.query(Herramienta).get(h_id)
    if not h:
        raise HTTPException(404)

    año = datetime.now().year
    count = db.query(Reparacion).filter(Reparacion.numero.like(f"REP-{año}-%")).count()
    numero = f"REP-{año}-{(count+1):04d}"

    rep = Reparacion(
        numero=numero,
        herramienta_id=h_id,
        diagnostico=diagnostico or None,
        proveedor_id=int(proveedor_id) if proveedor_id else None,
        coste_estimado=float(coste_estimado) if coste_estimado else None,
        fecha_entrada=datetime.utcnow(),
        fecha_prevista=datetime.strptime(fecha_prevista, "%Y-%m-%d") if fecha_prevista else None,
        estado="diagnostico",
        observaciones=observaciones or None,
        creado_por_id=user.id,
    )
    db.add(rep)

    # Cambiar estado de la herramienta
    h.estado = "en_reparacion"
    h.ubicacion_texto = "En reparación"
    registrar_movimiento(db, h, "reparacion", "en_reparacion", user,
                         observaciones=f"Reparación {numero}: {diagnostico or ''}")
    db.commit()
    return RedirectResponse("/reparaciones", status_code=303)


@app.post("/reparaciones/{rid}/finalizar")
def reparacion_finalizar(
    rid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    coste_final: str = Form(""),
    almacen_id: str = Form(""),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    rep = db.query(Reparacion).get(rid)
    if not rep:
        raise HTTPException(404)
    rep.estado = "finalizada"
    rep.fecha_salida = datetime.utcnow()
    rep.coste_final = float(coste_final) if coste_final else None

    h = rep.herramienta
    if h:
        almacen = db.query(Almacen).get(int(almacen_id)) if almacen_id else db.query(Almacen).first()
        h.estado = "disponible"
        h.almacen_id = almacen.id if almacen else None
        h.ubicacion_texto = almacen.nombre if almacen else "Almacén"
        h.fecha_ultimo_mantenimiento = date.today()
        registrar_movimiento(db, h, "devolucion_reparacion", "disponible", user,
                             destino=h.ubicacion_texto,
                             observaciones=f"Reparación {rep.numero} finalizada")
    db.commit()
    return RedirectResponse("/reparaciones", status_code=303)


@app.post("/reparaciones/{rid}/editar", response_class=RedirectResponse)
async def reparacion_editar(
    rid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    rep = db.query(Reparacion).get(rid)
    if not rep:
        raise HTTPException(404)
    form = await request.form()
    rep.descripcion = form.get("descripcion") or None
    rep.diagnostico = form.get("diagnostico") or None
    rep.estado = form.get("estado") or rep.estado
    rep.prioridad = form.get("prioridad") or rep.prioridad
    pid = form.get("proveedor_id", "")
    rep.proveedor_id = int(pid) if pid else None
    ce = form.get("coste_estimado", "")
    rep.coste_estimado = float(ce) if ce else None
    fp = form.get("fecha_prevista", "")
    if fp:
        rep.fecha_prevista = datetime.strptime(fp, "%Y-%m-%d")
    rep.observaciones = form.get("observaciones") or None
    db.commit()
    return RedirectResponse("/reparaciones?ok=editado", status_code=303)


# ─── Movimientos: Entregar / Devolver (páginas dedicadas) ─────────────────────
@app.get("/movimientos/entregar", response_class=HTMLResponse)
def movimiento_entregar_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta: int = Query(None),
):
    if not tiene_permiso(user, "entregar"):
        raise HTTPException(403, "Sin permiso")
    herramientas = db.query(Herramienta).filter(
        Herramienta.activa == True, Herramienta.estado == "disponible"
    ).order_by(Herramienta.nombre).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    h_sel = db.query(Herramienta).get(herramienta) if herramienta else None
    return templates.TemplateResponse(request, "movimiento_entregar.html", ctx_base(
        request, user,
        herramientas=herramientas, trabajadores=trabajadores, obras=obras, herramienta_sel=h_sel,
    ))


@app.post("/movimientos/entregar")
def movimiento_entregar_post(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta_id: str = Form(...),
    trabajador_id: str = Form(""),
    obra_id: str = Form(""),
    observaciones: str = Form(""),
):
    if not tiene_permiso(user, "entregar"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).get(int(herramienta_id))
    if not h:
        raise HTTPException(404)
    t_id = int(trabajador_id) if trabajador_id else None
    o_id = int(obra_id) if obra_id else None
    trabajador = db.query(Trabajador).get(t_id) if t_id else None
    h.estado = "entregada"
    h.responsable_id = t_id
    h.obra_id = o_id
    h.almacen_id = None
    h.ubicacion_texto = trabajador.nombre_completo if trabajador else "Entregada"
    registrar_movimiento(db, h, "entrega", "entregada", user, t_id, o_id,
                         destino=h.ubicacion_texto, observaciones=observaciones)
    db.commit()
    return RedirectResponse(f"/herramientas/{h.id}", status_code=303)


@app.get("/movimientos/devolver", response_class=HTMLResponse)
def movimiento_devolver_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta: int = Query(None),
):
    if not tiene_permiso(user, "entregar"):
        raise HTTPException(403, "Sin permiso")
    herramientas = db.query(Herramienta).filter(
        Herramienta.activa == True,
        Herramienta.estado.in_(["entregada", "en_obra", "en_furgoneta", "en_transporte"])
    ).order_by(Herramienta.nombre).all()
    almacenes = db.query(Almacen).filter(Almacen.activo == True).all()
    h_sel = db.query(Herramienta).get(herramienta) if herramienta else None
    return templates.TemplateResponse(request, "movimiento_devolver.html", ctx_base(
        request, user,
        herramientas=herramientas, almacenes=almacenes, herramienta_sel=h_sel,
    ))


@app.post("/movimientos/devolver")
def movimiento_devolver_post(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta_id: str = Form(...),
    almacen_id: str = Form(""),
    observaciones: str = Form(""),
):
    if not tiene_permiso(user, "entregar"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).get(int(herramienta_id))
    if not h:
        raise HTTPException(404)
    a_id = int(almacen_id) if almacen_id else None
    almacen = db.query(Almacen).get(a_id) if a_id else db.query(Almacen).first()
    h.estado = "disponible"
    h.responsable_id = None
    h.obra_id = None
    h.vehiculo_id = None
    h.almacen_id = almacen.id if almacen else None
    h.ubicacion_texto = almacen.nombre if almacen else "Almacén"
    registrar_movimiento(db, h, "devolucion", "disponible", user,
                         destino=h.ubicacion_texto, observaciones=observaciones)
    db.commit()
    return RedirectResponse(f"/herramientas/{h.id}", status_code=303)


# ─── Documentos: subida AJAX ──────────────────────────────────────────────────
@app.post("/documentos/subir")
async def documento_subir(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    herramienta_id: int = Form(...),
    nombre: str = Form(""),
    tipo: str = Form("otro"),
    archivo: UploadFile = File(...),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).get(herramienta_id)
    if not h:
        raise HTTPException(404)

    # Sprint 5.2: validar archivo antes de guardar
    try:
        _, _ext_doc = validar_nombre_archivo(archivo.filename, {'jpg', 'jpeg', 'png', 'webp', 'pdf', 'xlsx', 'csv'})
        _head_doc = await archivo.read(16); await archivo.seek(0)
        validar_contenido_archivo(_head_doc, _ext_doc)
        contenido = await archivo.read(); await archivo.seek(0)
        validar_tamaño_bytes(len(contenido), MAX_UPLOAD_MB)
    except ErrorArchivo as _ea:
        raise HTTPException(400, str(_ea))
    ext = f".{_ext_doc}"
    nombre_archivo = f"{h.codigo}_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}"
    docs_dir = UPLOADS_DIR / "documentos"
    docs_dir.mkdir(parents=True, exist_ok=True)
    ruta = docs_dir / nombre_archivo

    with open(ruta, "wb") as _fd:
        _fd.write(contenido)

    doc = Documento(
        herramienta_id=herramienta_id,
        nombre=nombre or archivo.filename,
        tipo=tipo,
        archivo=nombre_archivo,
        extension=ext.lstrip("."),
        tamano=len(contenido),
        subido_por_id=user.id,
    )
    db.add(doc)
    db.commit()
    return JSONResponse({"ok": True, "id": doc.id, "nombre": doc.nombre, "archivo": nombre_archivo})


# ─── API v1 ───────────────────────────────────────────────────────────────────
@app.get("/api/v1/herramientas")
def api_v1_herramientas(
    q: str = Query(""),
    estado: str = Query(""),
    limit: int = Query(50),
    offset: int = Query(0),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    filtros = []
    if q:
        filtros.append(or_(
            Herramienta.nombre.ilike(f"%{q}%"),
            Herramienta.codigo.ilike(f"%{q}%"),
            Herramienta.num_serie.ilike(f"%{q}%"),
        ))
    if estado:
        filtros.append(Herramienta.estado == estado)
    query = db.query(Herramienta)
    if filtros:
        query = query.filter(*filtros)
    total = query.count()
    herramientas = query.order_by(Herramienta.nombre).offset(offset).limit(limit).all()
    return JSONResponse({
        "total": total,
        "offset": offset,
        "limit": limit,
        "items": [
            {
                "id": h.id,
                "codigo": h.codigo,
                "nombre": h.nombre,
                "marca": h.marca or "",
                "modelo": h.modelo or "",
                "estado": h.estado,
                "num_serie": h.num_serie or "",
                "categoria": h.categoria or "",
            }
            for h in herramientas
        ],
    })


@app.get("/api/v1/herramientas/{hid}")
def api_v1_herramienta_detalle(
    hid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).get(hid)
    if not h:
        raise HTTPException(404, "No encontrada")
    return JSONResponse({
        "id": h.id,
        "codigo": h.codigo,
        "nombre": h.nombre,
        "marca": h.marca or "",
        "modelo": h.modelo or "",
        "estado": h.estado,
        "num_serie": h.num_serie or "",
        "categoria": h.categoria or "",
        "descripcion": h.descripcion or "",
        "valor": float(h.valor) if h.valor else None,
        "fecha_compra": h.fecha_compra.isoformat() if h.fecha_compra else None,
    })

def _herramienta_full_json(h) -> dict:
    """Serializa una herramienta completa para la API v1."""
    return {
        "id": h.id,
        "codigo": h.codigo,
        "nombre": h.nombre,
        "descripcion": h.descripcion or "",
        "categoria": h.categoria or "",
        "subcategoria": h.subcategoria or "",
        "familia": h.familia or "",
        "marca": h.marca or "",
        "modelo": h.modelo or "",
        "fabricante": h.fabricante or "",
        "num_serie": h.num_serie or "",
        "potencia": h.potencia or "",
        "voltaje": h.voltaje or "",
        "peso": float(h.peso) if h.peso else None,
        "color": h.color or "",
        "dimensiones": h.dimensiones or "",
        "activo_fijo": h.activo_fijo or "",
        "vida_util_anos": h.vida_util_anos,
        "estado": h.estado,
        "activa": bool(h.activa),
        "ubicacion_texto": h.ubicacion_texto or "",
        "almacen_id": h.almacen_id,
        "obra_id": h.obra_id,
        "vehiculo_id": h.vehiculo_id,
        "responsable_id": h.responsable_id,
        "fecha_compra": h.fecha_compra.isoformat() if h.fecha_compra else None,
        "precio_compra": float(h.precio_compra) if h.precio_compra else None,
        "garantia_hasta": h.garantia_hasta.isoformat() if h.garantia_hasta else None,
        "proveedor_texto": h.proveedor_texto or "",
        "numero_factura": h.numero_factura or "",
        "observaciones": h.observaciones or "",
        "foto": h.foto or "",
    }


# ─── API v1 — CREATE ──────────────────────────────────────────────────────────
@app.post("/api/v1/herramientas")
async def api_v1_crear_herramienta(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    body: Dict[str, Any] = await request.json()
    codigo = body.get("codigo", "").strip()
    nombre = body.get("nombre", "").strip()
    if not codigo or not nombre:
        raise HTTPException(400, "codigo y nombre son obligatorios")
    if db.query(Herramienta).filter(Herramienta.codigo == codigo).first():
        raise HTTPException(409, f"Código '{codigo}' ya existe")
    h = Herramienta(
        codigo=codigo,
        nombre=nombre,
        descripcion=body.get("descripcion") or None,
        categoria=body.get("categoria") or "Otro",
        subcategoria=body.get("subcategoria") or None,
        familia=body.get("familia") or None,
        marca=body.get("marca") or None,
        modelo=body.get("modelo") or None,
        fabricante=body.get("fabricante") or None,
        num_serie=body.get("num_serie") or None,
        potencia=body.get("potencia") or None,
        voltaje=body.get("voltaje") or None,
        peso=float(body["peso"]) if body.get("peso") else None,
        color=body.get("color") or None,
        dimensiones=body.get("dimensiones") or None,
        activo_fijo=body.get("activo_fijo") or None,
        vida_util_anos=int(body["vida_util_anos"]) if body.get("vida_util_anos") else None,
        estado=body.get("estado") or "disponible",
        fecha_compra=datetime.fromisoformat(body["fecha_compra"]).date() if body.get("fecha_compra") else None,
        precio_compra=float(body["precio_compra"]) if body.get("precio_compra") else None,
        garantia_hasta=datetime.fromisoformat(body["garantia_hasta"]).date() if body.get("garantia_hasta") else None,
        proveedor_texto=body.get("proveedor_texto") or None,
        numero_factura=body.get("numero_factura") or None,
        observaciones=body.get("observaciones") or None,
        almacen_id=int(body["almacen_id"]) if body.get("almacen_id") else None,
        ubicacion_texto=body.get("ubicacion_texto") or None,
        activa=True,
    )
    db.add(h)
    db.flush()
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    registrar_auditoria(db, "herramientas", h.id, "crear_api", user.id,
                        datos_nuevos=snapshot_herramienta(h), resumen=f"Alta API: {h.nombre}", ip=ip)
    db.commit()
    return JSONResponse(_herramienta_full_json(h), status_code=201)


# ─── API v1 — UPDATE ─────────────────────────────────────────────────────────
@app.put("/api/v1/herramientas/{hid}")
async def api_v1_actualizar_herramienta(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = await request.json()
    snap_ant = snapshot_herramienta(h)
    campos = ["nombre", "descripcion", "categoria", "subcategoria", "familia",
              "marca", "modelo", "fabricante", "num_serie", "potencia", "voltaje",
              "color", "dimensiones", "activo_fijo", "proveedor_texto",
              "numero_factura", "observaciones", "ubicacion_texto"]
    for campo in campos:
        if campo in body:
            setattr(h, campo, body[campo] or None)
    if "peso" in body:
        h.peso = float(body["peso"]) if body["peso"] else None
    if "precio_compra" in body:
        h.precio_compra = float(body["precio_compra"]) if body["precio_compra"] else None
    if "vida_util_anos" in body:
        h.vida_util_anos = int(body["vida_util_anos"]) if body["vida_util_anos"] else None
    if "fecha_compra" in body:
        h.fecha_compra = datetime.fromisoformat(body["fecha_compra"]).date() if body["fecha_compra"] else None
    if "garantia_hasta" in body:
        h.garantia_hasta = datetime.fromisoformat(body["garantia_hasta"]).date() if body["garantia_hasta"] else None
    if "almacen_id" in body:
        h.almacen_id = int(body["almacen_id"]) if body["almacen_id"] else None
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    registrar_auditoria(db, "herramientas", h.id, "editar_api", user.id,
                        datos_anteriores=snap_ant, datos_nuevos=snapshot_herramienta(h),
                        resumen=f"Edición API: {h.nombre}", ip=ip)
    db.commit()
    return JSONResponse(_herramienta_full_json(h))


# ─── API v1 — DELETE (baja lógica) ───────────────────────────────────────────
@app.delete("/api/v1/herramientas/{hid}")
async def api_v1_baja_herramienta(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "borrar"):
        raise HTTPException(403, "Sin permiso de administrador")
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = {}
    try:
        body = await request.json()
    except Exception:
        pass
    observaciones = body.get("observaciones", "Baja por API")
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        aplicar_accion(db, h, "baja", user, es_admin=True, observaciones=observaciones, ip=ip)
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse({"ok": True, "estado": h.estado, "activa": bool(h.activa)})


# ─── API v1 — ACCION genérica ────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/accion")
async def api_v1_accion_herramienta(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = await request.json()
    accion = body.get("accion", "").strip()
    if not accion:
        raise HTTPException(400, "accion es obligatorio")
    ACCIONES_ADMIN = {"baja", "restaurar", "archivar", "recuperar", "robada"}
    es_admin = tiene_permiso(user, "borrar")
    if accion in ACCIONES_ADMIN and not es_admin:
        raise HTTPException(403, "Sin permiso de administrador")
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(
            db, h, accion, user,
            es_admin=es_admin,
            trabajador_id=int(body["trabajador_id"]) if body.get("trabajador_id") else None,
            obra_id=int(body["obra_id"]) if body.get("obra_id") else None,
            almacen_id=int(body["almacen_id"]) if body.get("almacen_id") else None,
            vehiculo_id=int(body["vehiculo_id"]) if body.get("vehiculo_id") else None,
            observaciones=body.get("observaciones", ""),
            ip=ip,
        )
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — MOVER ──────────────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/mover")
async def api_v1_mover(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = await request.json()
    destino = body.get("destino", "")
    accion_map = {"obra": "a_obra", "almacen": "a_almacen", "furgoneta": "a_furgoneta"}
    accion = accion_map.get(destino)
    if not accion:
        raise HTTPException(400, f"destino debe ser: {', '.join(accion_map)}")
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(
            db, h, accion, user,
            obra_id=int(body["obra_id"]) if body.get("obra_id") else None,
            almacen_id=int(body["almacen_id"]) if body.get("almacen_id") else None,
            vehiculo_id=int(body["vehiculo_id"]) if body.get("vehiculo_id") else None,
            observaciones=body.get("observaciones", ""),
            ip=ip,
        )
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — ASIGNAR ────────────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/asignar")
async def api_v1_asignar(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = await request.json()
    trabajador_id = body.get("trabajador_id")
    if not trabajador_id:
        raise HTTPException(400, "trabajador_id es obligatorio")
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(
            db, h, "entregar", user,
            trabajador_id=int(trabajador_id),
            observaciones=body.get("observaciones", ""),
            ip=ip,
        )
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — DEVOLVER ───────────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/devolver")
async def api_v1_devolver(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = {}
    try:
        body = await request.json()
    except Exception:
        pass
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(db, h, "devolver", user,
                                   observaciones=body.get("observaciones", ""), ip=ip)
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — REPARACIÓN ─────────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/reparacion")
async def api_v1_reparacion(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = {}
    try:
        body = await request.json()
    except Exception:
        pass
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(db, h, "reparacion", user,
                                   observaciones=body.get("observaciones", ""), ip=ip)
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — INCIDENCIA ─────────────────────────────────────────────────────
@app.post("/api/v1/herramientas/{hid}/incidencia")
async def api_v1_incidencia(
    hid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "borrar"):
        raise HTTPException(403, "Sin permiso de administrador para incidencias")
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    body: Dict[str, Any] = await request.json()
    tipo = body.get("tipo", "").strip()
    if tipo not in {"perdida", "robada", "fuera_servicio"}:
        raise HTTPException(400, "tipo debe ser: perdida, robada, fuera_servicio")
    ip = request.headers.get("X-Forwarded-For", request.client.host if request.client else "")
    try:
        resultado = aplicar_accion(db, h, tipo, user, es_admin=True,
                                   observaciones=body.get("observaciones", ""), ip=ip)
        db.commit()
    except ErrorTransicion as exc:
        db.rollback()
        raise HTTPException(400, str(exc))
    return JSONResponse(resultado)


# ─── API v1 — ETIQUETA / QR ──────────────────────────────────────────────────
@app.get("/api/v1/herramientas/{hid}/etiqueta")
def api_v1_etiqueta(
    hid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    try:
        import qrcode, io as _io, base64
        qr = qrcode.QRCode(version=1, box_size=4, border=2)
        qr.add_data(h.codigo)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        qr_b64 = base64.b64encode(buf.getvalue()).decode()
    except Exception:
        qr_b64 = None
    return JSONResponse({
        "id": h.id,
        "codigo": h.codigo,
        "nombre": h.nombre,
        "marca": h.marca or "",
        "modelo": h.modelo or "",
        "num_serie": h.num_serie or "",
        "estado": h.estado,
        "qr_base64": qr_b64,
        "url_pdf": f"/herramientas/{h.id}/pdf",
    })


# ─── API v1 — HISTORIAL ──────────────────────────────────────────────────────
@app.get("/api/v1/herramientas/{hid}/historial")
def api_v1_historial(
    hid: int,
    limit: int = Query(50),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    movs = db.query(Movimiento).filter(
        Movimiento.herramienta_id == hid
    ).order_by(Movimiento.fecha.desc()).limit(limit).all()
    return JSONResponse({
        "herramienta_id": hid,
        "total": len(movs),
        "items": [
            {
                "id": m.id,
                "fecha": m.fecha.isoformat() if m.fecha else None,
                "tipo": m.tipo,
                "estado_anterior": m.estado_anterior or "",
                "estado_nuevo": m.estado_nuevo or "",
                "destino": m.destino or "",
                "observaciones": m.observaciones or "",
                "usuario_id": m.usuario_id,
            }
            for m in movs
        ],
    })


# ─── API v1 — AUDITORÍA ──────────────────────────────────────────────────────
@app.get("/api/v1/herramientas/{hid}/auditoria")
def api_v1_auditoria_herramienta(
    hid: int,
    limit: int = Query(50),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    h = db.query(Herramienta).filter(Herramienta.id == hid).first()
    if not h:
        raise HTTPException(404, "No encontrada")
    logs = db.query(AuditoriaLog).filter(
        AuditoriaLog.tabla == "herramientas",
        AuditoriaLog.registro_id == hid,
    ).order_by(AuditoriaLog.fecha.desc()).limit(limit).all()
    return JSONResponse({
        "herramienta_id": hid,
        "total": len(logs),
        "items": [
            {
                "id": lg.id,
                "fecha": lg.fecha.isoformat() if lg.fecha else None,
                "accion": lg.accion,
                "usuario_id": lg.usuario_id,
                "resumen": lg.resumen or "",
                "ip": lg.ip or "",
            }
            for lg in logs
        ],
    })


# ─── API v1 — EXPORT Excel ───────────────────────────────────────────────────
@app.get("/api/v1/export/herramientas")
def api_v1_exportar_herramientas(
    estado: str = Query(""),
    activa: str = Query(""),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    q = db.query(Herramienta)
    if estado:
        q = q.filter(Herramienta.estado == estado)
    if activa:
        q = q.filter(Herramienta.activa == (activa.lower() == "true"))
    herramientas = q.order_by(Herramienta.nombre).all()
    excel = exportar_inventario_excel(herramientas)
    nombre = f"herramientas_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )




# ─── Export trabajadores y EPIs ───────────────────────────────────────────────

@app.get("/informes/trabajadores/excel")
def exportar_trabajadores_excel_route(
    activo: str = Query(""),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    q = db.query(Trabajador)
    if activo == "true":
        q = q.filter(Trabajador.activo == True)
    elif activo == "false":
        q = q.filter(Trabajador.activo == False)
    trabajadores = q.order_by(Trabajador.nombre).all()
    excel = exportar_trabajadores_excel(trabajadores)
    nombre = f"trabajadores_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(
        content=excel,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )


@app.get("/api/epis/individuales/disponibles")
def api_epis_disponibles(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    tipo: str = Query(None),
):
    """EPIs individuales sin asignar — para modal de asignacion desde trabajador."""
    q = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.trabajador_id == None,
    )
    if tipo:
        q = q.filter(EPIIndividual.tipo == tipo)
    epis = q.order_by(EPIIndividual.tipo, EPIIndividual.codigo_fabricacion).all()
    return [
        {
            "id": e.id,
            "tipo": e.tipo,
            "codigo": e.codigo_fabricacion,
            "marca": e.marca or "",
            "modelo": e.modelo or "",
            "proxima_revision": e.proxima_revision.isoformat() if e.proxima_revision else None,
            "revision_vencida": e.revision_vencida,
        }
        for e in epis
    ]


@app.get("/informes/epis-trabajadores", response_class=HTMLResponse)
def informe_epis_trabajadores(request: Request, user: Usuario = Depends(requiere_login),
                               db: Session = Depends(get_db)):
    """Informe completo: qué EPIs/ropa/arneses tiene cada trabajador + stock disponible."""
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    # Para cada trabajador armar su resumen
    resumen = []
    for t in trabajadores:
        entregas = db.query(EntregaEPI).filter(EntregaEPI.trabajador_id == t.id).order_by(EntregaEPI.fecha.desc()).all()
        arneses = db.query(EPIIndividual).filter(
            EPIIndividual.trabajador_id == t.id,
            EPIIndividual.estado != "baja"
        ).all()
        if entregas or arneses:
            resumen.append({
                "trabajador": t,
                "entregas": [
                    {"e": e, "items": json.loads(e.items_json or "[]")}
                    for e in entregas
                ],
                "arneses": arneses,
            })
    # Stock disponible
    stock_epi = db.query(EPIIndividual).filter(
        EPIIndividual.estado != "baja",
        EPIIndividual.trabajador_id == None
    ).all()
    stock_por_tipo = {}
    for epi in stock_epi:
        stock_por_tipo.setdefault(epi.tipo, []).append(epi)
    return templates.TemplateResponse(request, "informe_epis_trabajadores.html", ctx_base(
        request, user, db,
        resumen=resumen,
        stock_por_tipo=stock_por_tipo,
        total_trabajadores_con_epis=len(resumen),
    ))


@app.get("/informes/epis-trabajadores/excel")
def informe_epis_trabajadores_excel(user: Usuario = Depends(requiere_login),
                                     db: Session = Depends(get_db)):
    """Exporta a Excel el informe EPIs/ropa/arneses por trabajador."""
    from openpyxl import Workbook as _WB
    from openpyxl.styles import Font as _Font, PatternFill as _Fill, Alignment as _Align, Border as _Border, Side as _Side
    from openpyxl.utils import get_column_letter as _gcl
    import io as _io

    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()

    wb = _WB()

    # ── Hoja 1: Entregas EPIs / Ropa
    ws1 = wb.active; ws1.title = "Entregas EPI y Ropa"
    lado = _Side(style="thin", color="CCCCCC")
    borde = _Border(left=lado, right=lado, top=lado, bottom=lado)
    fill_h = _Fill("solid", fgColor="1B4F8A")
    fill_s = _Fill("solid", fgColor="D6E4F0")
    fill_o = _Fill("solid", fgColor="E8600A")

    ws1.merge_cells("A1:G1")
    ws1["A1"] = "MRD TOOL CONTROL — Entregas de EPIs y Ropa por Trabajador"
    ws1["A1"].font = _Font(bold=True, color="FFFFFF", size=13)
    ws1["A1"].fill = fill_h
    ws1["A1"].alignment = _Align(horizontal="center", vertical="center")
    ws1.row_dimensions[1].height = 28

    cols1 = [("Trabajador", 28), ("Cargo", 22), ("Tipo", 10),
             ("Fecha entrega", 16), ("Artículos", 50), ("Firmado por", 22), ("Obs.", 25)]
    for c, (t_, w) in enumerate(cols1, 1):
        cell = ws1.cell(row=3, column=c, value=t_)
        cell.font = _Font(bold=True, color="FFFFFF", size=11)
        cell.fill = fill_o
        cell.alignment = _Align(horizontal="center")
        cell.border = borde
        ws1.column_dimensions[_gcl(c)].width = w
    ws1.row_dimensions[3].height = 20

    row = 4
    for idx_t, t in enumerate(trabajadores):
        entregas = db.query(EntregaEPI).filter(EntregaEPI.trabajador_id == t.id).order_by(EntregaEPI.fecha.desc()).all()
        if not entregas:
            continue
        bg = fill_s if idx_t % 2 == 0 else _Fill("solid", fgColor="FFFFFF")
        for e in entregas:
            items_str = ", ".join(
                f"{it['nombre']} x{it.get('cantidad',1)}" + (f" T.{it['talla']}" if it.get('talla') else "")
                for it in json.loads(e.items_json or "[]")
            )
            vals = [t.nombre_completo, t.cargo or "", e.tipo.upper(),
                    e.fecha.strftime("%d/%m/%Y") if e.fecha else "",
                    items_str, e.firmado_por or "", e.observaciones or ""]
            for c, v in enumerate(vals, 1):
                cell = ws1.cell(row=row, column=c, value=v)
                cell.fill = bg; cell.border = borde
                cell.alignment = _Align(vertical="center", wrap_text=(c == 5))
            ws1.row_dimensions[row].height = 18
            row += 1

    # ── Hoja 2: Arneses y Absorbedores
    ws2 = wb.create_sheet("Arneses y Absorbedores")
    ws2.merge_cells("A1:F1")
    ws2["A1"] = "MRD TOOL CONTROL — Arneses y Absorbedores Asignados"
    ws2["A1"].font = _Font(bold=True, color="FFFFFF", size=13)
    ws2["A1"].fill = fill_h
    ws2["A1"].alignment = _Align(horizontal="center", vertical="center")
    ws2.row_dimensions[1].height = 28

    cols2 = [("Trabajador", 28), ("Tipo", 14), ("Código fabricación", 22),
             ("Marca / Modelo", 22), ("Estado", 14), ("Próx. revisión", 16)]
    for c, (t_, w) in enumerate(cols2, 1):
        cell = ws2.cell(row=3, column=c, value=t_)
        cell.font = _Font(bold=True, color="FFFFFF", size=11)
        cell.fill = fill_o
        cell.alignment = _Align(horizontal="center")
        cell.border = borde
        ws2.column_dimensions[_gcl(c)].width = w
    ws2.row_dimensions[3].height = 20

    row2 = 4
    epis_asignados = db.query(EPIIndividual).filter(
        EPIIndividual.trabajador_id != None,
        EPIIndividual.estado != "baja"
    ).options(joinedload(EPIIndividual.trabajador)).order_by(EPIIndividual.tipo).all()
    for idx_e, epi in enumerate(epis_asignados):
        bg = fill_s if idx_e % 2 == 0 else _Fill("solid", fgColor="FFFFFF")
        marca_mod = " / ".join(filter(None, [epi.marca, epi.modelo])) or "—"
        vals = [
            epi.trabajador.nombre_completo if epi.trabajador else "—",
            epi.tipo, epi.codigo_fabricacion, marca_mod,
            epi.estado.replace("_", " ").title(),
            epi.proxima_revision.strftime("%d/%m/%Y") if epi.proxima_revision else "Sin programar",
        ]
        for c, v in enumerate(vals, 1):
            cell = ws2.cell(row=row2, column=c, value=v)
            cell.fill = bg; cell.border = borde
            cell.alignment = _Align(vertical="center")
        ws2.row_dimensions[row2].height = 18
        row2 += 1

    # ── Hoja 3: Stock disponible
    ws3 = wb.create_sheet("Stock Disponible")
    ws3.merge_cells("A1:D1")
    ws3["A1"] = "MRD TOOL CONTROL — Stock EPIs Individuales Disponibles"
    ws3["A1"].font = _Font(bold=True, color="FFFFFF", size=13)
    ws3["A1"].fill = fill_h
    ws3["A1"].alignment = _Align(horizontal="center", vertical="center")
    ws3.row_dimensions[1].height = 28

    cols3 = [("Tipo", 18), ("Código fabricación", 24), ("Marca / Modelo", 24), ("Próx. revisión", 16)]
    for c, (t_, w) in enumerate(cols3, 1):
        cell = ws3.cell(row=3, column=c, value=t_)
        cell.font = _Font(bold=True, color="FFFFFF", size=11)
        cell.fill = fill_o
        cell.alignment = _Align(horizontal="center")
        cell.border = borde
        ws3.column_dimensions[_gcl(c)].width = w
    ws3.row_dimensions[3].height = 20

    disponibles = db.query(EPIIndividual).filter(
        EPIIndividual.estado != "baja",
        EPIIndividual.trabajador_id == None
    ).order_by(EPIIndividual.tipo, EPIIndividual.codigo_fabricacion).all()
    for idx_d, epi in enumerate(disponibles):
        bg = fill_s if idx_d % 2 == 0 else _Fill("solid", fgColor="FFFFFF")
        marca_mod = " / ".join(filter(None, [epi.marca, epi.modelo])) or "—"
        vals = [epi.tipo, epi.codigo_fabricacion, marca_mod,
                epi.proxima_revision.strftime("%d/%m/%Y") if epi.proxima_revision else "Sin programar"]
        for c, v in enumerate(vals, 1):
            cell = ws3.cell(row=3 + 1 + idx_d, column=c, value=v)
            cell.fill = bg; cell.border = borde
            cell.alignment = _Align(vertical="center")
        ws3.row_dimensions[3 + 1 + idx_d].height = 18

    buf = _io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    from datetime import date as _date
    nombre = f"informe_epis_{_date.today().strftime('%Y%m%d')}.xlsx"
    return Response(
        content=buf.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )


@app.get("/informes/epis/excel")
def exportar_epis_excel_route(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Exporta historial de entregas de EPIs a Excel."""
    from openpyxl import Workbook as _WB
    from openpyxl.styles import Font as _Font, PatternFill as _Fill, Alignment as _Align, Border as _Border, Side as _Side
    from openpyxl.utils import get_column_letter as _gcl
    import io as _io

    entregas = (
        db.query(EntregaEPI)
        .options(joinedload(EntregaEPI.trabajador))
        .order_by(EntregaEPI.fecha.desc())
        .all()
    )

    wb = _WB(); ws = wb.active; ws.title = "EPIs Entregas"
    lado = _Side(style="thin", color="CCCCCC")
    borde = _Border(left=lado, right=lado, top=lado, bottom=lado)
    fill_h = _Fill("solid", fgColor="1B4F8A")
    fill_s = _Fill("solid", fgColor="D6E4F0")

    ws.merge_cells("A1:G1")
    ws["A1"] = "MRD TOOL CONTROL — Historial de Entregas EPI"
    ws["A1"].font = _Font(bold=True, color="FFFFFF", size=13)
    ws["A1"].fill = fill_h
    ws["A1"].alignment = _Align(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    cols = [("Fecha", 18), ("Trabajador", 28), ("Tipo", 10),
            ("Artículos", 45), ("Firmado por", 20), ("Entregado por", 20), ("Observaciones", 30)]
    for c, (t, w) in enumerate(cols, 1):
        cell = ws.cell(row=3, column=c, value=t)
        cell.font = _Font(bold=True, color="FFFFFF", size=11)
        cell.fill = _Fill("solid", fgColor="E8600A")
        cell.alignment = _Align(horizontal="center", vertical="center")
        cell.border = borde
        ws.column_dimensions[_gcl(c)].width = w
    ws.row_dimensions[3].height = 20

    for i, e in enumerate(entregas):
        row = 4 + i
        items_str = ", ".join(
            f"{it['nombre']} x{it.get('cantidad',1)}"
            + (f" T.{it['talla']}" if it.get("talla") else "")
            for it in json.loads(e.items_json or "[]")
        )
        bg = fill_s if i % 2 == 0 else _Fill("solid", fgColor="FFFFFF")
        vals = [
            e.fecha.strftime("%d/%m/%Y %H:%M") if e.fecha else "",
            e.trabajador.nombre_completo if e.trabajador else "",
            e.tipo.upper() if e.tipo else "",
            items_str,
            e.firmado_por or "",
            e.entregado_por or "",
            e.observaciones or "",
        ]
        for c, v in enumerate(vals, 1):
            cell = ws.cell(row=row, column=c, value=v)
            cell.fill = bg; cell.border = borde
            cell.alignment = _Align(vertical="center", wrap_text=(c == 4))
        ws.row_dimensions[row].height = 18

    ws.freeze_panes = "A4"
    buf = _io.BytesIO(); wb.save(buf)
    nombre = f"epis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={nombre}"},
    )



# ─── Foto herramienta ─────────────────────────────────────────────────────────

@app.post("/herramientas/{herramienta_id}/foto")
async def subir_foto_herramienta(
    herramienta_id: int,
    request: Request,
    foto: UploadFile = File(...),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if user.rol not in ("admin", "almacen"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404, "Herramienta no encontrada")

    # Validate
    contenido = await foto.read()
    try:
        validar_contenido_archivo(contenido, ["image/jpeg", "image/png", "image/webp"])
        validar_tamaño_bytes(contenido, MAX_UPLOAD_MB * 1024 * 1024)
    except ErrorArchivo as e:
        raise HTTPException(400, str(e))

    ext = pathlib.Path(foto.filename or "foto.jpg").suffix.lower() or ".jpg"
    foto_dir = BASE_DIR / "static" / "uploads" / "herramientas"
    foto_dir.mkdir(parents=True, exist_ok=True)
    nombre = f"h_{herramienta_id}{ext}"
    (foto_dir / nombre).write_bytes(contenido)

    h.foto_path = nombre
    db.commit()
    return JSONResponse({"ok": True, "foto_url": f"/static/uploads/herramientas/{nombre}"})


@app.delete("/herramientas/{herramienta_id}/foto")
def borrar_foto_herramienta(
    herramienta_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if user.rol not in ("admin", "almacen"):
        raise HTTPException(403, "Sin permiso")
    h = db.query(Herramienta).filter(Herramienta.id == herramienta_id).first()
    if not h:
        raise HTTPException(404)
    if h.foto_path:
        p = BASE_DIR / "static" / "uploads" / "herramientas" / h.foto_path
        if p.exists():
            p.unlink()
        h.foto_path = None
        db.commit()
    return JSONResponse({"ok": True})


# ─── Búsqueda global ──────────────────────────────────────────────────────────

@app.get("/api/buscar")
def api_buscar_global(
    q: str = Query(""),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """API de búsqueda global: herramientas + trabajadores + obras + maquinaria."""
    if not q or len(q.strip()) < 2:
        return {"herramientas": [], "trabajadores": [], "obras": [], "maquinaria": []}
    q = q.strip()
    like = f"%{q}%"

    herramientas = (
        db.query(Herramienta)
        .filter(Herramienta.activa == True)
        .filter(or_(
            Herramienta.codigo.ilike(like),
            Herramienta.nombre.ilike(like),
            Herramienta.numero_serie.ilike(like),
            Herramienta.categoria.ilike(like),
        ))
        .limit(6).all()
    )
    trabajadores = (
        db.query(Trabajador)
        .filter(or_(
            Trabajador.nombre.ilike(like),
            Trabajador.apellidos.ilike(like),
            Trabajador.dni.ilike(like),
            Trabajador.cargo.ilike(like),
        ))
        .limit(4).all()
    )
    obras = (
        db.query(Obra)
        .filter(or_(
            Obra.nombre.ilike(like),
            Obra.numero.ilike(like),
            Obra.direccion.ilike(like),
        ))
        .limit(4).all()
    )
    maquinaria = (
        db.query(Maquinaria)
        .filter(or_(
            Maquinaria.nombre.ilike(like),
            Maquinaria.matricula.ilike(like),
        ))
        .limit(3).all()
    )
    return {
        "herramientas": [{"id": h.id, "codigo": h.codigo, "nombre": h.nombre, "estado": h.estado} for h in herramientas],
        "trabajadores": [{"id": t.id, "nombre": t.nombre_completo, "cargo": t.cargo or ""} for t in trabajadores],
        "obras": [{"id": o.id, "nombre": o.nombre, "numero": o.numero or ""} for o in obras],
        "maquinaria": [{"id": m.id, "nombre": m.nombre, "matricula": getattr(m, "matricula", "") or ""} for m in maquinaria],
    }


@app.get("/buscar", response_class=HTMLResponse)
def buscar_global(
    request: Request,
    q: str = Query(""),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    """Página de resultados de búsqueda global."""
    herramientas, trabajadores, obras, maquinaria = [], [], [], []
    if q and len(q.strip()) >= 2:
        like = f"%{q.strip()}%"
        herramientas = (
            db.query(Herramienta)
            .filter(Herramienta.activa == True)
            .filter(or_(
                Herramienta.codigo.ilike(like),
                Herramienta.nombre.ilike(like),
                Herramienta.numero_serie.ilike(like),
                Herramienta.categoria.ilike(like),
            ))
            .order_by(Herramienta.nombre).limit(50).all()
        )
        trabajadores = (
            db.query(Trabajador)
            .filter(or_(
                Trabajador.nombre.ilike(like),
                Trabajador.apellidos.ilike(like),
                Trabajador.dni.ilike(like),
                Trabajador.cargo.ilike(like),
            ))
            .order_by(Trabajador.nombre).limit(30).all()
        )
        obras = (
            db.query(Obra)
            .filter(or_(
                Obra.nombre.ilike(like),
                Obra.numero.ilike(like),
                Obra.direccion.ilike(like),
            ))
            .order_by(Obra.nombre).limit(20).all()
        )
        maquinaria = (
            db.query(Maquinaria)
            .filter(or_(
                Maquinaria.nombre.ilike(like),
                Maquinaria.matricula.ilike(like),
            ))
            .limit(20).all()
        )
    total = len(herramientas) + len(trabajadores) + len(obras) + len(maquinaria)
    return templates.TemplateResponse(request, "buscar.html", ctx_base(
        request, user,
        q=q,
        total=total,
        herramientas=herramientas,
        trabajadores=trabajadores,
        obras=obras,
        maquinaria=maquinaria,
    ))


# ─── API v1 — IMPORT Excel ───────────────────────────────────────────────────
@app.post("/api/v1/import/herramientas")
async def api_v1_importar_herramientas(
    request: Request,
    archivo: UploadFile = File(...),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    # Sprint 5.2: validar MIME, magic bytes y tamaño
    try:
        _, _ext_api = validar_nombre_archivo(archivo.filename, {'xlsx'})
        _head_api = await archivo.read(16); await archivo.seek(0)
        validar_contenido_archivo(_head_api, _ext_api)
        contenido = await archivo.read(); await archivo.seek(0)
        validar_tamaño_bytes(len(contenido), MAX_UPLOAD_MB)
    except ErrorArchivo as _ea:
        raise HTTPException(400, str(_ea))
    try:
        resultado = importar_herramientas_excel(db, contenido, user)
        db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(422, f"Error al procesar Excel: {exc}")
    return JSONResponse(resultado)


# ═══════════════════════════════════════════════════════════════════════════════
# MÓDULO MAQUINARIA — Sprint 3.2
# Integración Zebra DS3678-SR (HID Bluetooth): escanea codigo_barras → busca aquí
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/maquinaria", response_class=HTMLResponse)
def maquinaria_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = Query(""),
    q: str = Query(""),
):
    query = db.query(Maquinaria).filter(Maquinaria.activa == True)
    if estado:
        query = query.filter(Maquinaria.estado == estado)
    if q:
        like = f"%{q}%"
        query = query.filter(
            or_(Maquinaria.nombre.ilike(like), Maquinaria.matricula.ilike(like),
                Maquinaria.codigo_barras.ilike(like), Maquinaria.codigo_interno.ilike(like))
        )
    items = query.order_by(Maquinaria.nombre).all()
    total_por_estado = {e: db.query(Maquinaria).filter(
        Maquinaria.activa == True, Maquinaria.estado == e).count()
        for e in ESTADOS_MAQUINARIA}
    return templates.TemplateResponse(request, "maquinaria.html", ctx_base(
        request, user,
        items=items, estados=ESTADOS_MAQUINARIA,
        total_por_estado=total_por_estado,
        filtro_estado=estado, filtro_q=q,
    ))


@app.get("/maquinaria/nueva", response_class=HTMLResponse)
def maquinaria_nueva_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    codigo_barras: str = Query(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    return templates.TemplateResponse(request, "maquinaria_nueva.html", ctx_base(
        request, user,
        tipos=TIPOS_MAQUINARIA,
        estados=ESTADOS_MAQUINARIA,
        prefill_codigo_barras=codigo_barras.strip(),
        scan_origen=bool(codigo_barras.strip()),
    ))


@app.post("/maquinaria/nueva")
def maquinaria_nueva_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    nombre: str = Form(...),
    tipo: str = Form(""),
    marca: str = Form(""),
    modelo: str = Form(""),
    matricula: str = Form(""),
    num_serie: str = Form(""),
    codigo_barras: str = Form(""),
    codigo_interno: str = Form(""),
    estado: str = Form("disponible"),
    ubicacion: str = Form(""),
    responsable: str = Form(""),
    notas: str = Form(""),
):
    if not tiene_permiso(user, "crear"):
        raise HTTPException(403, "Sin permiso")
    # Validar codigo_barras único
    if codigo_barras:
        existe = db.query(Maquinaria).filter(Maquinaria.codigo_barras == codigo_barras.strip()).first()
        if existe:
            return templates.TemplateResponse(request, "maquinaria_nueva.html", ctx_base(
                request, user,
                tipos=TIPOS_MAQUINARIA, estados=ESTADOS_MAQUINARIA,
                prefill_codigo_barras=codigo_barras,
                error=f"El código de barras '{codigo_barras}' ya está registrado.",
            ))
    m = Maquinaria(
        nombre=nombre.strip(),
        tipo=tipo or None,
        marca=marca or None,
        modelo=modelo or None,
        matricula=matricula.strip() or None,
        num_serie=num_serie or None,
        codigo_barras=codigo_barras.strip() or None,
        codigo_interno=codigo_interno.strip() or None,
        estado=estado,
        ubicacion=ubicacion or None,
        responsable=responsable or None,
        notas=notas or None,
    )
    db.add(m)
    db.commit()
    db.refresh(m)
    registrar_auditoria(db, user, "maquinaria", m.id, "crear", None,
                        {"nombre": m.nombre, "codigo_barras": m.codigo_barras})
    return RedirectResponse(f"/maquinaria/{m.id}", status_code=303)


@app.get("/maquinaria/{mid}", response_class=HTMLResponse)
def maquinaria_detalle(
    mid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    qr_b64 = generar_qr_base64(m.codigo_barras or m.codigo_interno or str(m.id))
    return templates.TemplateResponse(request, "maquinaria_detalle.html", ctx_base(
        request, user,
        maquina=m, estados=ESTADOS_MAQUINARIA, qr_b64=qr_b64,
        tipos_maquinaria=TIPOS_MAQUINARIA,
        etiqueta_imprimir_url=f"/maquinaria/{m.id}/etiqueta",
    ))


@app.post("/maquinaria/{mid}/estado")
def maquinaria_update_estado(
    mid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = Form(...),
    ubicacion: str = Form(""),
    responsable: str = Form(""),
    obra_actual: str = Form(""),
    notas: str = Form(""),
):
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    anterior = {"estado": m.estado, "ubicacion": m.ubicacion, "responsable": m.responsable}
    m.estado = estado
    if ubicacion:
        m.ubicacion = ubicacion
    if responsable:
        m.responsable = responsable
    if obra_actual:
        m.obra_actual = obra_actual
    if notas:
        m.notas = (m.notas or "") + f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M')}] {notas}"
    db.commit()
    registrar_auditoria(db, user, "maquinaria", m.id, "cambio_estado",
                        anterior, {"estado": estado, "ubicacion": ubicacion})
    # Sprint 4.2: dispatch evento de maquinaria
    try:
        auto_engine.dispatch_evento(
            tipo_evento="evento_maquinaria",
            estado_nuevo=estado,
            item={
                "tipo": "maquinaria",
                "id": m.id,
                "codigo": m.codigo_interno or m.codigo_barras or str(m.id),
                "nombre": m.nombre,
                "marca": m.marca or "",
                "estado": estado,
                "dias": 0,
                "enlace": f"/maquinaria/{m.id}",
            },
            db=db,
        )
    except Exception:
        pass
    return RedirectResponse(f"/maquinaria/{m.id}", status_code=303)


@app.post("/maquinaria/{mid}/editar", response_class=RedirectResponse)
async def maquinaria_editar(
    mid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    form = await request.form()
    m.nombre = form.get("nombre") or m.nombre
    m.tipo = form.get("tipo") or m.tipo
    m.marca = form.get("marca") or None
    m.modelo = form.get("modelo") or None
    m.matricula = form.get("matricula") or None
    m.num_serie = form.get("num_serie") or None
    m.estado = form.get("estado") or m.estado
    m.ubicacion = form.get("ubicacion") or None
    m.responsable = form.get("responsable") or None
    m.notas = form.get("notas") or None
    km = form.get("km_actuales", "")
    if km:
        try:
            m.km_actuales = float(km)
        except ValueError:
            pass
    db.commit()
    return RedirectResponse(f"/maquinaria/{mid}?ok=editado", status_code=303)


@app.get("/maquinaria/{mid}/etiqueta", response_class=HTMLResponse)
def maquinaria_etiqueta(
    mid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    codigo = m.codigo_barras or m.codigo_interno or str(m.id)
    qr_b64 = generar_qr_base64(codigo)
    return templates.TemplateResponse(request, "maquinaria_etiqueta.html", ctx_base(
        request, user,
        maquina=m,
        codigo=codigo,
        qr_b64=qr_b64,
        empresa=COMPANY_NAME,
    ))


@app.post("/maquinaria/{mid}/foto", response_class=RedirectResponse)
async def maquinaria_foto(
    mid: int,
    foto: UploadFile = File(...),
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    carpeta = BASE_DIR / "static" / "uploads" / "maquinaria"
    carpeta.mkdir(parents=True, exist_ok=True)
    if m.foto:
        old_p = carpeta / m.foto
        if old_p.exists():
            old_p.unlink()
    ext = (foto.filename or "").rsplit(".", 1)[-1].lower() or "jpg"
    import time as _t
    nombre = f"{mid}_{int(_t.time())}.{ext}"
    data = await foto.read()
    (carpeta / nombre).write_bytes(data)
    m.foto = nombre
    db.commit()
    return RedirectResponse(f"/maquinaria/{mid}?ok=foto", status_code=303)


@app.post("/maquinaria/{mid}/foto/eliminar", response_class=RedirectResponse)
def maquinaria_foto_eliminar(
    mid: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    m = db.query(Maquinaria).get(mid)
    if m and m.foto:
        p = BASE_DIR / "static" / "uploads" / "maquinaria" / m.foto
        if p.exists():
            p.unlink()
        m.foto = None
        db.commit()
    return RedirectResponse(f"/maquinaria/{mid}?ok=foto_eliminada", status_code=303)


# API JSON para maquinaria
@app.get("/api/v1/maquinaria")
def api_maquinaria_list(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = Query(""),
):
    q = db.query(Maquinaria).filter(Maquinaria.activa == True)
    if estado:
        q = q.filter(Maquinaria.estado == estado)
    items = q.order_by(Maquinaria.nombre).all()
    return JSONResponse([{
        "id": m.id, "nombre": m.nombre, "tipo": m.tipo,
        "codigo_barras": m.codigo_barras, "matricula": m.matricula,
        "estado": m.estado, "estado_label": ESTADOS_MAQUINARIA.get(m.estado, m.estado),
        "ubicacion": m.ubicacion, "responsable": m.responsable,
    } for m in items])



# ═══════════════════════════════════════════════════════════════════════════════
#  SPRINT 4.1 — MOTOR DE AUTOMATIZACIONES
# ═══════════════════════════════════════════════════════════════════════════════

def ctx_auto(request, user, **kw):
    """Helper de contexto base para templates de automatizaciones."""
    return {
        **ctx_base(request, user),
        "estados_auto": ESTADOS_AUTOMATIZACION,
        "prioridades_auto": PRIORIDADES_AUTOMATIZACION,
        "tipos_disparador": TIPOS_DISPARADOR,
        "tipos_condicion": TIPOS_CONDICION,
        "tipos_accion": TIPOS_ACCION,
        "prioridades_aviso": PRIORIDADES_AVISO,
        **kw,
    }


# ─── Listado de automatizaciones ─────────────────────────────────────────────
@app.get("/automatizaciones", response_class=HTMLResponse)
def automatizaciones_list(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = Query(""),
    q: str = Query(""),
):
    query = db.query(Automatizacion)
    if estado:
        query = query.filter(Automatizacion.estado == estado)
    if q:
        query = query.filter(Automatizacion.nombre.ilike(f"%{q}%"))
    items = query.order_by(Automatizacion.id.desc()).all()

    # KPI por estado
    total_por_estado = {k: 0 for k in ESTADOS_AUTOMATIZACION}
    for item in db.query(Automatizacion).all():
        if item.estado in total_por_estado:
            total_por_estado[item.estado] += 1

    # Avisos sin leer
    avisos_sin_leer = db.query(Aviso).filter(Aviso.leido == False, Aviso.archivado == False).count()

    return templates.TemplateResponse(request, "automatizaciones.html", ctx_auto(
        request, user,
        items=items,
        filtro_estado=estado,
        filtro_q=q,
        total_por_estado=total_por_estado,
        avisos_sin_leer=avisos_sin_leer,
    ))


# ─── Nueva automatización — GET ───────────────────────────────────────────────
@app.get("/automatizaciones/nueva", response_class=HTMLResponse)
def automatizacion_nueva_get(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    return templates.TemplateResponse(request, "automatizacion_nueva.html", ctx_auto(
        request, user,
        auto=None,
        error=None,
    ))


# ─── Nueva automatización — POST ─────────────────────────────────────────────
@app.post("/automatizaciones/nueva", response_class=HTMLResponse)
async def automatizacion_nueva_post(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    form = await request.form()

    nombre = (form.get("nombre") or "").strip()
    if not nombre:
        return templates.TemplateResponse(request, "automatizacion_nueva.html", ctx_auto(
            request, user, auto=None, error="El nombre es obligatorio.",
        ))

    tipo_disparador = form.get("tipo_disparador") or "manual"
    prioridad = form.get("prioridad") or "media"
    descripcion = (form.get("descripcion") or "").strip()

    # Config disparador
    config_disparador = {}
    if tipo_disparador == "intervalo":
        config_disparador["intervalo_min"] = int(form.get("intervalo_min") or 60)
    elif tipo_disparador == "diario":
        config_disparador["hora"] = form.get("hora_diario") or "08:00"

    # Condiciones (una por formulario simplificado)
    tipo_cond = form.get("tipo_condicion") or ""
    condiciones = []
    if tipo_cond and tipo_cond != "ninguna":
        cond = {"tipo": tipo_cond}
        if tipo_cond in ("herramienta_dias_entregada", "reparacion_retrasada",
                          "maquinaria_sin_movimiento", "mantenimiento_proximo_itv"):
            cond["dias"] = int(form.get("cond_dias") or 30)
        condiciones.append(cond)

    # Acciones (una acción principal)
    tipo_accion = form.get("tipo_accion") or "crear_aviso"
    accion_titulo = (form.get("accion_titulo") or "Aviso: {nombre}").strip()
    accion_mensaje = (form.get("accion_mensaje") or "El activo {nombre} ({codigo}) requiere atención.").strip()
    accion_prioridad = form.get("accion_prioridad") or "media"
    acciones = [{
        "tipo": tipo_accion,
        "titulo": accion_titulo,
        "mensaje": accion_mensaje,
        "prioridad": accion_prioridad,
    }]

    auto = Automatizacion(
        nombre=nombre,
        descripcion=descripcion,
        estado="activa",
        prioridad=prioridad,
        tipo_disparador=tipo_disparador,
        config_disparador=json.dumps(config_disparador),
        condiciones=json.dumps(condiciones),
        acciones=json.dumps(acciones),
        creado_por_id=user.id,
        version=1,
    )
    # Calcular próxima ejecución
    auto.proxima_ejecucion = auto_engine.calcular_proxima_ejecucion(
        tipo_disparador, config_disparador
    )

    db.add(auto)
    db.commit()
    db.refresh(auto)

    registrar_auditoria(db, user, "automatizacion", auto.id, "crear",
                        None, {"nombre": auto.nombre})
    return RedirectResponse(f"/automatizaciones/{auto.id}", status_code=303)


# ─── Detalle de automatización ────────────────────────────────────────────────
@app.get("/automatizaciones/{auto_id}", response_class=HTMLResponse)
def automatizacion_detalle(
    auto_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)

    historial = (
        db.query(EjecucionAutomatizacion)
        .filter(EjecucionAutomatizacion.automatizacion_id == auto_id)
        .order_by(EjecucionAutomatizacion.fecha.desc())
        .limit(30)
        .all()
    )

    # Parse JSON para mostrar en template
    try:
        condiciones = json.loads(auto.condiciones or "[]")
    except Exception:
        condiciones = []
    try:
        acciones = json.loads(auto.acciones or "[]")
    except Exception:
        acciones = []
    try:
        config_disp = json.loads(auto.config_disparador or "{}")
    except Exception:
        config_disp = {}

    avisos = (
        db.query(Aviso)
        .filter(Aviso.automatizacion_id == auto_id, Aviso.archivado == False)
        .order_by(Aviso.creado_en.desc())
        .limit(20)
        .all()
    )

    return templates.TemplateResponse(request, "automatizacion_detalle.html", ctx_auto(
        request, user,
        auto=auto,
        historial=historial,
        condiciones=condiciones,
        acciones=acciones,
        config_disp=config_disp,
        avisos=avisos,
        es_admin=True,
    ))


# ─── Activar/pausar automatización ───────────────────────────────────────────
@app.post("/automatizaciones/{auto_id}/activar")
def automatizacion_activar(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)
    auto.estado = "activa"
    config = {}
    try:
        config = json.loads(auto.config_disparador or "{}")
    except Exception:
        pass
    auto.proxima_ejecucion = auto_engine.calcular_proxima_ejecucion(auto.tipo_disparador, config)
    db.commit()
    registrar_auditoria(db, user, "automatizacion", auto.id, "activar", None, {"estado": "activa"})
    return RedirectResponse(f"/automatizaciones/{auto_id}", status_code=303)

@app.post("/maquinaria/{mid}/eliminar", response_class=RedirectResponse)
def maquinaria_eliminar(
    mid: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    if not tiene_permiso(user, "editar"):
        raise HTTPException(403, "Sin permiso")
    m = db.query(Maquinaria).get(mid)
    if not m:
        raise HTTPException(404)
    # Eliminar foto si existe
    import os as _os
    if m.foto:
        try:
            foto_path = _os.path.join("static", "uploads", "maquinaria", m.foto)
            if _os.path.exists(foto_path):
                _os.remove(foto_path)
        except Exception:
            pass
    db.delete(m)
    db.commit()
    return RedirectResponse("/maquinaria?ok=eliminado", status_code=303)



@app.post("/automatizaciones/{auto_id}/pausar")
def automatizacion_pausar(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)
    auto.estado = "pausada"
    auto.proxima_ejecucion = None
    db.commit()
    registrar_auditoria(db, user, "automatizacion", auto.id, "pausar", None, {"estado": "pausada"})
    return RedirectResponse(f"/automatizaciones/{auto_id}", status_code=303)


# ─── Archivar (no eliminar) ───────────────────────────────────────────────────
@app.post("/automatizaciones/{auto_id}/archivar")
def automatizacion_archivar(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)
    auto.estado = "archivada"
    auto.proxima_ejecucion = None
    db.commit()
    registrar_auditoria(db, user, "automatizacion", auto.id, "archivar", None, {})
    return RedirectResponse("/automatizaciones", status_code=303)


# ─── Duplicar ─────────────────────────────────────────────────────────────────
@app.post("/automatizaciones/{auto_id}/duplicar")
def automatizacion_duplicar(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    src = db.query(Automatizacion).get(auto_id)
    if not src:
        raise HTTPException(404)
    nueva = Automatizacion(
        nombre=f"{src.nombre} (copia)",
        descripcion=src.descripcion,
        estado="inactiva",
        prioridad=src.prioridad,
        tipo_disparador=src.tipo_disparador,
        config_disparador=src.config_disparador,
        condiciones=src.condiciones,
        acciones=src.acciones,
        creado_por_id=user.id,
        version=1,
    )
    db.add(nueva)
    db.commit()
    db.refresh(nueva)
    registrar_auditoria(db, user, "automatizacion", nueva.id, "duplicar",
                        None, {"fuente": auto_id})
    return RedirectResponse(f"/automatizaciones/{nueva.id}", status_code=303)


# ─── Ejecutar manualmente ────────────────────────────────────────────────────
@app.post("/automatizaciones/{auto_id}/ejecutar")
def automatizacion_ejecutar(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    resultado = auto_engine.ejecutar_automatizacion(
        auto_id, db, modo="manual", simulacion=False, usuario_id=user.id
    )
    registrar_auditoria(db, user, "automatizacion", auto_id, "ejecutar_manual",
                        None, {"resultado": resultado.get("resultado")})
    return RedirectResponse(f"/automatizaciones/{auto_id}?ejecutado=1", status_code=303)


# ─── Simular ─────────────────────────────────────────────────────────────────
@app.post("/automatizaciones/{auto_id}/simular", response_class=HTMLResponse)
def automatizacion_simular(
    auto_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    resultado = auto_engine.ejecutar_automatizacion(
        auto_id, db, modo="simulacion", simulacion=True, usuario_id=user.id
    )

    auto = db.query(Automatizacion).get(auto_id)
    try:
        condiciones = json.loads(auto.condiciones or "[]")
    except Exception:
        condiciones = []
    try:
        acciones = json.loads(auto.acciones or "[]")
    except Exception:
        acciones = []
    try:
        config_disp = json.loads(auto.config_disparador or "{}")
    except Exception:
        config_disp = {}

    historial = (
        db.query(EjecucionAutomatizacion)
        .filter(EjecucionAutomatizacion.automatizacion_id == auto_id)
        .order_by(EjecucionAutomatizacion.fecha.desc())
        .limit(30)
        .all()
    )
    avisos = (
        db.query(Aviso)
        .filter(Aviso.automatizacion_id == auto_id, Aviso.archivado == False)
        .order_by(Aviso.creado_en.desc())
        .limit(20)
        .all()
    )

    return templates.TemplateResponse(request, "automatizacion_detalle.html", ctx_auto(
        request, user,
        auto=auto,
        historial=historial,
        condiciones=condiciones,
        acciones=acciones,
        config_disp=config_disp,
        avisos=avisos,
        resultado_simulacion=resultado,
        es_admin=True,
    ))


# ─── API: historial de ejecuciones ──────────────────────────────────────────
@app.get("/api/v1/automatizaciones/{auto_id}/historial")
def api_auto_historial(
    auto_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    limit: int = Query(20, le=100),
):
    historial = (
        db.query(EjecucionAutomatizacion)
        .filter(EjecucionAutomatizacion.automatizacion_id == auto_id)
        .order_by(EjecucionAutomatizacion.fecha.desc())
        .limit(limit)
        .all()
    )
    return JSONResponse([{
        "id": e.id,
        "fecha": e.fecha.isoformat() if e.fecha else None,
        "modo": e.modo,
        "resultado": e.resultado,
        "acciones_ejecutadas": e.acciones_ejecutadas,
        "items_afectados": e.items_afectados,
        "duracion_ms": e.duracion_ms,
        "error": e.error,
    } for e in historial])


# ─── API: avisos ─────────────────────────────────────────────────────────────
@app.get("/api/v1/avisos")
def api_avisos_list(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    solo_no_leidos: bool = Query(False),
    limit: int = Query(50, le=200),
):
    q = db.query(Aviso).filter(Aviso.archivado == False)
    if solo_no_leidos:
        q = q.filter(Aviso.leido == False)
    avisos = q.order_by(Aviso.creado_en.desc()).limit(limit).all()
    return JSONResponse([{
        "id": a.id,
        "titulo": a.titulo,
        "mensaje": a.mensaje,
        "prioridad": a.prioridad,
        "tipo": a.tipo,
        "leido": a.leido,
        "enlace": a.enlace,
        "creado_en": a.creado_en.isoformat() if a.creado_en else None,
        "automatizacion_id": a.automatizacion_id,
    } for a in avisos])


@app.post("/api/v1/avisos/{aviso_id}/leer")
def api_aviso_leer(
    aviso_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    aviso = db.query(Aviso).get(aviso_id)
    if not aviso:
        raise HTTPException(404)
    aviso.leido = True
    aviso.leido_en = datetime.utcnow()
    db.commit()
    return JSONResponse({"ok": True})


@app.post("/api/v1/avisos/{aviso_id}/archivar")
def api_aviso_archivar(
    aviso_id: int,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    aviso = db.query(Aviso).get(aviso_id)
    if not aviso:
        raise HTTPException(404)
    aviso.archivado = True
    aviso.leido = True
    db.commit()
    return JSONResponse({"ok": True})


# ─── Panel de avisos ─────────────────────────────────────────────────────────
@app.get("/avisos", response_class=HTMLResponse)
def avisos_panel(
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    mostrar: str = Query("activos"),  # activos | todos | archivados
):
    q = db.query(Aviso)
    if mostrar == "archivados":
        q = q.filter(Aviso.archivado == True)
    elif mostrar == "todos":
        pass
    else:
        q = q.filter(Aviso.archivado == False)

    avisos = q.order_by(Aviso.creado_en.desc()).limit(200).all()
    total_sin_leer = db.query(Aviso).filter(Aviso.leido == False, Aviso.archivado == False).count()

    return templates.TemplateResponse(request, "avisos.html", ctx_base(
        request, user,
        avisos=avisos,
        mostrar=mostrar,
        total_sin_leer=total_sin_leer,
        prioridades_aviso=PRIORIDADES_AVISO,
    ))


# ═══════════════════════════════════════════════════════════════════════════════
#  SPRINT 4.2 — EDITAR AUTOMATIZACIÓN + GESTIÓN DE LISTENERS
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/automatizaciones/{auto_id}/editar", response_class=HTMLResponse)
def automatizacion_editar_get(
    auto_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)
    if auto.estado == "archivada":
        raise HTTPException(400, "No se puede editar una automatización archivada.")

    try:
        condiciones = json.loads(auto.condiciones or "[]")
    except Exception:
        condiciones = []
    try:
        acciones = json.loads(auto.acciones or "[]")
    except Exception:
        acciones = []
    try:
        config_disp = json.loads(auto.config_disparador or "{}")
    except Exception:
        config_disp = {}

    # Get list of users for notificar_usuario action
    usuarios = db.query(Usuario).filter(Usuario.activo == True).order_by(Usuario.username).all()

    return templates.TemplateResponse(request, "automatizacion_editar.html", ctx_auto(
        request, user,
        auto=auto,
        condiciones=condiciones,
        acciones=acciones,
        config_disp=config_disp,
        usuarios=usuarios,
        error=None,
    ))


@app.post("/automatizaciones/{auto_id}/editar", response_class=HTMLResponse)
async def automatizacion_editar_post(
    auto_id: int,
    request: Request,
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    auto = db.query(Automatizacion).get(auto_id)
    if not auto:
        raise HTTPException(404)
    if auto.estado == "archivada":
        raise HTTPException(400)

    form = await request.form()

    nombre = (form.get("nombre") or "").strip()
    if not nombre:
        usuarios = db.query(Usuario).filter(Usuario.activo == True).all()
        return templates.TemplateResponse(request, "automatizacion_editar.html", ctx_auto(
            request, user, auto=auto,
            condiciones=json.loads(auto.condiciones or "[]"),
            acciones=json.loads(auto.acciones or "[]"),
            config_disp=json.loads(auto.config_disparador or "{}"),
            usuarios=usuarios,
            error="El nombre es obligatorio.",
        ))

    tipo_disparador = form.get("tipo_disparador") or "manual"
    prioridad = form.get("prioridad") or "media"
    descripcion = (form.get("descripcion") or "").strip()

    # Config disparador
    config_disparador = {}
    if tipo_disparador == "intervalo":
        config_disparador["intervalo_min"] = int(form.get("intervalo_min") or 60)
    elif tipo_disparador == "diario":
        config_disparador["hora"] = form.get("hora_diario") or "08:00"
    elif tipo_disparador in ("evento_herramienta", "evento_maquinaria"):
        config_disparador["filtro_estado"] = form.get("filtro_estado_evento") or ""

    # Condiciones — hasta 3 condiciones con AND
    condiciones = []
    for i in range(1, 4):
        tipo_cond = form.get(f"tipo_condicion_{i}") or ""
        if not tipo_cond or tipo_cond == "ninguna":
            continue
        cond = {"tipo": tipo_cond}
        dias_val = form.get(f"cond_dias_{i}")
        if dias_val:
            cond["dias"] = int(dias_val)
        estado_val = form.get(f"cond_estado_{i}")
        if estado_val:
            cond["estado"] = estado_val
        condiciones.append(cond)

    # Acciones — hasta 2 acciones
    acciones = []
    for i in range(1, 3):
        tipo_accion = form.get(f"tipo_accion_{i}") or ""
        if not tipo_accion or tipo_accion == "ninguna":
            continue
        accion = {
            "tipo": tipo_accion,
            "titulo": (form.get(f"accion_titulo_{i}") or "Aviso: {nombre}").strip(),
            "mensaje": (form.get(f"accion_mensaje_{i}") or "").strip(),
            "prioridad": form.get(f"accion_prioridad_{i}") or "media",
        }
        if tipo_accion == "cambiar_estado_herramienta":
            accion["estado_destino"] = form.get(f"accion_estado_destino_{i}") or ""
        if tipo_accion == "notificar_usuario":
            accion["username_destino"] = form.get(f"accion_username_{i}") or ""
        if tipo_accion == "registrar_log":
            accion["nivel"] = form.get(f"accion_nivel_{i}") or "info"
        acciones.append(accion)

    # Snapshot anterior
    snap_ant = {
        "nombre": auto.nombre, "estado": auto.estado,
        "tipo_disparador": auto.tipo_disparador,
    }

    auto.nombre = nombre
    auto.descripcion = descripcion
    auto.prioridad = prioridad
    auto.tipo_disparador = tipo_disparador
    auto.config_disparador = json.dumps(config_disparador)
    auto.condiciones = json.dumps(condiciones)
    auto.acciones = json.dumps(acciones)
    auto.version = (auto.version or 1) + 1
    auto.proxima_ejecucion = auto_engine.calcular_proxima_ejecucion(
        tipo_disparador, config_disparador
    )

    db.commit()

    # Actualizar listeners si es trigger de evento
    if tipo_disparador in ("evento_herramienta", "evento_maquinaria"):
        auto_engine.registrar_listener_eventos(
            auto.id, tipo_disparador,
            config_disparador.get("filtro_estado", "")
        )
    else:
        auto_engine.deregistrar_listener(auto.id)

    registrar_auditoria(db, user, "automatizacion", auto.id, "editar",
                        snap_ant, {"nombre": auto.nombre, "version": auto.version})

    return RedirectResponse(f"/automatizaciones/{auto_id}", status_code=303)


# ─── API: estado rápido de automatizaciones ──────────────────────────────────
@app.get("/api/v1/automatizaciones")
def api_automatizaciones_list(
    user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
    estado: str = Query(""),
):
    q = db.query(Automatizacion).filter(Automatizacion.estado != "archivada")
    if estado:
        q = q.filter(Automatizacion.estado == estado)
    items = q.order_by(Automatizacion.nombre).all()
    return JSONResponse([{
        "id": a.id,
        "nombre": a.nombre,
        "estado": a.estado,
        "tipo_disparador": a.tipo_disparador,
        "ultimo_resultado": a.ultimo_resultado,
        "ultima_ejecucion": a.ultima_ejecucion.isoformat() if a.ultima_ejecucion else None,
        "proxima_ejecucion": a.proxima_ejecucion.isoformat() if a.proxima_ejecucion else None,
        "total_ejecuciones": a.total_ejecuciones or 0,
    } for a in items])


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 4.3 — CENTRO INTELIGENTE DE NOTIFICACIONES
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/notificaciones")
async def notificaciones_panel(request: Request, db: Session = Depends(get_db),
                                user: Usuario = Depends(requiere_login)):
    canales = db.query(CanalNotificacion).order_by(CanalNotificacion.id).all()
    log = db.query(NotificacionEnviada).order_by(
        NotificacionEnviada.fecha_envio.desc()).limit(50).all()
    return templates.TemplateResponse(request, "notificaciones.html", ctx_base(
        request, user, db,
        canales=canales,
        log=log,
        tipos_canal=TIPOS_CANAL,
        prioridades_canal=PRIORIDADES_CANAL,
    ))


@app.get("/notificaciones/nuevo-canal")
async def notificaciones_nuevo_canal_get(request: Request,
                                          db: Session = Depends(get_db),
                                          user: Usuario = Depends(requiere_login)):
    return templates.TemplateResponse(request, "notificaciones.html", ctx_base(
        request, user, db,
        canales=db.query(CanalNotificacion).order_by(CanalNotificacion.id).all(),
        log=[],
        tipos_canal=TIPOS_CANAL,
        prioridades_canal=PRIORIDADES_CANAL,
        mostrar_form=True,
        error=None,
    ))


@app.post("/notificaciones/nuevo-canal")
async def notificaciones_nuevo_canal_post(
    request: Request, db: Session = Depends(get_db),
    user: Usuario = Depends(requiere_login),
    nombre: str = Form(...),
    tipo: str = Form(...),
    prioridad_minima: str = Form("media"),
    # Email
    smtp_host: str = Form(""),
    smtp_port: str = Form("587"),
    smtp_user: str = Form(""),
    smtp_pass: str = Form(""),
    smtp_tls: str = Form("1"),
    destinatarios: str = Form(""),
    # Webhook
    webhook_url: str = Form(""),
    webhook_incluir_enlace: str = Form("1"),
):
    if tipo not in TIPOS_CANAL:
        return templates.TemplateResponse(request, "notificaciones.html", ctx_base(
            request, user, db,
            canales=db.query(CanalNotificacion).all(), log=[],
            tipos_canal=TIPOS_CANAL, prioridades_canal=PRIORIDADES_CANAL,
            mostrar_form=True, error="Tipo de canal inválido."))

    if tipo == "email":
        cfg = {
            "smtp_host": smtp_host.strip(),
            "smtp_port": int(smtp_port) if smtp_port.isdigit() else 587,
            "smtp_user": smtp_user.strip(),
            "smtp_pass": smtp_pass,
            "smtp_tls": smtp_tls == "1",
            "destinatarios": [e.strip() for e in destinatarios.split(",") if e.strip()],
        }
        if not cfg["smtp_host"] or not cfg["destinatarios"]:
            return templates.TemplateResponse(request, "notificaciones.html", ctx_base(
                request, user, db,
                canales=db.query(CanalNotificacion).all(), log=[],
                tipos_canal=TIPOS_CANAL, prioridades_canal=PRIORIDADES_CANAL,
                mostrar_form=True, error="Faltan servidor SMTP o destinatarios."))
    else:
        url = webhook_url.strip()
        if not url.startswith(("http://", "https://")):
            return templates.TemplateResponse(request, "notificaciones.html", ctx_base(
                request, user, db,
                canales=db.query(CanalNotificacion).all(), log=[],
                tipos_canal=TIPOS_CANAL, prioridades_canal=PRIORIDADES_CANAL,
                mostrar_form=True, error="URL de webhook inválida."))
        cfg = {
            "url": url,
            "incluir_enlace": webhook_incluir_enlace == "1",
        }

    canal = CanalNotificacion(
        nombre=nombre[:120],
        tipo=tipo,
        prioridad_minima=prioridad_minima,
        config=__import__("json").dumps(cfg),
    )
    db.add(canal)
    db.commit()
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/notificaciones?ok=Canal+creado", status_code=303)


@app.post("/notificaciones/canal/{canal_id}/activar")
async def notificaciones_activar(canal_id: int, db: Session = Depends(get_db),
                                  user: Usuario = Depends(requiere_login)):
    canal = db.query(CanalNotificacion).filter(CanalNotificacion.id == canal_id).first()
    if canal:
        canal.activo = not canal.activo
        db.commit()
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/notificaciones", status_code=303)


@app.post("/notificaciones/canal/{canal_id}/eliminar")
async def notificaciones_eliminar(canal_id: int, db: Session = Depends(get_db),
                                   user: Usuario = Depends(requiere_login)):
    canal = db.query(CanalNotificacion).filter(CanalNotificacion.id == canal_id).first()
    if canal:
        db.delete(canal)
        db.commit()
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/notificaciones", status_code=303)


@app.post("/api/v1/notificaciones/test/{canal_id}")
async def notificaciones_test(canal_id: int, db: Session = Depends(get_db),
                               user: Usuario = Depends(requiere_login)):
    error = notif_engine.enviar_test(canal_id, db)
    if error:
        raise HTTPException(400, detail=error)
    return {"ok": True, "mensaje": "Notificación de prueba enviada."}


@app.get("/api/v1/notificaciones/log")
async def notificaciones_log_api(limit: int = 50, db: Session = Depends(get_db),
                                  user: Usuario = Depends(requiere_login)):
    rows = db.query(NotificacionEnviada).order_by(
        NotificacionEnviada.fecha_envio.desc()).limit(limit).all()
    return [{"id": r.id, "canal_id": r.canal_id, "aviso_titulo": r.aviso_titulo,
             "resultado": r.resultado, "reintentos": r.reintentos,
             "fecha": r.fecha_envio.isoformat() if r.fecha_envio else None,
             "detalle": r.detalle} for r in rows]


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 4.7 — INFORMES INTELIGENTES — Rutas adicionales
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/informes/resumen/pdf")
def informe_pdf_resumen(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    from config import COMPANY_NAME as _CN
    analisis = generar_analisis_inteligente(db)
    pdf = exportar_pdf_resumen(analisis, _CN)
    nombre = f"resumen_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename={nombre}"})


@app.get("/informes/maquinaria/excel")
def informe_maquinaria_excel(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    items = db.query(Maquinaria).filter(Maquinaria.activa == True).order_by(Maquinaria.nombre).all()
    excel = exportar_maquinaria_excel(items)
    nombre = f"maquinaria_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(content=excel,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename={nombre}"})


@app.get("/informes/incidencias/excel")
def informe_incidencias_excel(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    items = db.query(Incidencia).order_by(Incidencia.fecha_apertura.desc()).all()
    excel = exportar_incidencias_excel(items)
    nombre = f"incidencias_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(content=excel,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename={nombre}"})


@app.get("/informes/reparaciones/excel")
def informe_reparaciones_excel(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    items = db.query(Reparacion).order_by(Reparacion.fecha_entrada.desc()).all()
    excel = exportar_reparaciones_excel(items)
    nombre = f"reparaciones_mrd_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(content=excel,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename={nombre}"})


@app.get("/api/v1/informes/analisis")
def api_analisis_inteligente(user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    return generar_analisis_inteligente(db)


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 4.8 — DETECCIÓN DE ANOMALÍAS
# ═══════════════════════════════════════════════════════════════════════════════
@app.get("/anomalias", response_class=HTMLResponse)
def anomalias_panel(request: Request, db: Session = Depends(get_db),
                    user: Usuario = Depends(requiere_login),
                    sev: str = ""):
    resultado = anom_engine.ejecutar_deteccion_completa(db)
    lista = resultado["anomalias"]
    if sev:
        lista = [a for a in lista if a["severidad"] == sev]
    return templates.TemplateResponse(request, "anomalias.html", ctx_base(
        request, user, db,
        resultado=resultado,
        lista=lista,
        filtro_sev=sev,
    ))


@app.post("/anomalias/crear-avisos")
def anomalias_crear_avisos(request: Request, db: Session = Depends(get_db),
                            user: Usuario = Depends(requiere_login)):
    resultado = anom_engine.ejecutar_deteccion_completa(db)
    creados = anom_engine.crear_avisos_desde_anomalias(resultado, db)
    from fastapi.responses import RedirectResponse
    return RedirectResponse(f"/anomalias?ok={creados}+avisos+creados", status_code=303)


@app.get("/api/v1/anomalias")
def api_anomalias(sev: str = "", db: Session = Depends(get_db),
                  user: Usuario = Depends(requiere_login)):
    resultado = anom_engine.ejecutar_deteccion_completa(db)
    if sev:
        resultado["anomalias"] = [a for a in resultado["anomalias"] if a["severidad"] == sev]
    return resultado


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 4.9 — MANTENIMIENTO PREDICTIVO
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/mantenimiento", response_class=HTMLResponse)
def mantenimiento_panel(request: Request, db: Session = Depends(get_db),
                        user: Usuario = Depends(requiere_login),
                        nivel: str = ""):
    plan = mant_engine.generar_plan_mantenimiento(db)
    scores = plan["scores"]
    if nivel:
        scores = [s for s in scores if s["nivel"] == nivel]
    return templates.TemplateResponse(request, "mantenimiento.html", ctx_base(
        request, user, db,
        plan=plan,
        scores=scores,
        filtro_nivel=nivel,
        tipos_mantenimiento=TIPOS_MANTENIMIENTO,
        herramientas=db.query(Herramienta).filter(Herramienta.activa == True).order_by(Herramienta.nombre).all(),
        maquinas=db.query(Maquinaria).filter(Maquinaria.activa == True).order_by(Maquinaria.nombre).all(),
        now=datetime.now(),
    ))


@app.post("/mantenimiento/programar")
async def mantenimiento_programar(
    request: Request, db: Session = Depends(get_db),
    user: Usuario = Depends(requiere_login),
    tipo_activo: str = Form(...),
    activo_id: int = Form(...),
    tipo: str = Form("preventivo"),
    descripcion: str = Form(""),
    fecha_programada: str = Form(...),
    intervalo_dias: str = Form(""),
    coste_estimado: str = Form(""),
    proveedor_texto: str = Form(""),
    notas: str = Form(""),
):
    # Obtener nombre y código del activo
    nombre_activo, codigo_activo = "", ""
    if tipo_activo == "herramienta":
        h = db.query(Herramienta).filter(Herramienta.id == activo_id).first()
        if h:
            nombre_activo = h.nombre
            codigo_activo = getattr(h, "codigo", "") or ""
    else:
        m = db.query(Maquinaria).filter(Maquinaria.id == activo_id).first()
        if m:
            nombre_activo = m.nombre
            codigo_activo = getattr(m, "codigo", "") or ""

    try:
        fecha_dt = datetime.strptime(fecha_programada, "%Y-%m-%d")
    except Exception:
        fecha_dt = datetime.now()

    mant_engine.crear_mantenimiento(
        db=db,
        tipo_activo=tipo_activo,
        activo_id=activo_id,
        nombre_activo=nombre_activo,
        codigo_activo=codigo_activo,
        tipo=tipo,
        descripcion=descripcion,
        fecha_programada=fecha_dt,
        intervalo_dias=int(intervalo_dias) if intervalo_dias.isdigit() else None,
        coste_estimado=float(coste_estimado) if coste_estimado else None,
        proveedor=proveedor_texto,
        notas=notas,
        creado_por_id=user.id,
    )
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/mantenimiento?ok=Mantenimiento+programado", status_code=303)


@app.post("/mantenimiento/{mp_id}/completar")
async def mantenimiento_completar(
    mp_id: int, request: Request, db: Session = Depends(get_db),
    user: Usuario = Depends(requiere_login),
    fecha_realizada: str = Form(""),
    coste_real: str = Form(""),
    notas_cierre: str = Form(""),
):
    try:
        fecha_dt = datetime.strptime(fecha_realizada, "%Y-%m-%d") if fecha_realizada else datetime.now()
    except Exception:
        fecha_dt = datetime.now()
    mant_engine.completar_mantenimiento(
        mp_id=mp_id, db=db, fecha_realizada=fecha_dt,
        coste_real=float(coste_real) if coste_real else None,
        notas=notas_cierre,
    )
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/mantenimiento?ok=Mantenimiento+completado", status_code=303)


@app.post("/mantenimiento/{mp_id}/cancelar")
def mantenimiento_cancelar(mp_id: int, db: Session = Depends(get_db),
                            user: Usuario = Depends(requiere_login)):
    mp = db.query(MantenimientoProgramado).filter(MantenimientoProgramado.id == mp_id).first()
    if mp:
        mp.estado = "cancelado"
        db.commit()
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/mantenimiento", status_code=303)


@app.get("/api/v1/mantenimiento/plan")
def api_plan_mantenimiento(db: Session = Depends(get_db),
                            user: Usuario = Depends(requiere_login)):
    plan = mant_engine.generar_plan_mantenimiento(db)
    # Serializar fechas
    for s in plan["scores"]:
        if s.get("fecha_predicha"):
            s["fecha_predicha"] = s["fecha_predicha"].strftime("%Y-%m-%d")
        if s.get("ultimo_mantenimiento") and hasattr(s["ultimo_mantenimiento"], "strftime"):
            s["ultimo_mantenimiento"] = s["ultimo_mantenimiento"].strftime("%Y-%m-%d")
    return plan


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 4.12 — PANEL DE CONTROL DE IA Y AUTOMATIZACIONES
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/panel-ia", response_class=HTMLResponse)
def panel_ia(request: Request, db: Session = Depends(get_db),
             user: Usuario = Depends(requiere_login)):

    # ── Estado del scheduler ──────────────────────────────────────
    scheduler_activo = (
        auto_engine._scheduler_thread is not None and
        auto_engine._scheduler_thread.is_alive()
    )

    # ── KPIs globales ─────────────────────────────────────────────
    avisos_sin_leer  = db.query(Aviso).filter(Aviso.leido == False, Aviso.archivado == False).count()
    avisos_criticos  = db.query(Aviso).filter(Aviso.prioridad == "critica", Aviso.archivado == False).count()
    total_avisos     = db.query(Aviso).filter(Aviso.archivado == False).count()

    autos_activas    = db.query(Automatizacion).filter(Automatizacion.estado == "activa").count()
    autos_total      = db.query(Automatizacion).count()
    total_ejecuciones= db.query(EjecucionAutomatizacion).count()

    canales_activos  = db.query(CanalNotificacion).filter(CanalNotificacion.activo == True).count()
    notif_ok         = db.query(NotificacionEnviada).filter(NotificacionEnviada.resultado == "ok").count()
    notif_error      = db.query(NotificacionEnviada).filter(NotificacionEnviada.resultado == "error").count()

    mant_vencidos    = db.query(MantenimientoProgramado).filter(MantenimientoProgramado.estado == "vencido").count()
    mant_proximos    = db.query(MantenimientoProgramado).filter(
        MantenimientoProgramado.estado == "pendiente",
        MantenimientoProgramado.fecha_programada >= datetime.now(),
    ).count()

    # ── Anomalías (rápido — solo conteo) ─────────────────────────
    try:
        res_anom = anom_engine.ejecutar_deteccion_completa(db)
        anom_criticas = res_anom["resumen"]["critica"]
        anom_altas    = res_anom["resumen"]["alta"]
        anom_total    = res_anom["resumen"]["total"]
    except Exception:
        anom_criticas = anom_altas = anom_total = 0

    # ── Timeline de actividad reciente ────────────────────────────
    # Mezcla: últimas ejecuciones + últimos avisos + últimos mantenimientos
    timeline = []

    ult_ejecuciones = db.query(EjecucionAutomatizacion).order_by(
        EjecucionAutomatizacion.fecha.desc()).limit(5).all()
    for e in ult_ejecuciones:
        auto = db.query(Automatizacion).filter(Automatizacion.id == e.automatizacion_id).first()
        timeline.append({
            "tipo": "ejecucion",
            "icono": "bi-lightning",
            "color": "#0d6efd" if e.resultado == "ok" else "#dc3545",
            "texto": f"Auto «{auto.nombre if auto else '#'+str(e.automatizacion_id)}» — {e.acciones_ejecutadas} acción(es)",
            "fecha": e.fecha,
            "enlace": f"/automatizaciones/{e.automatizacion_id}",
        })

    ult_avisos = db.query(Aviso).order_by(Aviso.creado_en.desc()).limit(5).all()
    for a in ult_avisos:
        color_p = {"critica": "#dc3545", "alta": "#fd7e14", "media": "#0d6efd", "baja": "#6c757d"}.get(a.prioridad, "#6c757d")
        timeline.append({
            "tipo": "aviso",
            "icono": "bi-bell",
            "color": color_p,
            "texto": a.titulo,
            "fecha": a.creado_en,
            "enlace": "/avisos",
        })

    ult_notif = db.query(NotificacionEnviada).order_by(
        NotificacionEnviada.fecha_envio.desc()).limit(3).all()
    for n in ult_notif:
        timeline.append({
            "tipo": "notificacion",
            "icono": "bi-send",
            "color": "#198754" if n.resultado == "ok" else "#dc3545",
            "texto": f"Notif. {'enviada' if n.resultado=='ok' else 'fallida'}: {n.aviso_titulo or '—'}",
            "fecha": n.fecha_envio,
            "enlace": "/notificaciones",
        })

    ult_mant = db.query(MantenimientoProgramado).filter(
        MantenimientoProgramado.estado == "completado"
    ).order_by(MantenimientoProgramado.fecha_realizada.desc()).limit(3).all()
    for m in ult_mant:
        timeline.append({
            "tipo": "mantenimiento",
            "icono": "bi-tools",
            "color": "#198754",
            "texto": f"Mant. completado: {m.nombre_activo}",
            "fecha": m.fecha_realizada,
            "enlace": "/mantenimiento",
        })

    # Ordenar timeline por fecha
    timeline.sort(key=lambda x: x["fecha"] or datetime.min, reverse=True)
    timeline = timeline[:15]

    # ── Datos para mini gráfica de ejecuciones (7 días) ──────────
    ejecuciones_semana = []
    for i in range(6, -1, -1):
        dia = datetime.now() - timedelta(days=i)
        cnt = db.query(EjecucionAutomatizacion).filter(
            func.strftime("%Y-%m-%d", EjecucionAutomatizacion.fecha) == dia.strftime("%Y-%m-%d")
        ).count()
        ejecuciones_semana.append({"dia": dia.strftime("%a"), "total": cnt})

    chart_ej = json.dumps({
        "labels": [e["dia"] for e in ejecuciones_semana],
        "data":   [e["total"] for e in ejecuciones_semana],
    })

    return templates.TemplateResponse(request, "panel_ia.html", ctx_base(
        request, user, db,
        scheduler_activo=scheduler_activo,
        kpis={
            "avisos_sin_leer": avisos_sin_leer,
            "avisos_criticos": avisos_criticos,
            "total_avisos": total_avisos,
            "autos_activas": autos_activas,
            "autos_total": autos_total,
            "total_ejecuciones": total_ejecuciones,
            "canales_activos": canales_activos,
            "notif_ok": notif_ok,
            "notif_error": notif_error,
            "mant_vencidos": mant_vencidos,
            "mant_proximos": mant_proximos,
            "anom_criticas": anom_criticas,
            "anom_altas": anom_altas,
            "anom_total": anom_total,
        },
        timeline=timeline,
        chart_ej_json=chart_ej,
        now=datetime.now(),
    ))


@app.get("/api/v1/panel-ia/estado")
def api_panel_ia_estado(db: Session = Depends(get_db),
                         user: Usuario = Depends(requiere_login)):
    scheduler_activo = (
        auto_engine._scheduler_thread is not None and
        auto_engine._scheduler_thread.is_alive()
    )
    avisos_sin_leer = db.query(Aviso).filter(Aviso.leido == False, Aviso.archivado == False).count()
    autos_activas   = db.query(Automatizacion).filter(Automatizacion.estado == "activa").count()
    return {
        "scheduler_activo": scheduler_activo,
        "avisos_sin_leer": avisos_sin_leer,
        "autos_activas": autos_activas,
        "timestamp": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.3 — SERVICIOS DE PRODUCCIÓN
# API del servicio Windows y panel de administración
# Solo administradores. Todas las acciones se registran en log de auditoría.
# ═══════════════════════════════════════════════════════════════════════════════

import json as _json_mod
import subprocess as _subprocess
from pathlib import Path as _Path
import cloudflare_tunnel as _cf_tunnel

_SVC_BASE = _Path(__file__).parent
_SVC_STATUS_FILE = _SVC_BASE / ".service_status"
_SVC_RESTART_FLAG = _SVC_BASE / ".service_restart"
_SERVICE_NAME = "MRDToolControl"


def _svc_requiere_admin(user: Usuario):
    """Lanza 403 si el usuario no es administrador."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(status_code=403, detail="Solo administradores pueden gestionar el servicio.")


def _svc_log_audit(user: Usuario, action: str, detail: str = ""):
    """Registra acción de servicio en el log de seguridad."""
    try:
        mrd_logging.log_security(f"SERVICE_ACTION action={action} user={user.username} detail={detail}")
    except Exception:
        pass


def _svc_read_status() -> dict:
    """Lee el archivo .service_status escrito por windows_service.py."""
    try:
        if _SVC_STATUS_FILE.exists():
            return _json_mod.loads(_SVC_STATUS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _svc_get_metrics() -> dict:
    """Devuelve métricas del sistema usando service_health.py."""
    try:
        from service_health import get_system_metrics
        return get_system_metrics()
    except Exception:
        return {}


def _svc_windows_state() -> str:
    """Consulta estado del servicio Windows via sc.exe. Devuelve RUNNING/STOPPED/etc."""
    try:
        result = _subprocess.run(
            ["sc.exe", "query", _SERVICE_NAME],
            capture_output=True, text=True, timeout=5
        )
        if "RUNNING" in result.stdout:
            return "RUNNING"
        elif "STOPPED" in result.stdout:
            return "STOPPED"
        elif "PENDING" in result.stdout:
            return "PENDING"
        return "NOT_INSTALLED"
    except FileNotFoundError:
        return "NOT_WINDOWS"
    except Exception:
        return "UNKNOWN"


# ─── Reinicio del servidor ────────────────────────────────────────────────────
@app.post("/admin/reiniciar")
def reiniciar_servidor(
    request: Request,
    user: Usuario = Depends(requiere_login),
):
    if user.rol != "admin":
        raise HTTPException(403, "Solo administradores pueden reiniciar el servidor")
    import threading, time, os, sys as _sys
    mrd_logging.log_app(f"Reinicio del servidor solicitado por {user.username}", level="warning")
    def _do_restart():
        time.sleep(1.2)
        os.execv(_sys.executable, [_sys.executable] + _sys.argv)
    threading.Thread(target=_do_restart, daemon=True).start()
    return JSONResponse({"ok": True, "msg": "Reiniciando en 1 segundo..."})


# ─── GET /servicio (Panel admin) ──────────────────────────────────────────────
@app.get("/servicio")
def servicio_panel(request: Request, user: Usuario = Depends(requiere_login)):
    _svc_requiere_admin(user)
    return templates.TemplateResponse(request, "servicio.html", ctx_base(request, user, "servicio"))


# ─── GET /api/service/status ──────────────────────────────────────────────────
@app.get("/api/service/status")
def api_service_status(
    user: Usuario = Depends(requiere_login),
    _db: Session = Depends(get_db),
):
    _svc_requiere_admin(user)
    file_status = _svc_read_status()
    win_state   = _svc_windows_state()
    metrics     = _svc_get_metrics()

    # Determinar estado general
    if file_status.get("status") == "running":
        status = "running"
    elif win_state == "RUNNING":
        status = "running"
    elif win_state == "STOPPED":
        status = "stopped"
    else:
        status = "unknown"

    return {
        "status":        status,
        "windows_state": win_state,
        "pid":           file_status.get("pid"),
        "uptime_seconds": file_status.get("uptime_seconds"),
        "start_time":    file_status.get("start_time"),
        "port":          file_status.get("port", 8000),
        "host":          file_status.get("host", "0.0.0.0"),
        "workers":       file_status.get("workers", 1),
        "restart_count": file_status.get("restart_count", 0),
        "version":       file_status.get("version", "1.9.3-alpha"),
        "metrics":       metrics,
        "timestamp":     file_status.get("timestamp"),
    }


# ─── GET /api/service/health ──────────────────────────────────────────────────
@app.get("/api/service/health")
def api_service_health(
    user: Usuario = Depends(requiere_login),
    _db: Session = Depends(get_db),
):
    _svc_requiere_admin(user)
    try:
        from service_health import run_all_checks
        return run_all_checks(port=8000)
    except Exception as exc:
        return {"healthy": False, "error": str(exc), "checks": {}}


# ─── GET /api/service/logs/{nombre} ──────────────────────────────────────────
@app.get("/api/service/logs/{log_name}")
def api_service_logs(
    log_name: str,
    lines: int = 50,
    user: Usuario = Depends(requiere_login),
):
    _svc_requiere_admin(user)
    # Solo logs del servicio — no permitir path traversal
    allowed = {"service", "startup", "shutdown", "crash", "rotation", "uvicorn"}
    if log_name not in allowed:
        raise HTTPException(400, f"Log '{log_name}' no permitido.")
    log_path = _SVC_BASE / "logs" / f"{log_name}.log"
    if not log_path.exists():
        return {"content": f"(log {log_name}.log vacío o no existe)", "lines": 0}
    try:
        # Leer las últimas N líneas
        all_lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = all_lines[-min(lines, len(all_lines)):]
        return {"content": "\n".join(tail), "lines": len(tail), "log": log_name}
    except Exception as exc:
        raise HTTPException(500, f"Error leyendo log: {exc}")


# ─── POST /api/service/restart ────────────────────────────────────────────────
@app.post("/api/service/restart")
def api_service_restart(
    user: Usuario = Depends(requiere_login),
    _db: Session = Depends(get_db),
):
    """
    Reinicio suave: crea un archivo de señal que el watchdog detecta
    y reinicia el proceso uvicorn sin detener el servicio Windows.
    """
    _svc_requiere_admin(user)
    _svc_log_audit(user, "restart", "reinicio suave de uvicorn solicitado")
    try:
        _SVC_RESTART_FLAG.write_text(
            f"restart_requested_by={user.username}_at={datetime.now().isoformat()}",
            encoding="utf-8"
        )
        return {"ok": True, "message": "Señal de reinicio enviada. Uvicorn se reiniciará en unos segundos."}
    except Exception as exc:
        raise HTTPException(500, f"No se pudo enviar señal de reinicio: {exc}")


# ─── POST /api/service/stop ───────────────────────────────────────────────────
@app.post("/api/service/stop")
def api_service_stop(
    user: Usuario = Depends(requiere_login),
    _db: Session = Depends(get_db),
):
    """Detiene el servicio Windows MRDToolControl via sc.exe."""
    _svc_requiere_admin(user)
    _svc_log_audit(user, "stop", "detención del servicio Windows")
    win_state = _svc_windows_state()
    if win_state == "NOT_INSTALLED":
        raise HTTPException(409, "Servicio no instalado. Instala con install_service.ps1.")
    if win_state == "STOPPED":
        return {"ok": True, "message": "El servicio ya estaba detenido."}
    try:
        _subprocess.run(
            ["sc.exe", "stop", _SERVICE_NAME],
            capture_output=True, timeout=10, check=False
        )
        return {"ok": True, "message": "Señal de parada enviada al servicio."}
    except Exception as exc:
        raise HTTPException(500, f"Error al detener el servicio: {exc}")


# ─── POST /api/service/start ──────────────────────────────────────────────────
@app.post("/api/service/start")
def api_service_start(
    user: Usuario = Depends(requiere_login),
    _db: Session = Depends(get_db),
):
    """Inicia el servicio Windows MRDToolControl via sc.exe."""
    _svc_requiere_admin(user)
    _svc_log_audit(user, "start", "inicio del servicio Windows")
    win_state = _svc_windows_state()
    if win_state == "NOT_INSTALLED":
        raise HTTPException(409, "Servicio no instalado. Instala con install_service.ps1.")
    if win_state == "RUNNING":
        return {"ok": True, "message": "El servicio ya estaba en ejecución."}
    try:
        _subprocess.run(
            ["sc.exe", "start", _SERVICE_NAME],
            capture_output=True, timeout=10, check=False
        )
        return {"ok": True, "message": "Señal de inicio enviada al servicio."}
    except Exception as exc:
        raise HTTPException(500, f"Error al iniciar el servicio: {exc}")

# ─── FIN SPRINT 5.3 ───────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.4 — CLOUDFLARE NAMED TUNNEL
# ═══════════════════════════════════════════════════════════════════════════════

def _cf_requiere_admin(user):
    """Verifica que el usuario es administrador. Lanza 403 si no."""
    if not tiene_permiso(user, "config"):
        raise HTTPException(status_code=403, detail="Solo administradores pueden gestionar Cloudflare.")

def _cf_log_audit(user, action: str, detail: str = ""):
    mrd_logging.log_security(f"CF_ACTION user={user.username} action={action} detail={detail[:200]}")


@app.get("/cloudflare", response_class=HTMLResponse)
def cloudflare_panel(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    """Panel de configuración de Cloudflare Named Tunnel. Solo admin."""
    _cf_requiere_admin(user)
    cfg = remote_access.load_config()
    return templates.TemplateResponse(request, "cloudflare.html",
        ctx_base(request, user, db, config=cfg))


@app.get("/api/cloudflare/status")
def api_cf_status(user: Usuario = Depends(requiere_login)):
    """Estado completo del Cloudflare Named Tunnel. Solo admin."""
    _cf_requiere_admin(user)
    cfg = remote_access.load_config()
    status = _cf_tunnel.get_tunnel_status(cfg)
    # Añadir info del proveedor Cloudflare desde remote_access
    ra_status = remote_access.get_status_cached(max_age=30)
    cf_provider = next((p for p in ra_status.get("providers", [])
                        if p.get("name") == "cloudflare"), None)
    status["provider_info"] = cf_provider
    status["public_url_active"] = ra_status.get("public_url")
    return status


@app.get("/api/cloudflare/info")
def api_cf_info(user: Usuario = Depends(requiere_login)):
    """Información de configuración del túnel (sin credenciales). Solo admin."""
    _cf_requiere_admin(user)
    cfg = remote_access.load_config()
    cf_config_file = cfg.get("cf_config_file", "")
    tunnel_cfg = _cf_tunnel.read_tunnel_config(cf_config_file) if cf_config_file else {}
    version = _cf_tunnel.get_cloudflared_version(cfg.get("cloudflared_exe", "cloudflared.exe"))
    metrics = _cf_tunnel.get_metrics()
    return {
        "cloudflared_version": version,
        "tunnel_name":         cfg.get("cf_tunnel_name") or tunnel_cfg.get("tunnel"),
        "tunnel_id":           metrics.get("tunnel_id") or cfg.get("cf_tunnel_id"),
        "hostname":            cfg.get("cf_hostname"),
        "domain":              cfg.get("cf_domain"),
        "subdomain":           cfg.get("cf_subdomain"),
        "public_url":          cfg.get("cf_public_url"),
        "internal_port":       cfg.get("cf_internal_port", 8000),
        "force_https":         cfg.get("cf_force_https", True),
        "config_file_exists":  bool(cf_config_file and _Path(cf_config_file).exists()),
        "credentials_ok":      tunnel_cfg.get("credentials_file_exists", False),
        "ingress_count":       tunnel_cfg.get("ingress_count", 0),
        "metrics_available":   metrics["available"],
        # NO se incluye: credentials_file path, API tokens, cert.pem
    }


@app.post("/api/cloudflare/test")
def api_cf_test(user: Usuario = Depends(requiere_login)):
    """Ejecuta diagnóstico completo del tunnel. Solo admin."""
    _cf_requiere_admin(user)
    _cf_log_audit(user, "test")
    cfg = remote_access.load_config()
    port = int(cfg.get("port", 8000))
    checks = _cf_tunnel.run_diagnostics(cfg, port)
    all_ok = all(c["ok"] for c in checks)
    return {
        "healthy": all_ok,
        "checks":  checks,
        "checked_at": datetime.now().isoformat(),
    }


@app.post("/api/cloudflare/restart")
def api_cf_restart(user: Usuario = Depends(requiere_login)):
    """Reinicia el servicio cloudflared. Solo admin."""
    _cf_requiere_admin(user)
    _cf_log_audit(user, "restart")
    cfg = remote_access.load_config()
    svc_name = cfg.get("cloudflared_service", "cloudflared")
    result = _cf_tunnel.restart_service(svc_name)
    remote_access.invalidate_cache()
    return result



@app.get("/api/cloudflare/logs")
def api_cf_logs(lines: int = 50, user: Usuario = Depends(requiere_login)):
    """Lee los ultimos logs de cloudflared del Event Log de Windows. Solo admin."""
    _cf_requiere_admin(user)
    if lines < 1:
        lines = 1
    if lines > 500:
        lines = 500
    import subprocess as _sp
    import platform
    result_lines = []
    if platform.system() == "Windows":
        try:
            ps_cmd = (
                f"Get-EventLog -LogName Application -Source cloudflared -Newest {lines} "
                "-ErrorAction SilentlyContinue | "
                "Select-Object TimeGenerated,EntryType,Message | "
                "ForEach-Object { $_.TimeGenerated.ToString('yyyy-MM-dd HH:mm:ss') + ' [' + $_.EntryType + '] ' + ($_.Message -replace '\r?\n',' ') }"
            )
            r = _sp.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=10,
            )
            if r.stdout.strip():
                result_lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
        except Exception as e:
            result_lines = [f"Error leyendo Event Log: {str(e)[:100]}"]
    # Fallback: buscar cloudflared log en rutas conocidas
    if not result_lines:
        log_candidates = [
            Path("logs") / "cloudflared.log",
            Path("C:/Program Files/cloudflared/cloudflared.log"),
            Path("C:/ProgramData/cloudflared/cloudflared.log"),
        ]
        for lp in log_candidates:
            try:
                if lp.exists():
                    all_l = lp.read_text(encoding="utf-8", errors="replace").splitlines()
                    result_lines = all_l[-min(lines, len(all_l)):]
                    break
            except Exception:
                pass
    if not result_lines:
        result_lines = [
            "cloudflared no ha escrito logs accesibles desde esta API.",
            "Para ver logs: ejecuta scripts\\cloudflare_logs.ps1 como Administrador.",
        ]
    return {"lines": result_lines, "count": len(result_lines)}


@app.post("/api/cloudflare/config")
async def api_cf_save_config(request: Request, user: Usuario = Depends(requiere_login)):
    """Guarda la configuración de Cloudflare. Solo admin."""
    _cf_requiere_admin(user)
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="JSON inválido")

    allowed = {
        "cf_tunnel_name", "cf_hostname", "cf_domain", "cf_subdomain",
        "cf_public_url", "cf_config_file", "cf_force_https",
        "cf_internal_port", "cloudflared_service", "cloudflared_exe",
        "manual_url", "preferred_provider",
    }
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail="Sin parámetros válidos")

    # Si se actualiza cf_public_url también actualizar manual_url
    if "cf_public_url" in updates and updates["cf_public_url"]:
        updates.setdefault("manual_url", updates["cf_public_url"])

    ok = remote_access.save_config(updates)
    if not ok:
        raise HTTPException(status_code=500, detail="Error guardando configuración")

    remote_access.invalidate_cache()
    _cf_log_audit(user, "config_saved", str(list(updates.keys())))
    return {"ok": True, "message": "Configuración guardada.", "keys": list(updates.keys())}


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.5 — BASE DE DATOS
# ═══════════════════════════════════════════════════════════════════════════════
import db_tools as _db_tools
from database import get_db_info as _db_get_info, check_connection as _db_check_conn


def _db_requiere_admin(user: Usuario):
    if getattr(user, "rol", None) not in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="Sólo administradores pueden gestionar la base de datos.")


def _db_audit(user: Usuario, action: str, detail: str = ""):
    try:
        from models import LogSeguridad
        db = next(get_db())
        db.add(LogSeguridad(
            usuario_id=user.id, username=user.username,
            accion=f"DB:{action}", detalle=detail,
            ip="interno", riesgo="info",
        ))
        db.commit()
        db.close()
    except Exception:
        pass


@app.get("/database")
def page_database(request: Request, user: Usuario = Depends(requiere_login)):
    """Panel de administración de base de datos. Solo admin."""
    _db_requiere_admin(user)
    return templates.TemplateResponse(request, "database.html", ctx_base(request, user, title="Base de Datos"))


@app.get("/api/database/status")
def api_db_status(user: Usuario = Depends(requiere_login)):
    """Estado completo de la base de datos."""
    _db_requiere_admin(user)
    info = _db_get_info()
    conn = _db_check_conn()
    current = _db_tools.get_alembic_current()
    return {
        "engine":         info.get("engine"),
        "url_safe":       info.get("url_safe"),
        "connected":      conn.get("ok"),
        "latency_ms":     conn.get("ms"),
        "connection_error": conn.get("error"),
        "pool":           info.get("pool", {}),
        "stats":          info.get("stats", {}),
        "slow_queries":   info.get("slow_queries", []),
        "slow_query_ms":  info.get("slow_query_ms", 200),
        "alembic_current": current.get("output", ""),
        "checked_at":     datetime.now().isoformat(),
    }


@app.post("/api/database/migrate")
def api_db_migrate(user: Usuario = Depends(requiere_login)):
    """Ejecuta alembic upgrade head. Solo admin."""
    _db_requiere_admin(user)
    _db_audit(user, "upgrade", "alembic upgrade head")
    result = _db_tools.run_alembic_upgrade("head")
    return result


@app.post("/api/database/rollback")
async def api_db_rollback(request: Request, user: Usuario = Depends(requiere_login)):
    """Revierte N migraciones. Solo admin."""
    _db_requiere_admin(user)
    try:
        body = await request.json()
        steps = int(body.get("steps", 1))
        steps = max(1, min(steps, 10))
    except Exception:
        steps = 1
    _db_audit(user, "downgrade", f"steps={steps}")
    result = _db_tools.run_alembic_downgrade(steps)
    return result


@app.post("/api/database/check")
def api_db_check(user: Usuario = Depends(requiere_login)):
    """Verificación de integridad completa. Solo admin."""
    _db_requiere_admin(user)
    _db_audit(user, "integrity_check")
    result = _db_tools.verify_integrity()
    return result


@app.get("/api/database/history")
def api_db_history(user: Usuario = Depends(requiere_login)):
    """Historial de migraciones Alembic. Solo admin."""
    _db_requiere_admin(user)
    return _db_tools.get_alembic_history()


@app.post("/api/database/reset-stats")
def api_db_reset_stats(user: Usuario = Depends(requiere_login)):
    """Reinicia contadores de rendimiento. Solo admin."""
    _db_requiere_admin(user)
    from database import reset_stats as _reset_stats
    _reset_stats()
    _db_audit(user, "reset_stats")
    return {"ok": True, "message": "Contadores reiniciados."}


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.6 — BACKUPS Y RECUPERACIÓN
# ═══════════════════════════════════════════════════════════════════════════════
import backup_manager as _bk


def _bk_requiere_admin(user: Usuario):
    if getattr(user, "rol", None) not in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="Sólo administradores pueden gestionar backups.")


def _bk_audit(user: Usuario, action: str, detail: str = ""):
    try:
        from models import LogSeguridad
        db = next(get_db())
        db.add(LogSeguridad(
            usuario_id=user.id, username=user.username,
            accion=f"BACKUP:{action}", detalle=detail,
            ip="interno", riesgo="info",
        ))
        db.commit()
        db.close()
    except Exception:
        pass


@app.get("/backup")
def page_backup(request: Request, user: Usuario = Depends(requiere_login)):
    """Panel de gestión de backups. Solo admin."""
    _bk_requiere_admin(user)
    return templates.TemplateResponse(request, "backup.html", ctx_base(request, user, title="Backups"))


@app.get("/api/backup/status")
def api_bk_status(user: Usuario = Depends(requiere_login)):
    """Estado general del sistema de backups."""
    _bk_requiere_admin(user)
    return _bk.get_backup_status()


@app.get("/api/backup/history")
def api_bk_history(
    limit: int = 50,
    user: Usuario = Depends(requiere_login),
):
    """Historial de backups (más recientes primero)."""
    _bk_requiere_admin(user)
    limit = max(1, min(limit, 200))
    return {"history": _bk.get_history(limit), "limit": limit}


@app.post("/api/backup/create")
async def api_bk_create(request: Request, user: Usuario = Depends(requiere_login)):
    """Crea un backup manual."""
    _bk_requiere_admin(user)
    try:
        body  = await request.json()
        label = str(body.get("label", ""))[:30]
    except Exception:
        label = ""
    result = _bk.create_backup(tipo="manual", label=label or user.username)
    _bk_audit(user, "create_manual", label)
    return result


@app.post("/api/backup/verify")
async def api_bk_verify(request: Request, user: Usuario = Depends(requiere_login)):
    """Verifica la integridad de un backup."""
    _bk_requiere_admin(user)
    try:
        body = await request.json()
        filename = str(body.get("filename", ""))
    except Exception:
        raise HTTPException(status_code=400, detail="filename requerido")

    if not filename or ".." in filename or "/" in filename:
        raise HTTPException(status_code=400, detail="Nombre de fichero inválido")

    # Buscar en todos los subdirectorios de backup
    import backup_manager as _bm2
    found = None
    for f in _bm2.BACKUPS_DIR.rglob(filename):
        found = f
        break
    if not found:
        raise HTTPException(status_code=404, detail="Backup no encontrado")

    result = _bk.verify_backup(str(found))
    _bk_audit(user, "verify", filename)
    return result


@app.post("/api/backup/restore")
async def api_bk_restore(request: Request, user: Usuario = Depends(requiere_login)):
    """Restaura un backup. dry_run=true solo verifica."""
    _bk_requiere_admin(user)
    try:
        body     = await request.json()
        filename = str(body.get("filename", ""))
        dry_run  = bool(body.get("dry_run", True))
    except Exception:
        raise HTTPException(status_code=400, detail="JSON inválido")

    if not filename or ".." in filename or "/" in filename:
        raise HTTPException(status_code=400, detail="Nombre de fichero inválido")

    import backup_manager as _bm2
    found = None
    for f in _bm2.BACKUPS_DIR.rglob(filename):
        found = f
        break
    if not found:
        raise HTTPException(status_code=404, detail="Backup no encontrado")

    result = _bk.restore_backup(str(found), dry_run=dry_run)
    _bk_audit(user, "restore" + ("_dry" if dry_run else ""), filename)
    return result


@app.post("/api/backup/cleanup")
def api_bk_cleanup(user: Usuario = Depends(requiere_login)):
    """Limpieza de backups antiguos según política de retención."""
    _bk_requiere_admin(user)
    result = _bk.cleanup_old_backups()
    _bk_audit(user, "cleanup", str(result))
    return result


@app.get("/api/backup/download/{filename:path}")
def api_bk_download(filename: str, user: Usuario = Depends(requiere_login)):
    """Descarga segura de un backup."""
    from fastapi.responses import FileResponse
    _bk_requiere_admin(user)
    # Sanitizar: solo nombre de fichero, no rutas
    safe_name = Path(filename).name
    if ".." in safe_name or not safe_name:
        raise HTTPException(status_code=400, detail="Nombre inválido")

    import backup_manager as _bm2
    found = None
    for f in _bm2.BACKUPS_DIR.rglob(safe_name):
        found = f
        break
    if not found:
        raise HTTPException(status_code=404, detail="Backup no encontrado")

    _bk_audit(user, "download", safe_name)
    return FileResponse(
        path=str(found),
        filename=safe_name,
        media_type="application/octet-stream",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.7 — ACTUALIZACIONES PROFESIONALES
# ═══════════════════════════════════════════════════════════════════════════════
import updater as _updater


def _upd_requiere_admin(user: Usuario):
    if getattr(user, "rol", None) not in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="Sólo administradores pueden gestionar actualizaciones.")


def _upd_audit(user: Usuario, action: str, detail: str = ""):
    try:
        from models import LogSeguridad
        db = next(get_db())
        db.add(LogSeguridad(
            usuario_id=user.id, username=user.username,
            accion=f"UPDATE:{action}", detalle=detail,
            ip="interno", riesgo="info",
        ))
        db.commit()
        db.close()
    except Exception:
        pass


@app.get("/actualizaciones")
def page_actualizaciones(request: Request, user: Usuario = Depends(requiere_login)):
    """Panel de actualizaciones. Solo admin."""
    _upd_requiere_admin(user)
    return templates.TemplateResponse(request, "actualizaciones.html", ctx_base(request, user, title="Actualizaciones"))


@app.get("/api/update/check")
def api_upd_check(user: Usuario = Depends(requiere_login)):
    """Comprueba si hay actualizaciones disponibles."""
    _upd_requiere_admin(user)
    result = _updater.check_update()
    return result


@app.get("/api/update/status")
def api_upd_status(user: Usuario = Depends(requiere_login)):
    """Estado actual del proceso de actualización."""
    _upd_requiere_admin(user)
    return _updater.get_state()


@app.post("/api/update/install")
async def api_upd_install(request: Request, user: Usuario = Depends(requiere_login)):
    """Inicia la descarga e instalación de una actualización."""
    _upd_requiere_admin(user)
    try:
        body = await request.json()
        download_url = str(body.get("download_url", "")).strip()
        sha256       = str(body.get("sha256",       "")).strip()
        version      = str(body.get("version",      "")).strip()
    except Exception:
        raise HTTPException(status_code=400, detail="JSON inválido")

    if not download_url:
        raise HTTPException(status_code=400, detail="download_url requerido")
    if not download_url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="URL no válida (solo http/https)")
    if not version:
        raise HTTPException(status_code=400, detail="version requerida")

    _upd_audit(user, "install", f"version={version}")
    result = _updater.start_update(download_url, sha256, version)
    return result


@app.post("/api/update/rollback")
def api_upd_rollback(user: Usuario = Depends(requiere_login)):
    """Rollback manual a la versión anterior."""
    _upd_requiere_admin(user)
    _upd_audit(user, "rollback")
    return _updater.rollback_update()


@app.post("/api/update/reset")
def api_upd_reset(user: Usuario = Depends(requiere_login)):
    """Reinicia el estado del updater."""
    _upd_requiere_admin(user)
    ok = _updater.reset_state()
    return {"ok": ok, "message": "Estado reiniciado." if ok else "Actualización en curso, no se puede reiniciar."}


# ══════════════════════════════════════════════════════════════════════════════
# SPRINT 5.8 — IASMRD CLOUDFLARE DEPLOYMENT (v1.9.8-alpha)
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/deployment/diagnostics")
def api_deployment_diagnostics(user: Usuario = Depends(requiere_login)):
    _cf_requiere_admin(user)
    """
    17 comprobaciones de despliegue de producción IASMRD.
    Solo accesible para administradores.
    """
    import urllib.request as _req
    import urllib.error as _uerr
    import socket as _sock
    import subprocess as _sp

    checks = []
    passed = 0

    def _chk(name: str, ok: bool, detail: str = ""):
        nonlocal passed
        if ok:
            passed += 1
        checks.append({"name": name, "ok": ok, "detail": detail})

    # 1. MRD_ENV = production
    env = os.getenv("MRD_ENV", "development")
    _chk("MRD_ENV=production", env == "production", env)

    # 2. MRD_SECRET_KEY definida y segura
    sk = os.getenv("MRD_SECRET_KEY", "")
    _chk("MRD_SECRET_KEY definida (>=32 chars)", len(sk) >= 32,
         f"{len(sk)} chars" if sk else "vacía")

    # 3. MRD_PUBLIC_URL configurada
    pub = MRD_PUBLIC_URL
    _chk("MRD_PUBLIC_URL configurada", bool(pub), pub or "vacía")

    # 4. MRD_PUBLIC_URL empieza por https://
    _chk("MRD_PUBLIC_URL usa HTTPS", pub.startswith("https://"), pub)

    # 5. MRD_HTTPS_ONLY=true
    _chk("MRD_HTTPS_ONLY=true", _MRD_HTTPS_ONLY, str(_MRD_HTTPS_ONLY))

    # 6. MRD_TRUST_PROXY_HEADERS=true
    _chk("MRD_TRUST_PROXY_HEADERS=true", MRD_TRUST_PROXY_HEADERS,
         str(MRD_TRUST_PROXY_HEADERS))

    # 7. MRD_ALLOWED_HOSTS contiene app.iasmrd.com
    hosts = MRD_ALLOWED_HOSTS
    _chk("MRD_ALLOWED_HOSTS configurado", bool(hosts), ",".join(hosts) if hosts else "vacío")

    # 8. MRD_SCAN_URL configurada
    scan = MRD_SCAN_URL
    _chk("MRD_SCAN_URL configurada", bool(scan), scan or "vacía")

    # 9. Servidor local responde en /health
    try:
        _r = _req.urlopen("http://127.0.0.1:8000/health", timeout=3)
        _chk("Servidor local responde /health", _r.status == 200, f"HTTP {_r.status}")
    except Exception as _e:
        _chk("Servidor local responde /health", False, str(_e))

    # 10. Servicio cloudflared instalado/en ejecución
    try:
        _out = _sp.run(
            ["sc", "query", "cloudflared"],
            capture_output=True, text=True, timeout=5,
        )
        _running = "RUNNING" in _out.stdout
        _chk("Servicio cloudflared en ejecución", _running,
             "RUNNING" if _running else _out.stdout.strip()[:80])
    except Exception as _e:
        _chk("Servicio cloudflared en ejecución", False, str(_e))

    # 11. cloudflared.exe en PATH
    try:
        _out = _sp.run(["cloudflared", "version"], capture_output=True, text=True, timeout=5)
        _ok = _out.returncode == 0
        _chk("cloudflared.exe en PATH", _ok,
             _out.stdout.strip()[:60] if _ok else _out.stderr.strip()[:60])
    except Exception as _e:
        _chk("cloudflared.exe en PATH", False, str(_e))

    # 12. URL pública accesible
    _pub_ok = False
    _pub_detail = "no configurada"
    if pub:
        try:
            _r = _req.urlopen(f"{pub}/health", timeout=10)
            _pub_ok = _r.status == 200
            _pub_detail = f"HTTP {_r.status}"
        except Exception as _e:
            _pub_detail = str(_e)[:80]
    _chk("URL pública accesible", _pub_ok, _pub_detail)

    # 13. Ruta /scan disponible
    _scan_ok = False
    _scan_detail = "no configurada"
    if pub:
        try:
            _r = _req.urlopen(f"{pub}/scan", timeout=10)
            _scan_ok = _r.status < 500
            _scan_detail = f"HTTP {_r.status}"
        except _uerr.HTTPError as _e:
            _scan_ok = _e.code < 500
            _scan_detail = f"HTTP {_e.code}"
        except Exception as _e:
            _scan_detail = str(_e)[:80]
    _chk("Ruta /scan disponible", _scan_ok, _scan_detail)

    # 14. Base de datos accesible
    try:
        from database import check_connection as _chkconn
        _db_ok, _db_msg = _chkconn()
        _chk("Base de datos accesible", _db_ok, _db_msg)
    except Exception as _e:
        _chk("Base de datos accesible", False, str(_e))

    # 15. Backup reciente (últimas 25 horas)
    try:
        import backup_manager as _bk
        _hist = _bk.get_history(limit=1)
        if _hist:
            from datetime import datetime, timezone
            _ts_str = _hist[0].get("created_at", "")
            try:
                _ts = datetime.fromisoformat(_ts_str)
                if _ts.tzinfo is None:
                    _ts = _ts.replace(tzinfo=timezone.utc)
                _age_h = (datetime.now(timezone.utc) - _ts).total_seconds() / 3600
                _bk_ok = _age_h <= 25
                _chk("Backup reciente (≤25h)", _bk_ok, f"{_age_h:.1f}h")
            except Exception:
                _chk("Backup reciente (≤25h)", False, "fecha inválida")
        else:
            _chk("Backup reciente (≤25h)", False, "sin historial")
    except Exception as _e:
        _chk("Backup reciente (≤25h)", False, str(_e))

    # 16. Logs sin errores críticos recientes
    try:
        import mrd_logging as _mrdlog
        _log_dir = BASE_DIR / "logs"
        _log_file = _log_dir / "mrd.log"
        _critical_count = 0
        if _log_file.exists():
            _lines = _log_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            _critical_count = sum(1 for l in _lines[-200:] if "CRITICAL" in l or "ERROR" in l)
        _chk("Logs: sin errores críticos recientes",
             _critical_count == 0, f"{_critical_count} errores en últimas 200 líneas")
    except Exception as _e:
        _chk("Logs: sin errores críticos recientes", True, "no se pudo leer log")

    # 17. Versión de la aplicación
    _chk("Versión cargada", bool(VERSION), VERSION)

    total = len(checks)
    return JSONResponse({
        "ok": passed == total,
        "passed": passed,
        "total": total,
        "version": VERSION,
        "public_url": pub,
        "scan_url": scan,
        "env": env,
        "checks": checks,
        "checked_at": datetime.now().isoformat(),
    })

@app.get("/scanner-test", response_class=HTMLResponse)
def scanner_test_page(request: Request, user: Usuario = Depends(requiere_login), db: Session = Depends(get_db)):
    """Pagina de diagnostico del escaner QR/barcode — solo admins."""
    return templates.TemplateResponse(request, "scanner_test.html", ctx_base(request, user))

@app.get("/instalar", response_class=HTMLResponse)
def instalar_app_page(request: Request, db: Session = Depends(get_db)):
    """Pagina de instalacion PWA — publica, accesible sin login para empleados."""
    user = usuario_actual(request, db)
    return templates.TemplateResponse(request, "instalar_app.html", ctx_base(request, user))



# ═══════════════════════════════════════════════════════════════════════════════
# MÓDULOS NUEVOS — MEJORAS GLOBALES
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Formación y habilitaciones ────────────────────────────────────────────

@app.get("/trabajadores/{tid}/formacion", response_class=HTMLResponse)
def formacion_lista(tid: int, request: Request,
                    user: Usuario = Depends(requiere_login),
                    db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    formaciones = (db.query(FormacionTrabajador)
                   .filter(FormacionTrabajador.trabajador_id == tid)
                   .order_by(FormacionTrabajador.fecha_caducidad.asc().nullslast())
                   .all())
    ctx = ctx_base(request, user)
    ctx.update({"trabajador": t, "formaciones": formaciones,
                "tipos_formacion": TIPOS_FORMACION,
                "ok": request.query_params.get("ok")})
    return templates.TemplateResponse(request, "trabajador_formacion.html", ctx)


@app.post("/trabajadores/{tid}/formacion", response_class=RedirectResponse)
def formacion_crear(tid: int, request: Request,
                    nombre_curso: str = Form(...),
                    tipo: str = Form(""),
                    entidad: str = Form(""),
                    fecha_realizacion: str = Form(""),
                    fecha_caducidad: str = Form(""),
                    num_certificado: str = Form(""),
                    notas: str = Form(""),
                    user: Usuario = Depends(requiere_login),
                    db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    from datetime import date as _d
    def _date(s):
        try: return _d.fromisoformat(s) if s else None
        except: return None
    f = FormacionTrabajador(
        trabajador_id=tid,
        nombre_curso=nombre_curso.strip(),
        tipo=tipo or None,
        entidad=entidad or None,
        fecha_realizacion=_date(fecha_realizacion),
        fecha_caducidad=_date(fecha_caducidad),
        num_certificado=num_certificado or None,
        notas=notas or None,
        usuario_id=user.id,
    )
    db.add(f)
    db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/formacion?ok=creado", status_code=303)


@app.post("/trabajadores/{tid}/formacion/{fid}/eliminar", response_class=RedirectResponse)
def formacion_eliminar(tid: int, fid: int,
                       user: Usuario = Depends(requiere_login),
                       db: Session = Depends(get_db)):
    f = db.get(FormacionTrabajador, fid)
    if f and f.trabajador_id == tid:
        db.delete(f)
        db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/formacion?ok=eliminado", status_code=303)


# ─── Reconocimientos médicos ──────────────────────────────────────────────────────

@app.get("/trabajadores/{tid}/reconocimientos", response_class=HTMLResponse)
def reconocimientos_lista(tid: int, request: Request,
                          user: Usuario = Depends(requiere_login),
                          db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    reconocimientos = (db.query(ReconocimientoMedico)
                       .filter(ReconocimientoMedico.trabajador_id == tid)
                       .order_by(ReconocimientoMedico.fecha.desc())
                       .all())
    ctx = ctx_base(request, user)
    ctx.update({"trabajador": t, "reconocimientos": reconocimientos,
                "ok": request.query_params.get("ok")})
    return templates.TemplateResponse(request, "trabajador_reconocimientos.html", ctx)


@app.post("/trabajadores/{tid}/reconocimientos", response_class=RedirectResponse)
def reconocimiento_crear(tid: int,
                         fecha: str = Form(...),
                         resultado: str = Form("apto"),
                         fecha_proxima: str = Form(""),
                         medico: str = Form(""),
                         centro: str = Form(""),
                         restricciones: str = Form(""),
                         user: Usuario = Depends(requiere_login),
                         db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    from datetime import date as _d
    def _date(s):
        try: return _d.fromisoformat(s) if s else None
        except: return None
    r = ReconocimientoMedico(
        trabajador_id=tid,
        fecha=_date(fecha) or _d.today(),
        resultado=resultado,
        fecha_proxima=_date(fecha_proxima),
        medico=medico or None,
        centro=centro or None,
        restricciones=restricciones or None,
        usuario_id=user.id,
    )
    db.add(r)
    db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/reconocimientos?ok=creado", status_code=303)


@app.post("/trabajadores/{tid}/reconocimientos/{rid}/eliminar", response_class=RedirectResponse)
def reconocimiento_eliminar(tid: int, rid: int,
                            user: Usuario = Depends(requiere_login),
                            db: Session = Depends(get_db)):
    r = db.get(ReconocimientoMedico, rid)
    if r and r.trabajador_id == tid:
        db.delete(r)
        db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/reconocimientos?ok=eliminado", status_code=303)


# ─── Documentación del trabajador ─────────────────────────────────────────────────────

@app.get("/trabajadores/{tid}/documentos", response_class=HTMLResponse)
def documentos_trabajador_lista(tid: int, request: Request,
                                user: Usuario = Depends(requiere_login),
                                db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    documentos = (db.query(DocumentoTrabajador)
                  .filter(DocumentoTrabajador.trabajador_id == tid)
                  .order_by(DocumentoTrabajador.fecha_caducidad.asc().nullslast())
                  .all())
    ctx = ctx_base(request, user)
    ctx.update({"trabajador": t, "documentos": documentos,
                "tipos_documento": TIPOS_DOCUMENTO_TRABAJADOR,
                "ok": request.query_params.get("ok")})
    return templates.TemplateResponse(request, "trabajador_documentos.html", ctx)


@app.post("/trabajadores/{tid}/documentos", response_class=RedirectResponse)
def documento_trabajador_crear(tid: int,
                               tipo: str = Form(...),
                               numero: str = Form(""),
                               fecha_emision: str = Form(""),
                               fecha_caducidad: str = Form(""),
                               notas: str = Form(""),
                               user: Usuario = Depends(requiere_login),
                               db: Session = Depends(get_db)):
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    from datetime import date as _d
    def _date(s):
        try: return _d.fromisoformat(s) if s else None
        except: return None
    d = DocumentoTrabajador(
        trabajador_id=tid,
        tipo=tipo,
        numero=numero or None,
        fecha_emision=_date(fecha_emision),
        fecha_caducidad=_date(fecha_caducidad),
        notas=notas or None,
        usuario_id=user.id,
    )
    db.add(d)
    db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/documentos?ok=creado", status_code=303)


@app.post("/trabajadores/{tid}/documentos/{did}/eliminar", response_class=RedirectResponse)
def documento_trabajador_eliminar(tid: int, did: int,
                                  user: Usuario = Depends(requiere_login),
                                  db: Session = Depends(get_db)):
    d = db.get(DocumentoTrabajador, did)
    if d and d.trabajador_id == tid:
        db.delete(d)
        db.commit()
    return RedirectResponse(f"/trabajadores/{tid}/documentos?ok=eliminado", status_code=303)


# ─── PDF ficha completa del trabajador ────────────────────────────────────────────────

@app.get("/trabajadores/{tid}/pdf-ficha")
def trabajador_pdf_ficha(tid: int,
                         user: Usuario = Depends(requiere_login),
                         db: Session = Depends(get_db)):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    import io, datetime as _dt
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=36, rightMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("<b>Ficha del Trabajador</b>", styles["Title"]))
    story.append(Paragraph(f"{t.nombre_completo} — {t.cargo or ''}", styles["Heading2"]))
    story.append(Spacer(1, 12))
    datos = [
        ["DNI", t.dni or "—"], ["Teléfono", t.telefono or "—"],
        ["Email", t.email or "—"], ["Empresa", t.empresa or "—"],
        ["Cargo", t.cargo or "—"], ["Departamento", t.departamento or "—"],
        ["Estado", "Activo" if t.activo else "Baja"],
    ]
    tbl = Table([["Campo", "Valor"]] + datos, colWidths=[130, 360])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3a5c")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f4f8")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#1a3a5c")),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 12))
    formaciones = db.query(FormacionTrabajador).filter(FormacionTrabajador.trabajador_id == tid).order_by(FormacionTrabajador.fecha_caducidad).all()
    if formaciones:
        story.append(Paragraph("<b>Formación y Habilitaciones</b>", styles["Heading3"]))
        rows = [["Curso", "Tipo", "Entidad", "Realización", "Caducidad"]]
        for fi in formaciones:
            rows.append([fi.nombre_curso, fi.tipo or "—", fi.entidad or "—",
                         fi.fecha_realizacion.strftime("%d/%m/%Y") if fi.fecha_realizacion else "—",
                         fi.fecha_caducidad.strftime("%d/%m/%Y") if fi.fecha_caducidad else "—"])
        tf = Table(rows, colWidths=[160, 80, 100, 70, 70])
        tf.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2d6a4f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0fff4")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(tf)
        story.append(Spacer(1, 10))
    epis = db.query(EPIIndividual).filter(EPIIndividual.trabajador_id == tid, EPIIndividual.estado == "activo").all()
    if epis:
        story.append(Paragraph("<b>EPIs Asignados</b>", styles["Heading3"]))
        rows = [["Tipo", "Código", "Marca/Modelo", "Próx. Revisión"]]
        for e in epis:
            rows.append([e.tipo, e.codigo_fabricacion, f"{e.marca or ''} {e.modelo or ''}".strip() or "—",
                         e.proxima_revision.strftime("%d/%m/%Y") if e.proxima_revision else "—"])
        te = Table(rows, colWidths=[80, 130, 150, 120])
        te.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#c0392b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#fff5f5")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        story.append(te)
    story.append(Spacer(1, 20))
    story.append(Paragraph(f"Generado: {_dt.datetime.now().strftime('%d/%m/%Y %H:%M')} — MRD Tool", styles["Normal"]))
    doc.build(story)
    buf.seek(0)
    nombre_archivo = f"ficha_{t.nombre.lower().replace(' ', '_')}.pdf"
    from fastapi.responses import StreamingResponse
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="{nombre_archivo}"'})


# ─── Portal QR del trabajador (público) ────────────────────────────────────────────────────────

@app.get("/portal/{token}", response_class=HTMLResponse)
def portal_trabajador(token: str, request: Request, db: Session = Depends(get_db)):
    t = db.query(Trabajador).filter(Trabajador.portal_token == token).first()
    if not t:
        return HTMLResponse("<h2>Enlace no válido</h2>", status_code=404)
    epis = db.query(EPIIndividual).filter(EPIIndividual.trabajador_id == t.id, EPIIndividual.estado == "activo").all()
    formaciones = db.query(FormacionTrabajador).filter(FormacionTrabajador.trabajador_id == t.id).order_by(FormacionTrabajador.fecha_caducidad.asc().nullslast()).all()
    reconocs = db.query(ReconocimientoMedico).filter(ReconocimientoMedico.trabajador_id == t.id).order_by(ReconocimientoMedico.fecha.desc()).limit(3).all()
    return templates.TemplateResponse(request, "portal_trabajador.html", {
        "request": request, "trabajador": t, "epis": epis,
        "formaciones": formaciones, "reconocimientos": reconocs,
    })


@app.get("/trabajadores/{tid}/portal-qr", response_class=HTMLResponse)
def trabajador_portal_qr(tid: int, request: Request,
                         user: Usuario = Depends(requiere_login),
                         db: Session = Depends(get_db)):
    import secrets as _sec
    t = db.get(Trabajador, tid)
    if not t:
        raise HTTPException(404)
    if not t.portal_token:
        t.portal_token = _sec.token_urlsafe(32)
        db.commit()
        db.refresh(t)
    portal_url = f"{MRD_PUBLIC_URL}/portal/{t.portal_token}"
    qr_b64 = generar_qr_base64(portal_url)
    ctx = ctx_base(request, user)
    ctx.update({"trabajador": t, "portal_url": portal_url, "qr_b64": qr_b64})
    return templates.TemplateResponse(request, "trabajador_portal_qr.html", ctx)


# ─── Materiales / Almacén ───────────────────────────────────────────────────────────────────────────

@app.get("/materiales", response_class=HTMLResponse)
async def materiales_lista(
    request: Request, db: Session = Depends(get_db),
    usuario=Depends(requiere_login),
    q: str = "", cat: str = "", solo_bajos: bool = False,
):
    query = db.query(Material).filter(Material.activo == True)
    if q:
        query = query.filter(Material.nombre.ilike(f"%{q}%"))
    if cat:
        query = query.filter(Material.categoria == cat)
    materiales = query.order_by(Material.nombre).all()
    if solo_bajos:
        materiales = [m for m in materiales if m.bajo_minimo]
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    return templates.TemplateResponse(request, "materiales.html", {
        "request": request, "usuario": usuario,
        "materiales": materiales, "categorias": CATEGORIAS_MATERIAL,
        "unidades": UNIDADES_MATERIAL, "obras": obras, "trabajadores": trabajadores,
        "q": q, "cat": cat, "solo_bajos": solo_bajos,
    })


@app.post("/materiales", response_class=RedirectResponse)
async def materiales_crear(request: Request, db: Session = Depends(get_db),
                            usuario=Depends(requiere_login)):
    form = await request.form()
    import uuid as _uuid
    _codigo = form.get("codigo") or None
    if not _codigo:
        _codigo = "MAT-" + _uuid.uuid4().hex[:6].upper()
    mat = Material(
        codigo=_codigo,
        nombre=form["nombre"],
        descripcion=form.get("descripcion"),
        categoria=form.get("categoria"),
        unidad=form.get("unidad", "ud"),
        stock_actual=float(form.get("stock_actual") or 0),
        stock_minimo=float(form.get("stock_minimo") or 0),
        ubicacion_texto=form.get("ubicacion"),
    )
    db.add(mat)
    db.commit()
    return RedirectResponse("/materiales?ok=creado", status_code=303)



# ─── Materiales — alertas stock bajo ────────────────────────────────────────────
@app.get("/materiales/alertas", response_class=HTMLResponse)
def materiales_alertas(
    request: Request, user: Usuario = Depends(requiere_login),
    db: Session = Depends(get_db),
):
    bajos = (
        db.query(Material)
        .filter(Material.activo == True, Material.stock_minimo > 0,
                Material.stock_actual <= Material.stock_minimo)
        .order_by(Material.almacen_id, Material.nombre)
        .all()
    )
    # Agrupar por almacén
    from collections import defaultdict as _dd
    por_almacen = _dd(list)
    sin_almacen = []
    for m in bajos:
        if m.almacen_id:
            por_almacen[m.almacen_id].append(m)
        else:
            sin_almacen.append(m)
    almacenes_ids = list(por_almacen.keys())
    almacenes_map = {a.id: a for a in db.query(Almacen).filter(Almacen.id.in_(almacenes_ids)).all()} if almacenes_ids else {}
    grupos = []
    for aid, mats in por_almacen.items():
        grupos.append({"almacen": almacenes_map.get(aid), "materiales": mats})
    if sin_almacen:
        grupos.append({"almacen": None, "materiales": sin_almacen})
    return templates.TemplateResponse(request, "materiales_alertas.html", ctx_base(
        request, user,
        bajos=bajos,
        grupos=grupos,
        total_bajo=len(bajos),
    ))

@app.get("/materiales/{mid}", response_class=HTMLResponse)
async def material_detalle(mid: int, request: Request, db: Session = Depends(get_db),
                            usuario=Depends(requiere_login)):
    mat = db.query(Material).filter(Material.id == mid).first()
    if not mat:
        raise HTTPException(status_code=404)
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    mat_movs = mat.movimientos_almacen if hasattr(mat, 'movimientos_almacen') else []
    return templates.TemplateResponse(request, "material_detalle.html", {
        "request": request, "usuario": usuario, "mat": mat, "mat_movs": mat_movs,
        "tipos": TIPOS_MOVIMIENTO_MAT, "obras": obras, "trabajadores": trabajadores,
    })


@app.post("/materiales/{mid}/movimiento", response_class=RedirectResponse)
async def material_movimiento(mid: int, request: Request, db: Session = Depends(get_db),
                               usuario=Depends(requiere_login)):
    mat = db.query(Material).filter(Material.id == mid).first()
    if not mat:
        raise HTTPException(status_code=404)
    form = await request.form()
    tipo = form.get("tipo", "salida")
    cantidad = float(form.get("cantidad") or 0)
    mov = MovimientoMaterial(
        material_id=mid,
        tipo=tipo,
        cantidad=cantidad,
        obra_id=int(form["obra_id"]) if form.get("obra_id") else None,
        trabajador_id=int(form["trabajador_id"]) if form.get("trabajador_id") else None,
        referencia=form.get("referencia"),
        notas=form.get("notas"),
        usuario_id=usuario.id,
    )
    if tipo == "salida":
        mat.stock_actual = max(0.0, mat.stock_actual - cantidad)
    elif tipo == "entrada":
        mat.stock_actual = mat.stock_actual + cantidad
    elif tipo == "ajuste":
        mat.stock_actual = cantidad
    db.add(mov)
    db.commit()
    return RedirectResponse(f"/materiales/{mid}?ok=mov", status_code=303)


@app.post("/materiales/{mid}/editar", response_class=RedirectResponse)
async def material_editar(mid: int, request: Request, db: Session = Depends(get_db),
                           usuario=Depends(requiere_login)):
    mat = db.query(Material).filter(Material.id == mid).first()
    if not mat:
        raise HTTPException(status_code=404)
    form = await request.form()
    mat.nombre = form.get("nombre") or mat.nombre
    mat.codigo = form.get("codigo") or None
    mat.descripcion = form.get("descripcion")
    mat.categoria = form.get("categoria")
    mat.unidad = form.get("unidad") or mat.unidad
    mat.stock_minimo = float(form.get("stock_minimo") or 0)
    mat.ubicacion_texto = form.get("ubicacion_texto")
    db.commit()
    return RedirectResponse(f"/materiales/{mid}?ok=editado", status_code=303)


@app.post("/materiales/{mid}/eliminar", response_class=RedirectResponse)
async def material_eliminar(mid: int, db: Session = Depends(get_db),
                             usuario=Depends(requiere_login)):
    mat = db.query(Material).filter(Material.id == mid).first()
    if mat:
        mat.activo = False
        db.commit()
    return RedirectResponse("/materiales?ok=eliminado", status_code=303)


# ─── Control vehicular ─────────────────────────────────────────────────────────────────────────────

@app.get("/vehiculos/movimientos", response_class=HTMLResponse)
async def vehiculos_movimientos(
    request: Request, db: Session = Depends(get_db),
    usuario=Depends(requiere_login),
    solo_activos: bool = False,
):
    movs = db.query(MovimientoVehiculo).order_by(MovimientoVehiculo.fecha_salida.desc()).limit(300).all()
    if solo_activos:
        movs = [m for m in movs if m.en_ruta]
    vehiculos = db.query(Vehiculo).filter(Vehiculo.activo == True).order_by(Vehiculo.matricula).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    en_ruta = [m for m in db.query(MovimientoVehiculo).all() if m.en_ruta]
    # Repostajes externos (gasolinera)
    repos_ext = db.query(RepostajeVehiculo).order_by(RepostajeVehiculo.fecha.desc()).limit(100).all()
    # Repostajes internos desde surtidor propio que corresponden a vehículos
    repos_surt = db.query(RepostajeSurtidor).filter(
        RepostajeSurtidor.vehiculo_id != None,
        RepostajeSurtidor.tipo_registro == 'repostaje'
    ).order_by(RepostajeSurtidor.fecha.desc()).limit(100).all()
    # Combinar y ordenar por fecha descendente
    from datetime import datetime as _dt
    def _fecha_key(r):
        f = r.fecha
        if f is None:
            return _dt.min
        if isinstance(f, _dt):
            return f
        return _dt.combine(f, _dt.min.time())
    repostajes = sorted(list(repos_ext) + list(repos_surt), key=_fecha_key, reverse=True)[:150]
    return templates.TemplateResponse(request, "vehiculos_movimientos.html", {
        "request": request, "usuario": usuario,
        "movimientos": movs, "vehiculos": vehiculos,
        "trabajadores": trabajadores, "obras": obras,
        "en_ruta": en_ruta, "solo_activos": solo_activos,
        "repostajes": repostajes,
    })


@app.post("/vehiculos/{vid}/salida", response_class=RedirectResponse)
async def vehiculo_salida(vid: int, request: Request, db: Session = Depends(get_db),
                           usuario=Depends(requiere_login)):
    form = await request.form()
    from datetime import datetime as _dt
    mov = MovimientoVehiculo(
        vehiculo_id=vid,
        conductor_id=int(form["conductor_id"]) if form.get("conductor_id") else None,
        obra_id=int(form["obra_id"]) if form.get("obra_id") else None,
        destino=form.get("destino"),
        fecha_salida=_dt.now(),
        km_salida=int(form["km_salida"]) if form.get("km_salida") else None,
        observaciones=form.get("observaciones"),
        usuario_id=usuario.id,
    )
    db.add(mov)
    db.commit()
    return RedirectResponse("/vehiculos/movimientos?ok=salida", status_code=303)


@app.post("/vehiculos/movimientos/{mid}/retorno", response_class=RedirectResponse)
async def vehiculo_retorno(mid: int, request: Request, db: Session = Depends(get_db),
                            usuario=Depends(requiere_login)):
    mov = db.query(MovimientoVehiculo).filter(MovimientoVehiculo.id == mid).first()
    if not mov:
        raise HTTPException(status_code=404)
    form = await request.form()
    from datetime import datetime as _dt
    mov.fecha_retorno = _dt.now()
    if form.get("km_retorno"):
        mov.km_retorno = int(form["km_retorno"])
    if form.get("obs_retorno"):
        obs = form["obs_retorno"]
        mov.observaciones = (mov.observaciones + " | " + obs) if mov.observaciones else obs
    db.commit()
    return RedirectResponse("/vehiculos/movimientos?ok=retorno", status_code=303)


# ─── Panel Salidas (¿Qué está fuera ahora?) ─────────────────────────────────────────────────────────────────────────────

@app.get("/panel-salidas", response_class=HTMLResponse)
async def panel_salidas(request: Request, db: Session = Depends(get_db),
                         usuario=Depends(requiere_login)):
    from datetime import datetime as _dt
    herr_fuera = db.query(Herramienta).filter(
        Herramienta.activa == True,
        Herramienta.estado.notin_(["disponible", "baja", "mantenimiento"]),
    ).order_by(Herramienta.nombre).all()
    epis_fuera = db.query(EPIIndividual).filter(
        EPIIndividual.estado == "activo",
        EPIIndividual.trabajador_id.isnot(None),
    ).order_by(EPIIndividual.tipo).all()
    vehs_ruta = [m for m in db.query(MovimientoVehiculo)
                 .order_by(MovimientoVehiculo.fecha_salida.desc()).all()
                 if m.en_ruta]
    mat_bajos = [m for m in db.query(Material).filter(Material.activo == True).all()
                 if m.bajo_minimo]
    maq_fuera = db.query(Maquinaria).filter(
        Maquinaria.estado.in_(["en_obra", "asignada", "alquilada"]),
    ).order_by(Maquinaria.nombre).all()
    return templates.TemplateResponse(request, "panel_salidas.html", {
        "request": request, "usuario": usuario,
        "herr_fuera": herr_fuera, "epis_fuera": epis_fuera,
        "vehs_ruta": vehs_ruta, "mat_bajos": mat_bajos, "maq_fuera": maq_fuera,
        "ahora": _dt.now(),
    })


# ─── Historial Global ─────────────────────────────────────────────────────────────────────────────────────────────────────────

@app.get("/historial", response_class=HTMLResponse)
async def historial_global(
    request: Request, db: Session = Depends(get_db),
    usuario=Depends(requiere_login),
    tipo: str = "", obra_id: str = "", desde: str = "", hasta: str = "",
    pagina: int = 1,
):
    from datetime import datetime as _dt, date as _date
    POR_PAG = 60
    eventos = []

    # Movimientos de herramientas
    q_mov = db.query(Movimiento).order_by(Movimiento.fecha.desc())
    for mv in q_mov.limit(300).all():
        eventos.append({
            "fecha": mv.fecha, "tipo_cat": "herramienta",
            "icono": "bi-wrench-adjustable", "color": "primary",
            "descripcion": f"{mv.tipo.capitalize()} · {mv.herramienta.nombre if mv.herramienta else '?'}",
            "responsable": mv.responsable.nombre_completo if mv.responsable else "—",
            "obra": mv.obra.nombre if mv.obra else "—",
            "detalle": f"/herramientas/{mv.herramienta_id}" if mv.herramienta_id else "#",
        })

    # Movimientos de materiales
    for mm in db.query(MovimientoMaterial).order_by(MovimientoMaterial.fecha.desc()).limit(300).all():
        eventos.append({
            "fecha": mm.fecha, "tipo_cat": "material",
            "icono": "bi-boxes", "color": "success",
            "descripcion": f"{mm.tipo.capitalize()} {mm.cantidad} {mm.material.unidad if mm.material else ''} · {mm.material.nombre if mm.material else '?'}",
            "responsable": mm.trabajador.nombre_completo if mm.trabajador else "—",
            "obra": mm.obra.nombre if mm.obra else "—",
            "detalle": f"/materiales/{mm.material_id}" if mm.material_id else "#",
        })

    # Movimientos de vehículos
    for mv in db.query(MovimientoVehiculo).order_by(MovimientoVehiculo.fecha_salida.desc()).limit(200).all():
        eventos.append({
            "fecha": mv.fecha_salida, "tipo_cat": "vehiculo",
            "icono": "bi-truck", "color": "warning",
            "descripcion": f"{'Retorno' if not mv.en_ruta else 'Salida'} · {mv.vehiculo.matricula if mv.vehiculo else '?'}",
            "responsable": mv.conductor.nombre_completo if mv.conductor else "—",
            "obra": mv.obra.nombre if mv.obra else (mv.destino or "—"),
            "detalle": "/vehiculos/movimientos",
        })

    # Albaranes de salida
    for alb in db.query(AlbaranSalida).order_by(AlbaranSalida.fecha_salida.desc()).limit(100).all():
        eventos.append({
            "fecha": alb.fecha_salida, "tipo_cat": "albaran",
            "icono": "bi-file-earmark-arrow-up", "color": "danger",
            "descripcion": f"Albarán {alb.numero} · {len(alb.items)} ítem(s)",
            "responsable": alb.responsable.nombre_completo if alb.responsable else "—",
            "obra": alb.obra.nombre if alb.obra else "—",
            "detalle": f"/albaranes-salida/{alb.id}",
        })

    # Filtros
    if tipo:
        eventos = [e for e in eventos if e["tipo_cat"] == tipo]
    if obra_id:
        eventos = [e for e in eventos if e["obra"] and obra_id in e["obra"]]
    if desde:
        try:
            d = _dt.fromisoformat(desde)
            eventos = [e for e in eventos if e["fecha"] and e["fecha"] >= d]
        except Exception: pass
    if hasta:
        try:
            h = _dt.fromisoformat(hasta)
            eventos = [e for e in eventos if e["fecha"] and e["fecha"] <= h]
        except Exception: pass

    eventos.sort(key=lambda e: e["fecha"] or _dt(2000,1,1), reverse=True)
    total = len(eventos)
    inicio = (pagina-1)*POR_PAG
    paginas = max(1, (total + POR_PAG - 1)//POR_PAG)
    eventos = eventos[inicio:inicio+POR_PAG]
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    return templates.TemplateResponse(request, "historial.html", {
        "request": request, "usuario": usuario, "eventos": eventos,
        "tipo": tipo, "obra_id": obra_id, "desde": desde, "hasta": hasta,
        "pagina": pagina, "paginas": paginas, "total": total, "obras": obras,
    })


# ─── Albaranes de Salida ───────────────────────────────────────────────────────────────────────────────────────────────────────

def _gen_numero_albaran(db):
    from datetime import date as _d
    hoy = _d.today().strftime("%Y%m%d")
    prefix = f"AL-{hoy}-"
    count = db.query(AlbaranSalida).filter(AlbaranSalida.numero.like(f"{prefix}%")).count()
    return f"{prefix}{count+1:03d}"


@app.get("/albaranes-salida", response_class=HTMLResponse)
async def albaranes_lista(request: Request, db: Session = Depends(get_db),
                           usuario=Depends(requiere_login)):
    albaranes = db.query(AlbaranSalida).order_by(AlbaranSalida.fecha_salida.desc()).limit(200).all()
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True,
                            Herramienta.estado == "disponible").order_by(Herramienta.nombre).all()
    materiales = db.query(Material).filter(Material.activo == True).order_by(Material.nombre).all()
    return templates.TemplateResponse(request, "albaranes_salida.html", {
        "request": request, "usuario": usuario, "albaranes": albaranes,
        "obras": obras, "trabajadores": trabajadores,
        "herramientas": herramientas, "materiales": materiales,
    })


@app.post("/albaranes-salida", response_class=RedirectResponse)
async def albaran_crear(request: Request, db: Session = Depends(get_db),
                         usuario=Depends(requiere_login)):
    form = await request.form()
    from datetime import datetime as _dt
    alb = AlbaranSalida(
        numero=_gen_numero_albaran(db),
        obra_id=int(form["obra_id"]) if form.get("obra_id") else None,
        responsable_id=int(form["responsable_id"]) if form.get("responsable_id") else None,
        fecha_salida=_dt.now(),
        notas=form.get("notas"),
        usuario_id=usuario.id,
    )
    db.add(alb); db.flush()
    # items dinámicos: herramientas[]
    for hid in form.getlist("herramienta_ids"):
        if hid:
            db.add(ItemAlbaranSalida(albaran_id=alb.id, tipo="herramienta",
                                     herramienta_id=int(hid), cantidad=1))
    # items: materiales + cantidades
    for mid in form.getlist("material_ids"):
        if mid:
            cant = float(form.get(f"cant_mat_{mid}") or 1)
            db.add(ItemAlbaranSalida(albaran_id=alb.id, tipo="material",
                                     material_id=int(mid), cantidad=cant))
            mat = db.query(Material).filter(Material.id == int(mid)).first()
            if mat:
                mat.stock_actual = max(0.0, mat.stock_actual - cant)
    # líneas libres
    for desc in form.getlist("lineas_libres"):
        if desc.strip():
            db.add(ItemAlbaranSalida(albaran_id=alb.id, tipo="libre",
                                     descripcion_libre=desc.strip(), cantidad=1))
    db.commit()
    return RedirectResponse(f"/albaranes-salida/{alb.id}", status_code=303)


@app.get("/albaranes-salida/{aid}", response_class=HTMLResponse)
async def albaran_detalle(aid: int, request: Request, db: Session = Depends(get_db),
                           usuario=Depends(requiere_login)):
    alb = db.query(AlbaranSalida).filter(AlbaranSalida.id == aid).first()
    if not alb:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse(request, "albaran_detalle.html", {
        "request": request, "usuario": usuario, "alb": alb,
    })


@app.post("/albaranes-salida/{aid}/retorno-item/{iid}", response_class=RedirectResponse)
async def albaran_retorno_item(aid: int, iid: int, db: Session = Depends(get_db),
                                usuario=Depends(requiere_login)):
    item = db.query(ItemAlbaranSalida).filter(ItemAlbaranSalida.id == iid).first()
    if item:
        from datetime import datetime as _dt
        item.retornado = True
        item.fecha_retorno = _dt.now()
        if item.tipo == "material" and item.material:
            item.material.stock_actual += item.cantidad
        alb = item.albaran
        if alb:
            if all(i.retornado for i in alb.items):
                alb.estado = "cerrado"
                alb.fecha_retorno_real = _dt.now()
            else:
                alb.estado = "parcial"
        db.commit()
    return RedirectResponse(f"/albaranes-salida/{aid}?ok=retorno", status_code=303)


@app.get("/albaranes-salida/{aid}/pdf")
async def albaran_pdf(aid: int, db: Session = Depends(get_db),
                       usuario=Depends(requiere_login)):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    import io
    alb = db.query(AlbaranSalida).filter(AlbaranSalida.id == aid).first()
    if not alb:
        raise HTTPException(status_code=404)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph(f"<b>ALBARÁN DE SALIDA {alb.numero}</b>", styles["Title"]))
    story.append(Spacer(1,10))
    info = [
        ["Obra:", alb.obra.nombre if alb.obra else "—",
         "Responsable:", alb.responsable.nombre_completo if alb.responsable else "—"],
        ["Fecha salida:", alb.fecha_salida.strftime("%d/%m/%Y %H:%M"),
         "Estado:", alb.estado.upper()],
    ]
    t = Table(info, colWidths=[80,170,80,170])
    t.setStyle(TableStyle([("FONTNAME",(0,0),(-1,-1),"Helvetica"),
                            ("FONTSIZE",(0,0),(-1,-1),9),
                            ("TEXTCOLOR",(0,0),(0,-1),colors.grey),
                            ("TEXTCOLOR",(2,0),(2,-1),colors.grey)]))
    story.append(t); story.append(Spacer(1,16))
    headers = [["#","Descripción","Tipo","Cantidad","Retornado"]]
    rows = headers + [[str(i+1), item.descripcion, item.tipo.capitalize(),
                       str(item.cantidad), "Sí" if item.retornado else "No"]
                      for i, item in enumerate(alb.items)]
    tbl = Table(rows, colWidths=[25,230,80,60,80])
    tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A5F")),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),9),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#f8f9fa")]),
        ("GRID",(0,0),(-1,-1),0.3,colors.lightgrey),
        ("ALIGN",(3,0),(4,-1),"CENTER"),
    ]))
    story.append(tbl)
    if alb.notas:
        story.append(Spacer(1,12))
        story.append(Paragraph(f"<b>Notas:</b> {alb.notas}", styles["Normal"]))
    story.append(Spacer(1,30))
    story.append(Paragraph("Firma del responsable: ___________________________", styles["Normal"]))
    doc.build(story)
    buf.seek(0)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(buf, media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=albaran_{alb.numero}.pdf"})


# ─── QR de Material ──────────────────────────────────────────────────────────────────────────────────────────────────────

@app.get("/materiales/{mid}/qr", response_class=HTMLResponse)
async def material_qr(mid: int, request: Request, db: Session = Depends(get_db),
                       usuario=Depends(requiere_login)):
    mat = db.query(Material).filter(Material.id == mid).first()
    if not mat:
        raise HTTPException(status_code=404)
    public_url = getattr(config, "MRD_PUBLIC_URL", None) or str(request.base_url).rstrip("/")
    url = f"{public_url}/materiales/{mid}"
    qr_b64 = generar_qr_base64(url)
    return templates.TemplateResponse(request, "material_qr.html", {
        "request": request, "usuario": usuario, "mat": mat,
        "qr_b64": qr_b64, "url": url,
    })


# ─── Importar materiales desde Excel ──────────────────────────────────────────────────────────────────────────────────────

@app.get("/materiales/importar", response_class=HTMLResponse)
async def materiales_importar_form(request: Request, db: Session = Depends(get_db),
                                    usuario=Depends(requiere_login)):
    return templates.TemplateResponse(request, "materiales_importar.html", {
        "request": request, "usuario": usuario,
    })


@app.post("/materiales/importar", response_class=HTMLResponse)
async def materiales_importar_post(request: Request, db: Session = Depends(get_db),
                                    usuario=Depends(requiere_login),
                                    archivo: UploadFile = File(...)):
    import openpyxl, io, uuid as _uuid
    contents = await archivo.read()
    wb = openpyxl.load_workbook(io.BytesIO(contents))
    ws = wb.active
    creados = 0; errores = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        try:
            codigo = str(row[0]).strip() if row[0] else None
            nombre = str(row[1]).strip() if row[1] else None
            if not nombre:
                continue
            if not codigo:
                codigo = "MAT-" + _uuid.uuid4().hex[:6].upper()
            existe = db.query(Material).filter(Material.codigo == codigo).first()
            if existe:
                errores.append(f"{codigo}: ya existe, omitido")
                continue
            mat = Material(
                codigo=codigo, nombre=nombre,
                categoria=str(row[2]).strip() if row[2] else None,
                unidad=str(row[3]).strip() if row[3] else "ud",
                stock_actual=float(row[4]) if row[4] else 0.0,
                stock_minimo=float(row[5]) if row[5] else 0.0,
                ubicacion_texto=str(row[6]).strip() if row[6] else None,
            )
            db.add(mat); creados += 1
        except Exception as ex:
            errores.append(str(ex))
    db.commit()
    return templates.TemplateResponse(request, "materiales_importar.html", {
        "request": request, "usuario": usuario,
        "creados": creados, "errores": errores,
    })


@app.get("/materiales/plantilla-excel")
async def materiales_plantilla(usuario=Depends(requiere_login)):
    import openpyxl, io
    from fastapi.responses import StreamingResponse
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Materiales"
    ws.append(["Codigo","Nombre","Categoria","Unidad","Stock inicial","Stock minimo","Ubicacion nave"])
    ws.append(["MAT-001","Cable H07Z1-K 1.5mm²","Cables y electricidad","m","100","20","Estanteria A1"])
    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return StreamingResponse(buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=plantilla_materiales.xlsx"})


# ─── Repostaje de vehículos ───────────────────────────────────────────────────────────────────────────────────────────────

@app.post("/vehiculos/{vid}/repostaje", response_class=RedirectResponse)
async def vehiculo_repostaje(vid: int, request: Request, db: Session = Depends(get_db),
                              usuario=Depends(requiere_login)):
    form = await request.form()
    litros = float(form.get("litros") or 0)
    precio = float(form.get("precio_litro") or 0) if form.get("precio_litro") else None
    rep = RepostajeVehiculo(
        vehiculo_id=vid,
        litros=litros,
        precio_litro=precio,
        total_euros=round(litros * precio, 2) if precio else (float(form.get("total_euros_manual")) if form.get("total_euros_manual") else None),
        km_actuales=int(form["km_actuales"]) if form.get("km_actuales") else None,
        gasolinera=form.get("gasolinera"),
        notas=form.get("notas"),
        usuario_id=usuario.id,
    )
    # actualizar km en vehículo
    if rep.km_actuales:
        v = db.query(Vehiculo).filter(Vehiculo.id == vid).first()
        if v and (not v.kilometros or rep.km_actuales > v.kilometros):
            v.kilometros = rep.km_actuales
    db.add(rep); db.commit()
    return RedirectResponse("/vehiculos/movimientos?ok=repostaje", status_code=303)


# ─── Salida rápida (móvil) ───────────────────────────────────────────────────────────────────────────────────────────────

@app.get("/salida-rapida", response_class=HTMLResponse)
async def salida_rapida(request: Request, db: Session = Depends(get_db),
                         usuario=Depends(requiere_login)):
    obras = db.query(Obra).filter(Obra.activa == True).order_by(Obra.nombre).all()
    trabajadores = db.query(Trabajador).filter(Trabajador.activo == True).order_by(Trabajador.nombre).all()
    herramientas = db.query(Herramienta).filter(Herramienta.activa == True,
                            Herramienta.estado == "disponible").order_by(Herramienta.nombre).all()
    materiales = db.query(Material).filter(Material.activo == True,
                          Material.stock_actual > 0).order_by(Material.nombre).all()
    vehiculos = db.query(Vehiculo).filter(Vehiculo.activo == True).order_by(Vehiculo.matricula).all()
    return templates.TemplateResponse(request, "salida_rapida.html", {
        "request": request, "usuario": usuario,
        "obras": obras, "trabajadores": trabajadores,
        "herramientas": herramientas, "materiales": materiales, "vehiculos": vehiculos,
    })


# ─── Foto en incidencias ───────────────────────────────────────────────────────────────

@app.post("/incidencias/{iid}/foto", response_class=RedirectResponse)
async def incidencia_foto(iid: int,
                          foto: UploadFile = File(...),
                          user: Usuario = Depends(requiere_login),
                          db: Session = Depends(get_db)):
    inc = db.get(Incidencia, iid)
    if not inc:
        raise HTTPException(404)
    carpeta = BASE_DIR / "static" / "uploads" / "incidencias"
    carpeta.mkdir(parents=True, exist_ok=True)
    if inc.foto_path:
        old_p = carpeta / inc.foto_path
        if old_p.exists():
            old_p.unlink()
    ext = (foto.filename or "").rsplit(".", 1)[-1].lower() or "jpg"
    import time as _time
    nombre = f"{iid}_{int(_time.time())}.{ext}"
    data = await foto.read()
    (carpeta / nombre).write_bytes(data)
    inc.foto_path = nombre
    db.commit()
    return RedirectResponse(f"/incidencias/{iid}?ok=foto", status_code=303)


@app.post("/incidencias/{iid}/foto/eliminar", response_class=RedirectResponse)
def incidencia_foto_eliminar(iid: int,
                             user: Usuario = Depends(requiere_login),
                             db: Session = Depends(get_db)):
    inc = db.get(Incidencia, iid)
    if inc and inc.foto_path:
        p = BASE_DIR / "static" / "uploads" / "incidencias" / inc.foto_path
        if p.exists():
            p.unlink()
        inc.foto_path = None
        db.commit()
    return RedirectResponse(f"/incidencias/{iid}?ok=foto_eliminada", status_code=303)


# ─── /version.json ── Servidor de actualizaciones ────────────────────────────
@app.get("/version.json")
def serve_version_json():
    """
    Sirve el archivo version.json para el sistema de actualizaciones.
    Accesible en https://app.iasmrd.com/version.json
    """
    import json as _json
    try:
        vpath = BASE_DIR / "version.json"
        data  = _json.loads(vpath.read_text(encoding="utf-8"))
        return data
    except Exception as exc:
        return {"error": str(exc), "version_actual": "0.0.0"}




# ─── Surtidor de combustible ──────────────────────────────────────────────────

def _generar_pdf_surtidor(rep, stock_antes: float, stock_despues: float, empresa: str) -> bytes:
    """Genera ticket/albarán PDF de repostaje en el surtidor interno."""
    import io as _io
    from reportlab.lib.pagesizes import A5
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

    buf = _io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A5,
                            leftMargin=1.5*cm, rightMargin=1.5*cm,
                            topMargin=1.5*cm, bottomMargin=1.5*cm)

    azul   = colors.HexColor("#1B4F8A")
    naranj = colors.HexColor("#E8600A")
    gris   = colors.HexColor("#555555")
    rojo   = colors.HexColor("#dc3545")

    def P(text, size=10, bold=False, color=colors.black, align=TA_LEFT):
        name = f"s{size}{'b' if bold else ''}{'c' if align==TA_CENTER else ''}"
        st = ParagraphStyle(name, fontSize=size,
                            fontName="Helvetica-Bold" if bold else "Helvetica",
                            textColor=color, alignment=align, spaceAfter=2)
        return Paragraph(text, st)

    num       = f"SURT-{rep.fecha.strftime('%Y%m%d') if rep.fecha else '?'}-{rep.id:04d}"
    fecha_str = rep.fecha.strftime("%d/%m/%Y") if rep.fecha else "—"
    hora_str  = rep.fecha.strftime("%H:%M")    if rep.fecha else "—"
    activo    = str(rep.activo_nombre or "—")
    tipo_label = str(getattr(rep, 'activo_tipo', None) or "Vehículo")
    comb_label = (rep.tipo_combustible or "gasoil").upper()
    precio_str = f"{rep.precio_litro:.3f} €/L" if rep.precio_litro else "—"
    litros_str = f"{rep.litros:.2f} L"
    operador   = str(rep.usuario.nombre if (rep.usuario and hasattr(rep.usuario, 'nombre')) else "—")

    story = []

    # ── Cabecera ─────────────────────────────────────────
    story.append(P(empresa.upper(), size=14, bold=True, color=azul, align=TA_CENTER))
    story.append(P("ALBARÁN DE REPOSTAJE — SURTIDOR NAVE", size=9, color=naranj, align=TA_CENTER))
    story.append(HRFlowable(width="100%", thickness=2, color=azul, spaceAfter=4))

    # Nº y fecha en una fila
    t_head = Table([[f"Nº: {num}", f"{fecha_str}  {hora_str}"]],
                   colWidths=[8*cm, 4*cm])
    t_head.setStyle(TableStyle([
        ("FONTNAME",  (0,0), (-1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0), (-1,-1), 8),
        ("TEXTCOLOR", (0,0), (-1,-1), gris),
        ("ALIGN",     (1,0), (1,0), "RIGHT"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 2),
        ("TOPPADDING",    (0,0), (-1,-1), 2),
    ]))
    story.append(t_head)
    story.append(Spacer(1, 8))

    # ── Matrícula / Vehículo — bloque grande ─────────────
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey, spaceAfter=6))
    story.append(P(activo, size=20, bold=True, color=azul, align=TA_CENTER))
    story.append(P(tipo_label, size=10, color=gris, align=TA_CENTER))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey, spaceAfter=6))
    story.append(Spacer(1, 4))

    # ── Datos del repostaje ───────────────────────────────
    filas = [
        ["COMBUSTIBLE",   comb_label],
        ["LITROS",        litros_str],
        ["PRECIO / LITRO", precio_str],
        ["OPERADOR",      operador],
    ]
    if rep.km_actuales:
        filas.append(["KM ACTUALES", f"{rep.km_actuales:,} km"])

    t_datos = Table(filas, colWidths=[5.5*cm, 6.5*cm])
    t_datos.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME",      (1,0), (1,-1), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (0,-1), 9),
        ("FONTSIZE",      (1,0), (1,-1), 11),
        ("TEXTCOLOR",     (0,0), (0,-1), gris),
        ("TEXTCOLOR",     (1,0), (1,0), azul),        # combustible
        ("TEXTCOLOR",     (1,1), (1,1), naranj),       # litros
        ("FONTSIZE",      (1,1), (1,1), 16),           # litros — grande
        ("TEXTCOLOR",     (1,2), (1,2), colors.black), # precio
        ("TEXTCOLOR",     (1,3), (1,3), gris),         # operador
        ("FONTSIZE",      (1,3), (1,3), 9),
        ("ALIGN",         (1,0), (1,-1), "RIGHT"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("LINEBELOW",     (0,0), (-1,0), 0.5, colors.lightgrey),
        ("LINEBELOW",     (0,2), (-1,2), 1, colors.lightgrey),
    ]))
    story.append(t_datos)
    story.append(Spacer(1, 8))

    if rep.notas:
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey, spaceAfter=4))
        story.append(P(f"Notas: {rep.notas}", size=8, color=gris))

    story.append(Spacer(1, 14))
    story.append(HRFlowable(width="100%", thickness=1, color=azul, spaceAfter=4))
    story.append(P("Documento generado automáticamente por MRD Tool Control", size=7, color=gris, align=TA_CENTER))

    doc.build(story)
    buf.seek(0)
    return buf.read()


def _stock_surtidor(db) -> float:
    """Calcula el stock actual del depósito: compras - repostajes (todo el histórico)."""
    todos = db.query(RepostajeSurtidor).all()
    compras    = sum(r.litros for r in todos if r.tipo_registro == "compra")
    dispensado = sum(r.litros for r in todos if r.tipo_registro == "repostaje")
    return round(compras - dispensado, 2)


@app.get("/surtidor", response_class=HTMLResponse)
async def surtidor_get(
    request: Request,
    db: Session = Depends(get_db),
    usuario=Depends(requiere_login),
    mes: int = None,
    anio: int = None,
):
    from datetime import datetime as _dt, date as _date
    import calendar

    hoy = _date.today()
    mes  = mes  or hoy.month
    anio = anio or hoy.year

    todos = db.query(RepostajeSurtidor).order_by(RepostajeSurtidor.fecha.desc()).limit(200).all()

    primer_dia = _dt(anio, mes, 1)
    ultimo_dia = _dt(anio, mes, calendar.monthrange(anio, mes)[1], 23, 59, 59)
    del_mes = db.query(RepostajeSurtidor).filter(
        RepostajeSurtidor.fecha >= primer_dia,
        RepostajeSurtidor.fecha <= ultimo_dia,
    ).all()

    repos_mes   = [r for r in del_mes if r.tipo_registro == "repostaje"]
    compras_mes = [r for r in del_mes if r.tipo_registro == "compra"]
    litros_mes  = round(sum(r.litros for r in repos_mes), 2)
    comprado_mes= round(sum(r.litros for r in compras_mes), 2)
    gasto_mes   = round(sum(r.total_euros or 0 for r in del_mes), 2)
    n_repos     = len(repos_mes)
    precio_med  = round(sum(r.precio_litro for r in del_mes if r.precio_litro) /
                        max(1, sum(1 for r in del_mes if r.precio_litro)), 3) if del_mes else 0

    # Stock actual del depósito
    stock_actual = _stock_surtidor(db)

    # Si viene de un repostaje recién guardado, pasar el ID para mostrar botón albarán
    ok_param = request.query_params.get("ok", "")
    albaran_id = int(ok_param) if ok_param.isdigit() else None

    from sqlalchemy import or_ as _or
    vehiculos = db.query(Vehiculo).filter(
        Vehiculo.activo == True,
        _or(
            Vehiculo.tipo == None,
            Vehiculo.tipo.in_(["furgoneta", "camion", "camión", "van", "furgón"])
        )
    ).order_by(Vehiculo.matricula).all()
    maquinarias = db.query(Maquinaria).filter(Maquinaria.activa == True).order_by(Maquinaria.nombre).all()

    meses_nombres = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
                     "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]
    anios_rango = list(range(hoy.year - 2, hoy.year + 1))

    return templates.TemplateResponse(request, "surtidor.html", {
        "request": request,
        "usuario": usuario,
        "todos": todos,
        "litros_mes": litros_mes,
        "comprado_mes": comprado_mes,
        "gasto_mes": gasto_mes,
        "n_repos": n_repos,
        "precio_med": precio_med,
        "stock_actual": stock_actual,
        "albaran_id": albaran_id,
        "mes_sel": mes,
        "anio_sel": anio,
        "mes_label": meses_nombres[mes - 1],
        "meses_nombres": meses_nombres,
        "anios_rango": anios_rango,
        "vehiculos": vehiculos,
        "maquinarias": maquinarias,
    })


@app.get("/surtidor/{rid}/albaran")
async def surtidor_albaran(rid: int, db: Session = Depends(get_db),
                            usuario=Depends(requiere_login)):
    """Genera y descarga el albarán PDF de un repostaje del surtidor."""
    from fastapi.responses import Response as _Resp
    rep = db.query(RepostajeSurtidor).filter(RepostajeSurtidor.id == rid).first()
    if not rep or rep.tipo_registro != "repostaje":
        raise HTTPException(status_code=404, detail="Repostaje no encontrado")

    # Calcular stock antes y después
    todos = db.query(RepostajeSurtidor).filter(RepostajeSurtidor.fecha <= rep.fecha).all()
    compras    = sum(r.litros for r in todos if r.tipo_registro == "compra")
    dispensado = sum(r.litros for r in todos if r.tipo_registro == "repostaje")
    stock_despues = round(compras - dispensado, 2)
    stock_antes   = round(stock_despues + rep.litros, 2)

    pdf_bytes = _generar_pdf_surtidor(rep, stock_antes, stock_despues, COMPANY_NAME)
    nombre = f"albaran_surtidor_{rid:04d}.pdf"
    return _Resp(content=pdf_bytes, media_type="application/pdf",
                 headers={"Content-Disposition": f'inline; filename="{nombre}"'})


@app.post("/surtidor/nuevo", response_class=RedirectResponse)
async def surtidor_nuevo(request: Request, db: Session = Depends(get_db),
                          usuario=Depends(requiere_login)):
    form = await request.form()
    tipo_registro = form.get("tipo_registro", "repostaje")
    tipo_activo   = form.get("tipo_activo", "vehiculo")
    litros = float(form.get("litros") or 0)
    precio = float(form.get("precio_litro")) if form.get("precio_litro") else None
    total  = float(form.get("total_euros"))  if form.get("total_euros")  else (
        round(litros * precio, 2) if precio else None
    )
    rep = RepostajeSurtidor(
        tipo_registro=tipo_registro,
        tipo_combustible=form.get("tipo_combustible", "gasoil"),
        vehiculo_id=(int(form["vehiculo_id"]) if tipo_registro == "repostaje"
                     and tipo_activo == "vehiculo" and form.get("vehiculo_id") else None),
        maquinaria_id=(int(form["maquinaria_id"]) if tipo_registro == "repostaje"
                       and tipo_activo == "maquinaria" and form.get("maquinaria_id") else None),
        litros=litros,
        precio_litro=precio,
        total_euros=total,
        km_actuales=int(form["km_actuales"]) if form.get("km_actuales") else None,
        proveedor=form.get("proveedor") if tipo_registro == "compra" else None,
        notas=form.get("notas"),
        usuario_id=usuario.id,
    )
    db.add(rep)
    db.commit()
    db.refresh(rep)
    # Si es repostaje → redirigir al surtidor con ID para mostrar botón albarán
    if tipo_registro == "repostaje":
        return RedirectResponse(f"/surtidor?ok={rep.id}", status_code=303)
    return RedirectResponse("/surtidor?ok=compra", status_code=303)


@app.post("/surtidor/{rid}/eliminar", response_class=RedirectResponse)
async def surtidor_eliminar(rid: int, db: Session = Depends(get_db),
                             usuario=Depends(requiere_login)):
    rep = db.query(RepostajeSurtidor).filter(RepostajeSurtidor.id == rid).first()
    if rep:
        db.delete(rep)
        db.commit()
    return RedirectResponse("/surtidor?ok=eliminado", status_code=303)
