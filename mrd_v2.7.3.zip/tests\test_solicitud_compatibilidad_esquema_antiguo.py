"""Reproduce una instalación con el esquema anterior a 2.6, donde
solicitudes_trabajador.tipo/categoria/asunto/mensaje eran NOT NULL y las
migraciones aditivas de database.py nunca llegan a relajar."""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from database import Base
from models import Trabajador
from worker_portal_service import create_worker_request


def _crear_motor_esquema_legacy():
    """Motor aislado con el esquema actual completo, salvo
    solicitudes_trabajador, que se recrea con las columnas heredadas
    (tipo, categoria, asunto, mensaje) como NOT NULL, igual que en
    instalaciones reales anteriores a 2.6."""
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    with engine.begin() as conn:
        conn.execute(text("DROP TABLE solicitudes_trabajador"))
        conn.execute(text("""
            CREATE TABLE solicitudes_trabajador (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                numero VARCHAR(40) NOT NULL UNIQUE,
                submission_id VARCHAR(64) NOT NULL UNIQUE,
                trabajador_id INTEGER NOT NULL,
                almacen_id INTEGER,
                estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
                prioridad VARCHAR(20) NOT NULL DEFAULT 'normal',
                tipo VARCHAR(20) NOT NULL,
                categoria VARCHAR(50) NOT NULL,
                asunto VARCHAR(200) NOT NULL,
                mensaje TEXT NOT NULL,
                cantidad INTEGER,
                respuesta TEXT,
                respondido_en DATETIME,
                obra_destino VARCHAR(200),
                motivo TEXT,
                notas_gestion TEXT,
                revisado_por_id INTEGER,
                creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                entregado_en DATETIME,
                fecha_estimada DATETIME,
                cancelada_por_trabajador_en DATETIME,
                recogida_confirmada_en DATETIME
            )
        """))
    return engine


def test_create_worker_request_funciona_con_esquema_antiguo_not_null():
    """Antes del fix, esto fallaba con:
    sqlite3.IntegrityError: NOT NULL constraint failed: solicitudes_trabajador.tipo
    en cualquier instalación real que conservase el esquema anterior a 2.6
    (el mismo error visto en logs/errores.log de producción)."""
    engine = _crear_motor_esquema_legacy()
    Session = sessionmaker(bind=engine)
    db = Session()
    try:
        trabajador = Trabajador(nombre="Legacy", apellidos="Schema", activo=True)
        db.add(trabajador)
        db.flush()

        solicitud = create_worker_request(
            db, trabajador,
            submission_id="legacy-schema-0001",
            priority="normal",
            destination="Obra Legacy",
            reason="Prueba de compatibilidad con esquema antiguo",
            items=[{"tipo": "herramienta", "descripcion": "Taladro", "talla": "", "cantidad": "1"}],
        )
        db.commit()
        solicitud_id = solicitud.id
    finally:
        db.close()

    try:
        with engine.connect() as conn:
            row = conn.execute(
                text("SELECT tipo, categoria, asunto, mensaje FROM solicitudes_trabajador WHERE id = :id"),
                {"id": solicitud_id},
            ).fetchone()
        assert row is not None, "la solicitud debe haberse guardado realmente en la base de datos"
        tipo, categoria, asunto, mensaje = row
        assert tipo, "tipo debe quedar relleno para no violar el NOT NULL heredado"
        assert categoria, "categoria debe quedar rellena para no violar el NOT NULL heredado"
        assert asunto, "asunto debe quedar relleno para no violar el NOT NULL heredado"
        assert mensaje, "mensaje debe quedar relleno para no violar el NOT NULL heredado"
    finally:
        engine.dispose()
