"""Lecturas de EPI de stock que el lector entrega pegadas de dos en dos.

El 10/09/2026 el escaner de produccion entrego "SEPI-0028SEPI'0027" y
"SEPI-0028SEPI'0006", y ninguno se reconocio: la deteccion de lecturas pegadas
solo contemplaba los codigos largos MRD-XXX-<32 hex>.
"""
from scanner_service import normalize_scanned_code, scan_code_candidates


def test_dos_codigos_pegados_se_separan():
    assert normalize_scanned_code("SEPI-0028SEPI'0027") == "SEPI-0027"
    assert normalize_scanned_code("SEPI-0028SEPI'0006") == "SEPI-0006"


def test_se_queda_con_el_ultimo_no_con_la_cola_de_la_lectura_anterior():
    # El de delante es lo que arrastraba el lector; el bueno es el que se acaba
    # de leer. Al repetirse SEPI-0028 en las dos lecturas del log, era la cola.
    candidatos = scan_code_candidates("SEPI-0028SEPI-0027")
    assert candidatos[0] == "SEPI-0027"


def test_una_lectura_limpia_no_se_toca():
    assert normalize_scanned_code("SEPI-0028") == "SEPI-0028"
    assert normalize_scanned_code("sepi-0028") == "SEPI-0028"


def test_el_apostrofo_del_teclado_sigue_valiendo_como_guion():
    assert normalize_scanned_code("SEPI'0028") == "SEPI-0028"


def test_no_devuelve_los_dos_a_la_vez():
    # Si los dos llegaran como candidatos y ambos existieran en el almacen, la
    # consulta que los busca encontraria dos articulos y reventaria.
    candidatos = scan_code_candidates("SEPI-0028SEPI-0027")
    assert "SEPI-0028" not in candidatos


def test_los_codigos_largos_siguen_funcionando():
    largo = "MRD-HTA-" + "A" * 32
    assert normalize_scanned_code(largo) == largo
    assert normalize_scanned_code(largo + largo) == largo
