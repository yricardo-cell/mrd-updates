"""El stock bajo de EPI y ropa solo avisa de lo que sigue en el catálogo.

Caso real: salían ARNES, ABSORBEDOR, METRO y CHALECO como que faltaban. Los
tres primeros estaban quitados del catálogo y CHALECO ni existía en él; además
los arneses y absorbedores se llevan uno a uno, no en stock genérico. Y al
abrir la pantalla de stock se volvían a crear con mínimo 3.
"""
import main
from auth import hash_password
from models import Almacen, CatalogoEPI, StockEPI, Usuario


def _setup(db):
    almacen = Almacen(nombre="Almacen Stock", codigo="MRD-SBC", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="stock-cat", password_hash=hash_password("ClaveSegura123!"),
                   nombre="Stock Catalogo", rol="admin", activo=True,
                   must_change_password=False, almacen_id=almacen.id))
    db.add_all([
        CatalogoEPI(nombre="CASCO", categoria="epi", cantidad_kit=1, activo=True),
        CatalogoEPI(nombre="BOTAS", categoria="ropa", cantidad_kit=1, activo=True),
        CatalogoEPI(nombre="METRO", categoria="epi", cantidad_kit=1, activo=False),
        CatalogoEPI(nombre="ARNES", categoria="epi", cantidad_kit=1, activo=True),
    ])
    db.add_all([
        StockEPI(nombre="CASCO", categoria="epi", cantidad=1, stock_minimo=5, almacen_id=almacen.id),
        StockEPI(nombre="BOTAS", categoria="ropa", talla="44", cantidad=0, stock_minimo=5, almacen_id=almacen.id),
        StockEPI(nombre="METRO", categoria="epi", cantidad=0, stock_minimo=3, almacen_id=almacen.id),
        StockEPI(nombre="CHALECO", categoria="ropa", cantidad=0, stock_minimo=3, almacen_id=almacen.id),
        StockEPI(nombre="ARNES", categoria="epi", cantidad=0, stock_minimo=3, almacen_id=almacen.id),
    ])
    db.commit()
    return almacen


def _login(client):
    resp = client.post("/login", data={"username": "stock-cat", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def test_el_contador_solo_cuenta_lo_del_catalogo(db):
    almacen = _setup(db)
    assert main._stock_bajo_count(db, almacen.id) == 2  # CASCO y BOTAS 44


def test_la_pagina_de_stock_bajo_no_pide_lo_quitado_del_catalogo(client, db):
    _setup(db)
    _login(client)

    html = client.get("/materiales/alertas").text
    assert "CASCO" in html and "BOTAS" in html
    assert "METRO" not in html      # quitado del catálogo
    assert "CHALECO" not in html    # nunca estuvo en el catálogo
    assert "ARNES" not in html      # se lleva uno a uno


def test_los_pedidos_a_proveedor_no_sugieren_lo_quitado(client, db):
    _setup(db)
    _login(client)

    html = client.get("/pedidos-proveedor").text
    assert "CASCO" in html
    assert "METRO" not in html and "CHALECO" not in html and "ARNES" not in html


def test_el_panel_de_patio_no_avisa_de_lo_quitado(client, db):
    _setup(db)
    _login(client)

    html = client.get("/panel-patio").text
    assert "METRO" not in html and "CHALECO" not in html


def test_el_estado_real_del_inventario_no_lo_cuenta(db):
    _setup(db)
    resumen = main._estado_inventario_real(db)
    assert resumen["stock"]["epi_stock"]["bajo_minimo"] == 1   # CASCO
    assert resumen["stock"]["ropa"]["bajo_minimo"] == 1        # BOTAS 44, no CHALECO


def test_abrir_la_pantalla_de_stock_no_resucita_lo_quitado(client, db):
    almacen = _setup(db)
    db.query(StockEPI).filter(StockEPI.nombre.in_(["METRO", "ARNES", "CASCO"])).delete(synchronize_session=False)
    db.commit()
    _login(client)

    assert client.get("/epis/stock").status_code == 200
    nombres = {n for (n,) in db.query(StockEPI.nombre).filter(StockEPI.almacen_id == almacen.id)}
    assert "CASCO" in nombres              # sigue en el catálogo: se crea su ficha
    assert "METRO" not in nombres          # quitado del catálogo: no vuelve
    assert "ARNES" not in nombres          # uno a uno: no hace falta ficha genérica
    assert "PORTAMETRO" not in nombres     # la lista fija antigua ya no manda


def test_sin_catalogo_todavia_se_usa_el_kit_inicial(db):
    main._inicializar_stock_epi(db)
    nombres = {n for (n,) in db.query(StockEPI.nombre)}
    assert "CASCO" in nombres
    assert "ARNES" not in nombres and "ABSORBEDOR" not in nombres
