"""Quitar cosas de un hueco (o vaciarlo) sin borrarlas: siguen en el inventario, sin hueco."""
from auth import hash_password
from models import Almacen, AuditoriaLog, Herramienta, Material, StockEPI, Ubicacion, Usuario
from security import generar_csrf_token


def _setup(db, rol="admin"):
    almacen = Almacen(nombre="Nave quitar", codigo="MRD-QUI", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="quitar", password_hash=hash_password("ClaveSegura123!"), nombre="Quitar",
                   rol=rol, activo=True, must_change_password=False, almacen_id=almacen.id))
    u = Ubicacion(almacen_id=almacen.id, nombre="CONTENEDOR A1", codigo="MRD-UBI-QUI-A1", zona="CONTENEDOR",
                  estanteria="A", balda="1", posicion="1", activo=True)
    u2 = Ubicacion(almacen_id=almacen.id, nombre="CONTENEDOR A2", codigo="MRD-UBI-QUI-A2", zona="CONTENEDOR",
                   estanteria="A", balda="1", posicion="2", activo=True)
    db.add_all([u, u2])
    db.flush()
    cosas = {
        "taladro": Herramienta(codigo="HER-QUI-1", nombre="Taladro", estado="disponible", activa=True,
                               almacen_id=almacen.id, ubicacion_id=u.id),
        "tornillo": Material(codigo="MAT-QUI-1", nombre="Tornillo", stock_actual=50, activo=True,
                             almacen_id=almacen.id, ubicacion_id=u.id),
        "guantes": StockEPI(nombre="GUANTES", categoria="epi", cantidad=12, codigo="SEPI-QUI-1",
                            almacen_id=almacen.id, ubicacion_id=u.id),
        "radial": Herramienta(codigo="HER-QUI-2", nombre="Radial", estado="disponible", activa=True,
                              almacen_id=almacen.id, ubicacion_id=u2.id),
    }
    db.add_all(cosas.values())
    db.commit()
    return almacen, u, u2, cosas


def _login(client):
    resp = client.post("/login", data={"username": "quitar", "password": "ClaveSegura123!"}, follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])
    token = generar_csrf_token()
    client.cookies.set("mrd_csrf", token)
    return {"X-CSRF-Token": token, "Accept": "application/json"}


def test_quitar_una_cosa_la_deja_sin_hueco_pero_no_la_borra(client, db):
    _, u, _, c = _setup(db)
    h = _login(client)

    r = client.post(f"/api/nave/huecos/{u.id}/quitar", json={"items": [{"tipo": "herramienta", "id": c["taladro"].id}]}, headers=h)
    assert r.status_code == 200, r.text
    assert r.json()["quitados"] == 1
    db.expire_all()
    taladro = db.get(Herramienta, c["taladro"].id)
    assert taladro is not None and taladro.ubicacion_id is None      # sigue existiendo, sin hueco
    assert db.get(Material, c["tornillo"].id).ubicacion_id == u.id   # lo demás no se toca
    assert db.get(Material, c["tornillo"].id).stock_actual == 50


def test_vaciar_el_hueco_quita_todo_lo_suyo_y_nada_de_otros(client, db):
    _, u, u2, c = _setup(db)
    h = _login(client)

    r = client.post(f"/api/nave/huecos/{u.id}/quitar", json={"todo": True}, headers=h)
    assert r.status_code == 200, r.text
    assert r.json()["quitados"] == 3
    db.expire_all()
    assert db.get(Herramienta, c["taladro"].id).ubicacion_id is None
    assert db.get(Material, c["tornillo"].id).ubicacion_id is None
    assert db.get(StockEPI, c["guantes"].id).ubicacion_id is None
    assert db.get(StockEPI, c["guantes"].id).cantidad == 12          # el stock no cambia
    assert db.get(Herramienta, c["radial"].id).ubicacion_id == u2.id  # otro hueco, intacto


def test_no_quita_lo_que_esta_en_otro_hueco(client, db):
    _, u, u2, c = _setup(db)
    h = _login(client)

    r = client.post(f"/api/nave/huecos/{u.id}/quitar", json={"items": [{"tipo": "herramienta", "id": c["radial"].id}]}, headers=h)
    assert r.status_code == 200 and r.json()["quitados"] == 0
    db.expire_all()
    assert db.get(Herramienta, c["radial"].id).ubicacion_id == u2.id


def test_queda_en_la_auditoria(client, db):
    _, u, _, c = _setup(db)
    h = _login(client)

    client.post(f"/api/nave/huecos/{u.id}/quitar", json={"items": [{"tipo": "material", "id": c["tornillo"].id}]}, headers=h)
    log = db.query(AuditoriaLog).filter(AuditoriaLog.tabla == "materiales", AuditoriaLog.registro_id == c["tornillo"].id,
                                        AuditoriaLog.accion == "quitar_de_hueco").first()
    assert log is not None


def test_hueco_de_otro_almacen_no_existe(client, db):
    _setup(db)
    otro = Almacen(nombre="Ajeno", codigo="MRD-QUI-AJ", activo=True)
    db.add(otro)
    db.flush()
    ajeno = Ubicacion(almacen_id=otro.id, nombre="AJENO 1", codigo="MRD-UBI-AJ-1", activo=True)
    db.add(ajeno)
    db.commit()
    h = _login(client)

    assert client.post(f"/api/nave/huecos/{ajeno.id}/quitar", json={"todo": True}, headers=h).status_code == 404


def test_peticiones_malas(client, db):
    _, u, u2, _ = _setup(db)
    h = _login(client)

    assert client.post(f"/api/nave/huecos/{u.id}/quitar", json={"items": [{"tipo": "herramienta"}]}, headers=h).status_code == 400
    assert client.post(f"/api/nave/huecos/{u.id}/quitar", json={}, headers=h).status_code == 400
    vacio = Ubicacion(almacen_id=u.almacen_id, nombre="VACIO", codigo="MRD-UBI-QUI-V", activo=True)
    db.add(vacio)
    db.commit()
    assert client.post(f"/api/nave/huecos/{vacio.id}/quitar", json={"todo": True}, headers=h).status_code == 400


def test_sin_permiso_no_quita(client, db):
    _, u, _, c = _setup(db, rol="operario")
    h = _login(client)

    assert client.post(f"/api/nave/huecos/{u.id}/quitar", json={"todo": True}, headers=h).status_code == 403
    db.expire_all()
    assert db.get(Herramienta, c["taladro"].id).ubicacion_id == u.id


def test_las_pantallas_tienen_los_botones(client, db):
    _setup(db)
    _login(client)

    assert 'id="hueco-vaciar"' in client.get("/nave").text
    assert "data-quitar-hueco" in client.get("/nave/3d").text
