"""Hora UTC sin zona horaria, que es como la guarda la base de datos."""
from datetime import datetime, timezone


def utcnow() -> datetime:
    """El mismo valor que devolvía datetime.utcnow().

    Python ha marcado datetime.utcnow() como obsoleto y lo quitará. La
    alternativa que propone, datetime.now(timezone.utc), devuelve una fecha con
    zona horaria, pero la base de datos guarda todas sin zona: comparar una con
    otra lanza TypeError. Por eso se quita la zona al final."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
