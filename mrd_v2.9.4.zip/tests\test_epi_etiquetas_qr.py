"""Arneses y absorbedores: el QR se ve en la ficha y se imprime en PDF."""
import re
from datetime import date

from auth import hash_password
from label_printer import item_etiqueta_epi_individual
from models import Almacen, EPIIndividual, Usuario


def _setup(db, rol="admin"):
    almacen = Almacen(nombre="Almacen EPI", codigo="MRD-EPIQR", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="epi-qr", password_hash=hash_password("ClaveSegura123!"),
                   nombre="EPI QR", rol=rol, activo=True,
                   must_change_password=False, almacen_id=almacen.id))
    equipos = [
        EPIIndividual(tipo="ARNES", codigo_fabricacion="236410964", estado="activo",
                      codigo_qr="QEPIS-AAAAAAAAAAAA", referencia_interna="MRD-EPIS-AAAA",
                      almacen_id=almacen.id),
        EPIIndividual(tipo="ARNES", codigo_fabricacion="236411055", estado="activo",
                      codigo_qr="QEPIS-BBBBBBBBBBBB", referencia_interna="MRD-EPIS-BBBB",
                      almacen_id=almacen.id),
        EPIIndividual(tipo="ABSORBEDOR", codigo_fabricacion="227860119", estado="activo",
                      codigo_qr="QEPIS-CCCCCCCCCCCC", referencia_interna="MRD-EPIS-CCCC",
                      almacen_id=almacen.id),
        EPIIndividual(tipo="ARNES", codigo_fabricacion="RETIRADO-1", estado="baja",
                      codigo_qr="QEPIS-DDDDDDDDDDDD", almacen_id=almacen.id),
    ]
    db.add_all(equipos)
    db.commit()
    return almacen, equipos


def _login(client):
    resp = client.post("/login", data={"username": "epi-qr", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def _paginas(pdf: bytes) -> int:
    return len(re.findall(rb"/Type\s*/Page(?![s])", pdf))


def test_la_ficha_ensena_el_qr_y_como_imprimirlo(client, db):
    _, equipos = _setup(db)
    _login(client)
    arnes = equipos[0]

    html = client.get(f"/epis/individuales/{arnes.id}").text
    assert f'src="/qr/epi_individual/{arnes.id}"' in html
    assert f"/qr/epi_individual/{arnes.id}/imprimir" in html
    assert f"/epis/individuales/etiquetas/pdf?ids={arnes.id}" in html


def test_la_imagen_del_qr_se_sirve(client, db):
    _, equipos = _setup(db)
    _login(client)

    r = client.get(f"/qr/epi_individual/{equipos[0].id}")
    assert r.status_code == 200
    assert r.content[:8] == b"\x89PNG\r\n\x1a\n"


def test_el_listado_tiene_qr_por_fila_y_boton_de_etiquetas(client, db):
    _, equipos = _setup(db)
    _login(client)

    html = client.get("/epis/individuales").text
    assert 'id="btn-etiquetas"' in html
    assert f"/qr/epi_individual/{equipos[0].id}/imprimir" in html
    assert f'data-id="{equipos[0].id}"' in html


def test_pdf_de_todos_los_equipos_sin_los_de_baja(client, db):
    _setup(db)
    _login(client)

    r = client.get("/epis/individuales/etiquetas/pdf")
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert r.headers["content-disposition"].startswith("inline;")
    assert _paginas(r.content) == 3  # el de baja no


def test_pdf_solo_de_los_elegidos(client, db):
    _, equipos = _setup(db)
    _login(client)

    r = client.get(f"/epis/individuales/etiquetas/pdf?ids={equipos[0].id},{equipos[2].id}")
    assert _paginas(r.content) == 2
    assert "seleccion" in r.headers["content-disposition"]


def test_no_se_cuelan_equipos_de_otro_almacen(client, db):
    _, equipos = _setup(db)
    otro = Almacen(nombre="Ajeno", codigo="MRD-AJE-EPI", activo=True)
    db.add(otro)
    db.flush()
    ajeno = EPIIndividual(tipo="ARNES", codigo_fabricacion="AJENO-1", estado="activo",
                          codigo_qr="QEPIS-EEEEEEEEEEEE", almacen_id=otro.id)
    db.add(ajeno)
    db.commit()
    _login(client)

    r = client.get(f"/epis/individuales/etiquetas/pdf?ids={equipos[0].id},{ajeno.id}")
    assert _paginas(r.content) == 1


def test_lista_con_basura_se_rechaza(client, db):
    _setup(db)
    _login(client)

    assert client.get("/epis/individuales/etiquetas/pdf?ids=1;DROP").status_code == 400


def test_un_equipo_antiguo_sin_qr_lo_recibe_al_imprimir(client, db):
    almacen, _ = _setup(db)
    viejo = EPIIndividual(tipo="ARNES", codigo_fabricacion="VIEJO-1", estado="activo",
                          almacen_id=almacen.id)
    db.add(viejo)
    db.commit()
    _login(client)

    r = client.get(f"/epis/individuales/etiquetas/pdf?ids={viejo.id}")
    assert r.status_code == 200
    db.refresh(viejo)
    assert viejo.codigo_qr and viejo.codigo_qr.startswith("QEPIS-")


def test_sin_permiso_de_etiquetas_no_imprime(client, db):
    _setup(db, rol="operario")
    _login(client)

    assert client.get("/epis/individuales/etiquetas/pdf").status_code == 403


def test_la_etiqueta_lleva_el_codigo_que_reconoce_el_lector():
    e = EPIIndividual(tipo="ARNES", codigo_fabricacion="236410964", codigo_qr="QEPIS-AAAAAAAAAAAA",
                      marca="Petzl", modelo="Avao", proxima_revision=date(2027, 3, 1))
    item = item_etiqueta_epi_individual(e)
    assert item["qr"] == "QEPIS-AAAAAAAAAAAA"
    assert item["grande"] == "236410964"      # el nº de serie que se ve en la cinta
    assert item["sup"] == "ARNES"
    assert item["detalle"] == "Petzl · Avao"
    assert item["pie"] == "Revisión 01/03/2027"
