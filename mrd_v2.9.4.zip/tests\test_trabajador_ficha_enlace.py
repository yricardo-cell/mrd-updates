"""/trabajadores/<id> a secas daba 404: la usan arneses, calendario e informes."""
from auth import hash_password
from models import Almacen, Trabajador, Usuario


def _setup(db):
    almacen = Almacen(nombre="Nave fichas", codigo="MRD-FIC", activo=True)
    db.add(almacen)
    db.flush()
    db.add(Usuario(username="fichas", password_hash=hash_password("ClaveSegura123!"), nombre="Fichas",
                   rol="admin", activo=True, must_change_password=False, almacen_id=almacen.id))
    t = Trabajador(nombre="Sane", apellidos="Prueba", activo=True, almacen_id=almacen.id)
    db.add(t)
    db.commit()
    return t


def _login(client):
    resp = client.post("/login", data={"username": "fichas", "password": "ClaveSegura123!"}, follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def test_el_enlace_a_secas_lleva_a_la_ficha_del_trabajador(client, db):
    t = _setup(db)
    _login(client)

    r = client.get(f"/trabajadores/{t.id}", follow_redirects=False)
    assert r.status_code == 303
    assert r.headers["location"] == f"/trabajadores/{t.id}/epis"
    assert client.get(f"/trabajadores/{t.id}").status_code == 200


def test_no_se_come_las_otras_paginas_de_trabajadores(client, db):
    _setup(db)
    _login(client)

    assert client.get("/trabajadores/importar").status_code == 200
    assert client.get("/trabajadores/cuidado").status_code == 200


def test_sin_sesion_no_entra(client, db):
    t = _setup(db)
    r = client.get(f"/trabajadores/{t.id}", follow_redirects=False)
    assert r.status_code in (302, 303, 401)
    assert "/epis" not in r.headers.get("location", "")
