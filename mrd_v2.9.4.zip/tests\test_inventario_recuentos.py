"""Lo que dice la pantalla de Inventario tiene que ser lo que luego se cuenta.

En produccion «Ropa y EPI de stock» marcaba 0 con 85 referencias en el almacen
(miraba las variantes, que estan vacias) y «Todo el almacen» decia 200 cuando
eran 536, porque no sumaba ni herramientas ni maquinaria.
"""
from auth import hash_password
from models import (
    Almacen, EPIIndividual, Herramienta, LineaInventario, Material, StockEPI, Usuario,
)
from inventario_service import open_inventory_session


def _setup(db):
    almacen = Almacen(nombre="Almacen Recuentos", codigo="MRD-REC", activo=True)
    otro = Almacen(nombre="Almacen Ajeno", codigo="MRD-AJE2", activo=True)
    db.add_all([almacen, otro])
    db.flush()
    db.add(Usuario(username="admin-rec", password_hash=hash_password("ClaveSegura123!"),
                   nombre="Admin Recuentos", rol="admin", activo=True,
                   must_change_password=False, almacen_id=almacen.id))

    db.add(Material(codigo="REC-MAT-1", nombre="Tornillos", activo=True,
                    almacen_id=almacen.id, stock_actual=10, unidad="ud"))
    db.add(StockEPI(nombre="PANTALON", categoria="ropa", talla="L", cantidad=5,
                    almacen_id=almacen.id))
    db.add(StockEPI(nombre="BOTAS", categoria="ropa", talla="42", cantidad=3,
                    almacen_id=almacen.id))
    db.add(StockEPI(nombre="CASCO", categoria="epi", cantidad=7, almacen_id=almacen.id))
    db.add(StockEPI(nombre="GUANTES AJENOS", categoria="epi", cantidad=9, almacen_id=otro.id))
    db.add(EPIIndividual(tipo="ARNES", codigo_fabricacion="REC-ARN-1", estado="activo",
                         almacen_id=almacen.id))
    db.add(EPIIndividual(tipo="ARNES", codigo_fabricacion="REC-ARN-BAJA", estado="baja",
                         almacen_id=almacen.id))
    db.add(Herramienta(codigo="REC-HER-1", nombre="Taladro", estado="disponible",
                       activa=True, almacen_id=almacen.id))
    db.add(Herramienta(codigo="REC-HER-AJENA", nombre="Sierra ajena", estado="disponible",
                       activa=True, almacen_id=otro.id))
    db.commit()
    return almacen


def _login(client):
    resp = client.post("/login", data={"username": "admin-rec", "password": "ClaveSegura123!"},
                       follow_redirects=False)
    client.cookies.set("mrd_token", resp.cookies["mrd_token"])


def test_la_ropa_y_el_epi_de_stock_cuentan_juntos(client, db):
    _setup(db)
    _login(client)
    # 2 de ropa + 1 de EPI del almacen; el del otro almacen no entra
    assert "3 referencias" in client.get("/inventario").text


def test_todo_el_almacen_incluye_las_herramientas(client, db):
    _setup(db)
    _login(client)
    # 1 material + 3 de stock + 1 EPI individual + 1 herramienta = 6
    assert "6 referencias" in client.get("/inventario").text


def test_el_inventario_de_ropa_mete_tambien_los_epi_de_stock(client, db):
    almacen = _setup(db)
    user = db.query(Usuario).filter(Usuario.username == "admin-rec").one()

    sesion = open_inventory_session(
        db, user, nombre="Prueba ropa", scope="total",
        tipo_articulo="epi_ropa", almacen_id=almacen.id,
    )
    lineas = db.query(LineaInventario).filter(LineaInventario.sesion_id == sesion.id).all()
    nombres = {db.get(StockEPI, l.stock_epi_id).nombre for l in lineas if l.stock_epi_id}
    assert nombres == {"PANTALON", "BOTAS", "CASCO"}


def test_el_inventario_no_cuenta_lo_de_otro_almacen(client, db):
    almacen = _setup(db)
    user = db.query(Usuario).filter(Usuario.username == "admin-rec").one()

    sesion = open_inventory_session(
        db, user, nombre="Prueba almacen", scope="total",
        tipo_articulo="epi_ropa", almacen_id=almacen.id,
    )
    lineas = db.query(LineaInventario).filter(LineaInventario.sesion_id == sesion.id).all()
    nombres = {db.get(StockEPI, l.stock_epi_id).nombre for l in lineas if l.stock_epi_id}
    assert "GUANTES AJENOS" not in nombres
