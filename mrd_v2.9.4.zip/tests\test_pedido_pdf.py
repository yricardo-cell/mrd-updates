"""PDF del pedido a proveedor: referencia que el proveedor reconoce y totales."""
import io
from datetime import date
from types import SimpleNamespace

import pytest

from reports import exportar_pedido_pdf

# Leer el PDF necesita pypdf, que no forma parte del entorno de la aplicacion.
# Donde no este, estos tests se saltan en vez de romper toda la ejecucion.
PdfReader = pytest.importorskip("pypdf", reason="pypdf no esta instalado en este entorno").PdfReader


def _linea(objeto_id, referencia, descripcion, cantidad, precio=None, tipo="material"):
    return SimpleNamespace(tipo=tipo, objeto_id=objeto_id, referencia=referencia,
                           descripcion=descripcion, cantidad_pedida=cantidad,
                           precio_anterior=precio)


def _pedido(lineas):
    return SimpleNamespace(numero="PED-20260910-TEST", fecha_pedido=date(2026, 9, 10),
                           proveedor=None, almacen=SimpleNamespace(nombre="Almacen Madrid"),
                           fecha_prevista=None, lineas=lineas, notas=None)


def _texto(pdf: bytes) -> str:
    return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(pdf)).pages)


def test_saca_la_referencia_del_proveedor_no_el_codigo_interno():
    pedido = _pedido([_linea(7, "MRD-MAT-698428E68D674123ABFD3F22637A2235", "TORNILLO M10X70", 1456)])
    pdf = exportar_pedido_pdf(pedido, referencias={("material", 7): "400719"})

    texto = _texto(pdf)
    assert "400719" in texto
    assert "MRD-MAT-698428" not in texto


def test_si_la_pieza_no_tiene_referencia_de_proveedor_usa_la_suya():
    pedido = _pedido([_linea(9, "MRD-MAT-SINREF", "CANCAMO 12x160", 379)])
    pdf = exportar_pedido_pdf(pedido, referencias={})

    assert "MRD-MAT-SINREF" in _texto(pdf)


def test_sin_precios_no_sale_una_columna_vacia():
    pedido = _pedido([_linea(1, "400719", "TORNILLO", 10),
                      _linea(2, "290212", "CANCAMO", 5)])
    texto = _texto(exportar_pedido_pdf(pedido))

    assert "Último precio" not in texto
    assert "Importe" not in texto
    assert "Total estimado" not in texto


def test_con_precios_aparece_el_importe_y_el_total():
    pedido = _pedido([_linea(1, "400719", "TORNILLO", 10, precio=2.5),    # 25.00
                      _linea(2, "290212", "CANCAMO", 4, precio=1.25)])    # 5.00
    texto = _texto(exportar_pedido_pdf(pedido))

    assert "Total estimado" in texto
    assert "30.00" in texto


def test_una_linea_sin_precio_no_rompe_el_total():
    pedido = _pedido([_linea(1, "400719", "TORNILLO", 10, precio=2.5),
                      _linea(2, "290212", "CANCAMO", 4, precio=None)])
    texto = _texto(exportar_pedido_pdf(pedido))

    assert "Total estimado" in texto
    assert "25.00" in texto


def test_la_descripcion_larga_no_se_pierde():
    largo = "BRIDA AJUSTABLE 780X9MM BLANCA NEGRA PARA SUJECION DE CABLES EN ESTRUCTURA"
    pedido = _pedido([_linea(1, "400719", largo, 2000)])
    texto = _texto(exportar_pedido_pdf(pedido))

    assert "BRIDA AJUSTABLE" in texto
    assert "ESTRUCTURA" in texto  # el final tambien, no se corta
