"""fechas.utcnow() sustituye a datetime.utcnow(), obsoleto en Python.

Tiene que devolver lo mismo que antes: la hora UTC SIN zona horaria. La
alternativa directa, datetime.now(timezone.utc), lleva zona, y las fechas de la
base de datos no: compararlas lanzaria TypeError por toda la aplicacion.
"""
import warnings
from datetime import datetime, timedelta, timezone

from fechas import utcnow


def test_devuelve_una_fecha_sin_zona():
    assert utcnow().tzinfo is None


def test_es_la_hora_utc_de_ahora():
    referencia = datetime.now(timezone.utc).replace(tzinfo=None)
    assert abs(utcnow() - referencia) < timedelta(seconds=2)


def test_se_puede_comparar_con_fechas_guardadas_sin_zona():
    guardada = datetime(2026, 1, 1, 12, 0, 0)  # como las devuelve la base de datos
    assert utcnow() > guardada
    assert (utcnow() - guardada).days > 0


def test_no_dispara_el_aviso_de_obsoleto():
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        utcnow()


def test_las_fechas_por_defecto_de_las_columnas_salen_sin_zona():
    # models.py pasaba datetime.utcnow sin parentesis como default de columna.
    import models  # noqa: F401  (registra las tablas)
    from database import Base

    vistas = 0
    for tabla in Base.metadata.tables.values():
        for columna in tabla.c:
            defecto = columna.default
            if defecto is None or not getattr(defecto, "is_callable", False):
                continue
            try:
                valor = defecto.arg(None)
            except TypeError:
                continue
            if isinstance(valor, datetime):
                assert valor.tzinfo is None, f"{tabla.name}.{columna.name}"
                vistas += 1
    assert vistas >= 8
