"""Rotacion en la vista 3D: dias que lleva sin moverse lo que hay en cada hueco."""
from datetime import datetime, timedelta

import main
from models import Almacen, Herramienta, Movimiento, Ubicacion


def _almacen(db):
    almacen = db.query(Almacen).filter(Almacen.activo == True).first()
    if not almacen:
        almacen = Almacen(nombre="Almacen Rotacion")
        db.add(almacen)
        db.commit()
    return almacen


def _hueco(db, almacen):
    hueco = Ubicacion(almacen_id=almacen.id, nombre="Estanteria A - Balda 1")
    db.add(hueco)
    db.commit()
    return hueco


def _herramienta(db, almacen, hueco, codigo, dias_desde_el_movimiento=None):
    herramienta = Herramienta(
        codigo=codigo, nombre=f"Herramienta {codigo}", estado="disponible",
        activa=True, almacen_id=almacen.id, ubicacion_id=hueco.id,
    )
    db.add(herramienta)
    db.commit()
    if dias_desde_el_movimiento is not None:
        db.add(Movimiento(
            herramienta_id=herramienta.id, tipo="entrega", estado_nuevo="entregada",
            fecha=datetime.now() - timedelta(days=dias_desde_el_movimiento),
        ))
        db.commit()
    return herramienta


def test_cuenta_los_dias_desde_el_ultimo_movimiento(client, db):
    almacen = _almacen(db)
    hueco = _hueco(db, almacen)
    _herramienta(db, almacen, hueco, "ROT-5", dias_desde_el_movimiento=5)

    contenido = main._nave_contenido(db, [hueco])
    assert [i["dias"] for i in contenido[hueco.id]] == [5]


def test_manda_el_movimiento_mas_reciente_de_cada_herramienta(client, db):
    almacen = _almacen(db)
    hueco = _hueco(db, almacen)
    herramienta = _herramienta(db, almacen, hueco, "ROT-VARIOS", dias_desde_el_movimiento=200)
    db.add(Movimiento(
        herramienta_id=herramienta.id, tipo="devolucion", estado_nuevo="disponible",
        fecha=datetime.now() - timedelta(days=3),
    ))
    db.commit()

    contenido = main._nave_contenido(db, [hueco])
    assert contenido[hueco.id][0]["dias"] == 3


def test_sin_movimientos_no_hay_dato(client, db):
    almacen = _almacen(db)
    hueco = _hueco(db, almacen)
    _herramienta(db, almacen, hueco, "ROT-NUNCA")

    contenido = main._nave_contenido(db, [hueco])
    assert contenido[hueco.id][0]["dias"] is None


def test_el_hueco_toma_lo_mas_recientemente_movido():
    items = [{"dias": 200}, {"dias": 5}, {"dias": 90}]
    assert main._nave_dias(items) == 5


def test_el_hueco_ignora_lo_que_no_tiene_dato():
    assert main._nave_dias([{"dias": None}, {"dias": 40}]) == 40
    assert main._nave_dias([{"dias": None}]) is None
    assert main._nave_dias([]) is None
